#!/usr/bin/env python3
"""
EOD.py — Email of Death.

Death's Head Software's IMAP/SMTP email client. Two UIs share the same
backend (IMAP, SMTP, SQLite cache, encrypted password store, address book)
and the same accounts file:

    python EOD.py             # Web edition (default): opens 127.0.0.1:8765
    python EOD.py --web       # explicit
    python EOD.py --desktop   # PyQt6 desktop GUI
    python EOD.py --gui       # alias for --desktop
"""
from __future__ import annotations

import base64
import email
import email.message
import email.policy
import email.utils
import imaplib
import json
import mimetypes
import os
import queue
import re
import smtplib
import socket
import sqlite3
import ssl
import sys
import threading
import time
import traceback
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email import encoders as email_encoders
from html import escape as html_escape, unescape as html_unescape
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# PyQt6 imports are deferred to run_desktop() so the web-edition build
# doesn't require PyQt6 to be present at all — the top-level import would
# fail in environments where PyQt6.sip isn't available (e.g. broken venv
# installs or server deployments).  All desktop classes that reference these
# names are only instantiated from run_desktop(), so this is safe.
try:
    from PyQt6.QtCore import (
        QByteArray, QEvent, QObject, QSize, QSettings, QStringListModel, Qt,
        QTimer, QUrl, pyqtSignal, pyqtSlot,
    )
    from PyQt6.QtGui import (
        QAction, QColor, QFont, QIcon, QKeySequence, QPainter, QPalette, QPixmap,
        QShortcut, QStandardItem, QStandardItemModel, QTextCharFormat, QTextDocument,
        QTextListFormat,
    )
    from PyQt6.QtWidgets import (
        QAbstractItemView, QApplication, QCheckBox, QComboBox, QCompleter,
        QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QFrame, QGroupBox,
        QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QListWidget,
        QListWidgetItem, QMainWindow, QMenu, QMessageBox, QProgressBar,
        QPushButton, QScrollArea, QSpinBox, QSplashScreen, QSplitter, QStatusBar,
        QStyle, QTabWidget, QTableView, QTextBrowser, QTextEdit, QToolBar,
        QToolButton, QTreeView, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
    )
    _PYQT6_AVAILABLE = True
except ImportError:
    _PYQT6_AVAILABLE = False

# Imports for the web edition (in addition to those required by the desktop):
# stdlib HTTP server, mimetypes, urllib.parse, queue.
import argparse
import mimetypes
import socketserver
import webbrowser
import queue as _queue
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse, quote as urlquote


APP_NAME = "Email of Death"
ORG_NAME = "Death's Head Software"
APP_VERSION = "1.0.0"

# =============================================================================
# Paths / Resources
# =============================================================================

def resource_path(relative: str) -> Path:
    """Resolve assets in dev and PyInstaller (_MEIPASS) builds."""
    if hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS) / relative
    return Path(__file__).parent / relative


def _ssl_context() -> ssl.SSLContext:
    """Return an SSL client context with a reliable CA bundle.

    In a PyInstaller bundle on Windows, ssl.create_default_context() may
    not find any CA certificates, causing all IMAP/SMTP connections to fail.
    We try certifi first (bundled Mozilla CA list), then fall back to the
    plain default context which on Python 3.4+ Windows uses the system store.
    """
    try:
        import certifi as _certifi
        return ssl.create_default_context(cafile=_certifi.where())
    except Exception:
        return ssl.create_default_context()


# =============================================================================
# Splash Screen
# =============================================================================

def create_splash():
    """
    Creates the QSplashScreen.

    It first checks for an external 'splash.png'. If not found, it generates
    a dark screen with the app name, org name, and ASCII skull art.
    """
    try:
        splash_path = resource_path("splash.png")

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback: Generate the dark-themed screen with ASCII art skull
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art): painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


def config_dir() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", str(Path.home() / "AppData/Roaming")))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config")))
    d = base / "EmailOfDeath"
    d.mkdir(parents=True, exist_ok=True)
    return d


CONFIG_FILE = config_dir() / "config.json"
CACHE_FILE = config_dir() / "cache.db"

# Web-edition constants. The skull image is expected to sit alongside this
# script — same conventions as the desktop's splash.png / icon.ico.
HOST = "127.0.0.1"
PORT = 8765
HEADERS_LIMIT = 100  # default per-folder fetch
# Web-edition asset paths. Use resource_path() so they resolve correctly both
# from a source checkout AND from a PyInstaller --onefile bundle (where assets
# are extracted to sys._MEIPASS at runtime).
SKULL_FILE = resource_path("skull_print.png")
ICON_FILE  = resource_path("icon.ico")


ATTACH_DIR = config_dir() / "attachments"
ATTACH_DIR.mkdir(parents=True, exist_ok=True)


# =============================================================================
# Account model + persistence
# =============================================================================

@dataclass
class Account:
    name: str = ""                 # display name (e.g. "Personal")
    email_addr: str = ""           # user@example.com
    real_name: str = ""            # "Sin"
    signature: str = ""

    imap_host: str = ""
    imap_port: int = 993
    imap_user: str = ""
    imap_pass: str = ""
    imap_ssl: bool = True          # implicit SSL

    smtp_host: str = ""
    smtp_port: int = 465
    smtp_user: str = ""
    smtp_pass: str = ""
    smtp_ssl: bool = True          # implicit SSL on connect (port 465 style)
    smtp_starttls: bool = False    # STARTTLS on plaintext (port 587 style)

    sent_folder: str = "Sent"
    trash_folder: str = "Trash"
    drafts_folder: str = "Drafts"

    def is_valid(self) -> bool:
        return bool(self.email_addr and self.imap_host and self.imap_user
                    and self.imap_pass and self.smtp_host and self.smtp_user
                    and self.smtp_pass)


# =============================================================================
# Password storage
# =============================================================================
#
# Three-tier scheme. Tried in order; first one that works wins:
#   1. keyring   — OS-native secret store (macOS Keychain, Windows Credential
#                  Manager, Linux SecretService / KWallet). Best.
#   2. Fernet    — cryptography.Fernet (AES-128-CBC + HMAC-SHA256) with a 32-byte
#                  random key kept in `keyfile` at 0o600. Real encryption at rest.
#   3. base64    — legacy obfuscation. Not encryption. Only used if neither lib
#                  is present.
#
# On-disk format is prefix-tagged:  "kr:<ref>", "frn:<ciphertext>", "b64:<obf>".
# load_accounts() detects the tag and decrypts; save_accounts() re-encrypts using
# whichever backend is currently active. Untagged legacy strings are treated as
# raw base64 (the v1 format) and migrated forward on next save.

try:
    import keyring as _keyring
    _HAS_KEYRING = True
except Exception:
    _HAS_KEYRING = False

try:
    from cryptography.fernet import Fernet as _Fernet, InvalidToken as _FernetInvalid
    _HAS_FERNET = True
except Exception:
    _HAS_FERNET = False


class PasswordStore:
    """Encrypts/decrypts secrets using the best backend available.

    backend: 'keyring' | 'fernet' | 'base64'
    """
    KEYRING_SERVICE = "EmailOfDeath"

    def __init__(self):
        self._fernet = None
        self.backend = "base64"
        self.backend_note = "base64 obfuscation (NOT encryption)"

        if _HAS_KEYRING:
            # Verify the OS backend actually does a working round-trip.
            # get_password returning None (no error but no value) is not
            # enough — it just means the probe key doesn't exist yet, which
            # tells us nothing about whether set/get will work at runtime.
            try:
                _probe_key = "__eod_probe__"
                _probe_val = "eod_probe_ok"
                _keyring.set_password(self.KEYRING_SERVICE, _probe_key, _probe_val)
                _read_back = _keyring.get_password(self.KEYRING_SERVICE, _probe_key)
                _keyring.delete_password(self.KEYRING_SERVICE, _probe_key)
                if _read_back == _probe_val:
                    self.backend = "keyring"
                    kb = type(_keyring.get_keyring()).__name__
                    self.backend_note = f"OS keyring ({kb})"
                    return
                # Read-back mismatch — backend silently doesn't work.
                sys.stderr.write(
                    f"[auth] keyring probe read-back mismatch "
                    f"(got {_read_back!r}), falling back\n"
                )
            except Exception as e:
                sys.stderr.write(
                    f"[auth] keyring probe failed ({e}), falling back\n"
                )

        if _HAS_FERNET:
            try:
                self._fernet = self._load_or_create_fernet()
                self.backend = "fernet"
                self.backend_note = "Fernet (AES-128-CBC + HMAC), key in " + str(self._keyfile_path())
                return
            except Exception as e:
                print(f"Fernet init failed: {e}", file=sys.stderr)

        # Final fallback.

    # -- keyfile management (Fernet backend) -------------------------------

    @staticmethod
    def _keyfile_path() -> Path:
        return config_dir() / "keyfile"

    def _load_or_create_fernet(self):
        kp = self._keyfile_path()
        if kp.exists():
            try:
                key = kp.read_bytes().strip()
            except Exception as e:
                raise RuntimeError(f"Cannot read keyfile: {e}")
        else:
            key = _Fernet.generate_key()
            kp.write_bytes(key)
            try:
                os.chmod(kp, 0o600)
            except Exception:
                pass  # Windows
        return _Fernet(key)

    # -- encrypt / decrypt --------------------------------------------------

    def encrypt(self, plaintext: str, ref: str) -> str:
        """Return the on-disk representation of `plaintext`.

        `ref` is a unique key for this secret (used by the keyring backend).
        Typically: f"{account_email}:imap" or f"{account_email}:smtp"."""
        if not plaintext:
            return ""
        if self.backend == "keyring":
            try:
                _keyring.set_password(self.KEYRING_SERVICE, ref, plaintext)
                return f"kr:{ref}"
            except Exception as e:
                print(f"keyring write failed, falling back: {e}", file=sys.stderr)
                # Fall through to whichever weaker backend exists.
        if self.backend == "fernet" or self._fernet is not None:
            try:
                token = self._fernet.encrypt(plaintext.encode("utf-8"))
                return "frn:" + token.decode("ascii")
            except Exception as e:
                print(f"Fernet encrypt failed, falling back: {e}", file=sys.stderr)
        # base64 fallback
        return "b64:" + base64.b64encode(plaintext.encode("utf-8")).decode("ascii")

    def decrypt(self, stored: str) -> str:
        """Return plaintext from on-disk representation. Tolerates legacy
        untagged base64 strings (the original v1 format)."""
        if not stored:
            return ""
        if stored.startswith("kr:"):
            ref = stored[3:]
            if not _HAS_KEYRING:
                return ""
            try:
                v = _keyring.get_password(self.KEYRING_SERVICE, ref)
                return v or ""
            except Exception as e:
                print(f"keyring read failed for {ref}: {e}", file=sys.stderr)
                return ""
        if stored.startswith("frn:"):
            if not _HAS_FERNET or self._fernet is None:
                return ""
            try:
                return self._fernet.decrypt(stored[4:].encode("ascii")).decode("utf-8")
            except _FernetInvalid:
                print("Fernet decrypt failed: invalid token (wrong keyfile?)",
                      file=sys.stderr)
                return ""
            except Exception as e:
                print(f"Fernet decrypt failed: {e}", file=sys.stderr)
                return ""
        if stored.startswith("b64:"):
            try:
                return base64.b64decode(stored[4:].encode("ascii")).decode("utf-8")
            except Exception:
                return ""
        # Legacy untagged base64 (v1 format).
        try:
            return base64.b64decode(stored.encode("ascii")).decode("utf-8")
        except Exception:
            return stored  # last-ditch: return as-is

    def forget(self, ref: str):
        """Best-effort removal of a keyring entry. No-op for other backends."""
        if not _HAS_KEYRING:
            return
        try:
            _keyring.delete_password(self.KEYRING_SERVICE, ref)
        except Exception:
            pass


# Single process-wide store instance, lazily constructed.
_PWSTORE: Optional[PasswordStore] = None


def password_store() -> PasswordStore:
    global _PWSTORE
    if _PWSTORE is None:
        _PWSTORE = PasswordStore()
    return _PWSTORE


def _fmt_exc(e: BaseException) -> str:
    """Render exception args readably, decoding any bytes in the args.
    imaplib.IMAP4.error stores raw protocol bytes here, which would otherwise
    render as `b'...'` Python repr — hostile to humans."""
    parts = []
    for a in (e.args or ()):
        if isinstance(a, (bytes, bytearray)):
            parts.append(bytes(a).decode("utf-8", "replace"))
        else:
            parts.append(str(a))
    return ": ".join(parts) if parts else type(e).__name__


def _auth_hints(error_text: str, email_addr: str) -> List[str]:
    """Given a connection-failure error string, return user-facing hint lines.
    Used by Test Connection AND by the post-connect failure dialog."""
    hints: List[str] = []
    s = error_text.lower()
    domain = email_addr.split("@", 1)[-1].lower() if "@" in email_addr else ""

    auth_failed = ("authenticationfailed" in s or "authentication failed" in s
                   or "smtpauthenticationerror" in s or " 535 " in s
                   or "[auth]" in s or "invalid credentials" in s
                   or "empty username or password" in s)
    if auth_failed:
        if domain in ("gmail.com", "googlemail.com"):
            hints.append("Gmail rejects regular passwords. You need an APP PASSWORD:\n"
                         "  1. Enable 2-Step Verification at myaccount.google.com\n"
                         "  2. Generate an app password at myaccount.google.com/apppasswords\n"
                         "  3. Enable IMAP at mail.google.com → Settings → Forwarding and POP/IMAP\n"
                         "  4. Use the 16-character app password (with or without spaces)")
        elif domain == "yahoo.com":
            hints.append("Yahoo requires an app password. Generate one at "
                         "login.yahoo.com → Account Security → Generate app password.")
        elif domain == "icloud.com":
            hints.append("iCloud requires an app-specific password "
                         "(appleid.apple.com → Sign-In and Security → App-Specific Passwords).")
        elif domain in ("outlook.com", "hotmail.com", "live.com"):
            hints.append("With MFA enabled, Outlook needs an app password "
                         "(account.microsoft.com → Security → Advanced security options).")
        elif domain == "fastmail.com":
            hints.append("Fastmail requires an app password (Settings → Privacy & Security).")
        elif domain == "mailfence.com":
            hints.append("Mailfence IMAP/SMTP requires a paid subscription. "
                         "Free accounts only have webmail access.")
        else:
            hints.append("Authentication was rejected. If your provider has 2FA, "
                         "you probably need an app-specific password rather than "
                         "your account password.")
    if "timed out" in s or "timeout" in s:
        hints.append("Timeout — check the host / port and any firewall or VPN. "
                     "Proton VPN's WFP driver has been known to break outbound IMAP/SMTP.")
    if "could not resolve" in s or "name or service not known" in s or "gaierror" in s:
        hints.append("DNS lookup failed. Verify the hostname and your internet connection.")
    if "starttls" in s and ("fail" in s or "error" in s):
        hints.append("If the server uses implicit SSL (port 465 / 993), select "
                     "SSL/TLS instead of STARTTLS.")
    if "this service is not currently enabled" in s and "subscription" in s:
        hints.append("Your provider requires a paid subscription for IMAP/SMTP access.")
    return hints


def load_accounts() -> List[Account]:
    if not CONFIG_FILE.exists():
        return []
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []
    ps = password_store()
    out = []
    for d in data.get("accounts", []):
        a = Account()
        for k, v in d.items():
            if hasattr(a, k):
                setattr(a, k, v)
        a.imap_pass = ps.decrypt(a.imap_pass)
        a.smtp_pass = ps.decrypt(a.smtp_pass)
        out.append(a)
    return out


def save_accounts(accounts: List[Account]) -> None:
    ps = password_store()
    payload = {
        "accounts": [],
        "_password_backend": ps.backend,  # informational only
    }
    for a in accounts:
        d = asdict(a)
        # Keep cleartext out of the JSON.
        d["imap_pass"] = ps.encrypt(a.imap_pass, f"{a.email_addr}:imap")
        d["smtp_pass"] = ps.encrypt(a.smtp_pass, f"{a.email_addr}:smtp")
        payload["accounts"].append(d)
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(CONFIG_FILE)
    try:
        os.chmod(CONFIG_FILE, 0o600)
    except Exception:
        pass


# =============================================================================
# Cache (SQLite)
# =============================================================================

class MessageCache:
    """Caches message bodies + headers per (account, folder, uid).
    Headers are also re-fetched live; cache exists for offline read of opened messages.

    Concurrency model:
    - SQLite WAL mode is enabled at startup, allowing concurrent readers and
      one writer without Python-level locking.
    - The writer thread holds ONE long-lived connection and drains a queue
      of pending writes. No connection setup cost per write.
    - Reader threads (the GUI thread, mostly) cache one connection per thread
      via thread-local storage. With WAL, reads never block on writes.
    - There is deliberately no Python `Lock` — SQLite handles concurrency
      internally and adding one only creates contention (which is what the
      previous version did, causing the GUI to freeze when the writer was
      mid-commit on Windows with antivirus inspection)."""

    _SHUTDOWN = object()

    def __init__(self, path: Path):
        self.path = path
        self._init_schema_and_wal()
        self._tls = threading.local()
        self._wq: "queue.Queue[Any]" = queue.Queue()
        self._writer = threading.Thread(target=self._writer_loop,
                                        daemon=True, name="MessageCache-writer")
        self._writer.start()

    def _init_schema_and_wal(self):
        # One-time setup with a transient connection.
        c = sqlite3.connect(str(self.path), timeout=10)
        try:
            c.execute("PRAGMA journal_mode=WAL")
            # NORMAL is durable across crashes (vs FULL) but skips the extra
            # fsync per commit — much faster on Windows.
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("""
                CREATE TABLE IF NOT EXISTS folder_state (
                    account TEXT, folder TEXT, uidvalidity INTEGER,
                    PRIMARY KEY (account, folder)
                )
            """)
            c.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    account TEXT, folder TEXT, uid INTEGER,
                    msg_id TEXT,
                    from_addr TEXT, to_addrs TEXT, cc_addrs TEXT,
                    subject TEXT, date_iso TEXT,
                    body_text TEXT, body_html TEXT,
                    seen INTEGER, flagged INTEGER, has_attachments INTEGER,
                    raw BLOB,
                    PRIMARY KEY (account, folder, uid)
                )
            """)
            c.commit()
        finally:
            c.close()

    def _reader_conn(self) -> sqlite3.Connection:
        """Per-thread reader connection, lazily created and cached."""
        conn = getattr(self._tls, "conn", None)
        if conn is None:
            conn = sqlite3.connect(str(self.path), timeout=5)
            conn.row_factory = sqlite3.Row
            self._tls.conn = conn
        return conn

    # -------- public read API (synchronous; runs on caller thread) --------

    def get_message(self, account: str, folder: str, uid: int) -> Optional[dict]:
        try:
            row = self._reader_conn().execute(
                "SELECT * FROM messages WHERE account=? AND folder=? AND uid=?",
                (account, folder, uid)
            ).fetchone()
        except sqlite3.Error as e:
            print(f"MessageCache.get_message: {e}", file=sys.stderr)
            return None
        return dict(row) if row else None

    # -------- public write API (async; enqueued, never blocks caller) -----

    def store_message(self, account: str, folder: str, uid: int, data: dict):
        keep = {k: data.get(k, "") for k in
                ("msg_id", "from_addr", "to_addrs", "cc_addrs",
                 "subject", "date_iso", "body_text", "body_html")}
        keep["seen"] = bool(data.get("seen"))
        keep["flagged"] = bool(data.get("flagged"))
        keep["has_attachments"] = bool(data.get("has_attachments"))
        keep["raw"] = data.get("raw")
        self._wq.put(("store", account, folder, uid, keep))

    def update_seen(self, account: str, folder: str, uid: int, seen: bool):
        self._wq.put(("update_seen", account, folder, uid, bool(seen)))

    def delete(self, account: str, folder: str, uid: int):
        self._wq.put(("delete", account, folder, uid))

    def shutdown(self, timeout: float = 2.0):
        try:
            self._wq.put(self._SHUTDOWN)
            self._writer.join(timeout=timeout)
        except Exception:
            pass

    # -------- writer thread loop (single long-lived connection) ----------

    def _writer_loop(self):
        try:
            conn = sqlite3.connect(str(self.path), timeout=10)
        except sqlite3.Error as e:
            print(f"MessageCache writer: failed to open: {e}", file=sys.stderr)
            return
        try:
            while True:
                item = self._wq.get()
                if item is self._SHUTDOWN:
                    break
                try:
                    op = item[0]
                    if op == "store":
                        _, account, folder, uid, data = item
                        conn.execute("""
                            INSERT OR REPLACE INTO messages
                                (account, folder, uid, msg_id, from_addr, to_addrs, cc_addrs,
                                 subject, date_iso, body_text, body_html,
                                 seen, flagged, has_attachments, raw)
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        """, (account, folder, uid,
                              data.get("msg_id", ""),
                              data.get("from_addr", ""), data.get("to_addrs", ""),
                              data.get("cc_addrs", ""),
                              data.get("subject", ""), data.get("date_iso", ""),
                              data.get("body_text", ""), data.get("body_html", ""),
                              int(bool(data.get("seen"))),
                              int(bool(data.get("flagged"))),
                              int(bool(data.get("has_attachments"))),
                              data.get("raw")))
                    elif op == "update_seen":
                        _, account, folder, uid, seen = item
                        conn.execute(
                            "UPDATE messages SET seen=? WHERE account=? AND folder=? AND uid=?",
                            (int(bool(seen)), account, folder, uid)
                        )
                    elif op == "delete":
                        _, account, folder, uid = item
                        conn.execute(
                            "DELETE FROM messages WHERE account=? AND folder=? AND uid=?",
                            (account, folder, uid)
                        )
                    elif op == "set_uidv":
                        _, account, folder, uidv = item
                        conn.execute("""
                            INSERT INTO folder_state (account, folder, uidvalidity)
                            VALUES (?, ?, ?)
                            ON CONFLICT(account, folder) DO UPDATE
                                SET uidvalidity=excluded.uidvalidity
                        """, (account, folder, uidv))
                    elif op == "wipe_folder":
                        _, account, folder = item
                        conn.execute(
                            "DELETE FROM messages WHERE account=? AND folder=?",
                            (account, folder)
                        )
                    conn.commit()
                except Exception as e:
                    print(f"MessageCache writer: {e}", file=sys.stderr)
        finally:
            try: conn.close()
            except Exception: pass

    # -------- folder state helpers (uidvalidity tracking) ----------------

    def get_uidvalidity(self, account: str, folder: str) -> Optional[int]:
        try:
            row = self._reader_conn().execute(
                "SELECT uidvalidity FROM folder_state WHERE account=? AND folder=?",
                (account, folder)
            ).fetchone()
            return row[0] if row else None
        except sqlite3.Error:
            return None

    def set_uidvalidity(self, account: str, folder: str, uidv: int):
        self._wq.put(("set_uidv", account, folder, uidv))

    def wipe_folder(self, account: str, folder: str):
        self._wq.put(("wipe_folder", account, folder))


# =============================================================================
# Address book
# =============================================================================

@dataclass
class Contact:
    email: str = ""
    name: str = ""
    notes: str = ""
    freq: int = 1            # how often we've seen this address
    last_seen: str = ""      # ISO timestamp string

    def display(self) -> str:
        """Render as 'Name <email>' or just the email if no name."""
        n = (self.name or "").strip()
        if n:
            return f"{n} <{self.email}>"
        return self.email


class AddressBook:
    """SQLite-backed contacts store. Lives in the same DB file as the message
    cache. Email is the primary key (case-insensitive).

    Same concurrency model as MessageCache: WAL mode, persistent writer
    connection, per-thread reader connections, no Python lock. Auto-collection
    (`see`/`see_many`) is fire-and-forget — writes are enqueued and the caller
    returns immediately, so receiving a message body never blocks the GUI on a
    SQLite commit."""

    _SHUTDOWN = object()

    def __init__(self, path: Path):
        self.path = path
        self._init_schema_and_wal()
        self._tls = threading.local()
        self._wq: "queue.Queue[Any]" = queue.Queue()
        self._writer = threading.Thread(target=self._writer_loop,
                                        daemon=True, name="AddressBook-writer")
        self._writer.start()

    def _init_schema_and_wal(self):
        c = sqlite3.connect(str(self.path), timeout=10)
        try:
            c.execute("PRAGMA journal_mode=WAL")
            c.execute("PRAGMA synchronous=NORMAL")
            c.execute("""
                CREATE TABLE IF NOT EXISTS contacts (
                    email TEXT PRIMARY KEY COLLATE NOCASE,
                    name TEXT NOT NULL DEFAULT '',
                    notes TEXT NOT NULL DEFAULT '',
                    freq INTEGER NOT NULL DEFAULT 1,
                    last_seen TEXT NOT NULL DEFAULT ''
                )
            """)
            c.execute("CREATE INDEX IF NOT EXISTS idx_contacts_freq "
                      "ON contacts(freq DESC)")
            c.commit()
        finally:
            c.close()

    def _reader_conn(self) -> sqlite3.Connection:
        conn = getattr(self._tls, "conn", None)
        if conn is None:
            conn = sqlite3.connect(str(self.path), timeout=5)
            conn.row_factory = sqlite3.Row
            self._tls.conn = conn
        return conn

    @staticmethod
    def _split_addr(s: str) -> Tuple[str, str]:
        if not s:
            return ("", "")
        name, em = email.utils.parseaddr(s)
        return (name.strip(), em.strip().lower())

    # -------- public read API (synchronous) ------------------------------

    def list_all(self, query: str = "") -> List[Contact]:
        q = (query or "").strip().lower()
        try:
            conn = self._reader_conn()
            if q:
                like = f"%{q}%"
                rows = conn.execute(
                    "SELECT * FROM contacts WHERE email LIKE ? OR name LIKE ? "
                    "ORDER BY freq DESC, name COLLATE NOCASE",
                    (like, like)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM contacts ORDER BY freq DESC, name COLLATE NOCASE"
                ).fetchall()
        except sqlite3.Error as e:
            print(f"AddressBook.list_all: {e}", file=sys.stderr)
            return []
        return [Contact(email=r["email"], name=r["name"] or "",
                        notes=r["notes"] or "", freq=r["freq"] or 1,
                        last_seen=r["last_seen"] or "") for r in rows]

    def get(self, em: str) -> Optional[Contact]:
        em = (em or "").strip().lower()
        if not em:
            return None
        try:
            r = self._reader_conn().execute(
                "SELECT * FROM contacts WHERE email=?", (em,)
            ).fetchone()
        except sqlite3.Error:
            return None
        if not r:
            return None
        return Contact(email=r["email"], name=r["name"] or "",
                       notes=r["notes"] or "", freq=r["freq"] or 1,
                       last_seen=r["last_seen"] or "")

    # -------- public write API (async) -----------------------------------

    def see(self, raw_addr: str, *, prefer_existing_name: bool = False):
        """Record a sighting. Returns immediately; the actual SQLite write
        happens on the writer thread."""
        name, em = self._split_addr(raw_addr)
        if not em or "@" not in em:
            return
        self._wq.put(("see", em, name, prefer_existing_name))

    def see_many(self, raw_addrs: List[str]):
        for s in raw_addrs:
            self.see(s)

    def upsert(self, ct: Contact):
        em = (ct.email or "").strip().lower()
        if not em:
            return
        self._wq.put(("upsert", em, ct.name, ct.notes, ct.freq or 1,
                      ct.last_seen or ""))

    def delete(self, em: str):
        em = (em or "").strip().lower()
        if not em:
            return
        self._wq.put(("delete", em))

    def shutdown(self, timeout: float = 2.0):
        try:
            self._wq.put(self._SHUTDOWN)
            self._writer.join(timeout=timeout)
        except Exception:
            pass

    # -------- writer thread ---------------------------------------------

    def _writer_loop(self):
        try:
            conn = sqlite3.connect(str(self.path), timeout=10)
        except sqlite3.Error as e:
            print(f"AddressBook writer: failed to open: {e}", file=sys.stderr)
            return
        try:
            while True:
                item = self._wq.get()
                if item is self._SHUTDOWN:
                    break
                try:
                    op = item[0]
                    if op == "see":
                        _, em, name, prefer_existing_name = item
                        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
                        row = conn.execute(
                            "SELECT name FROM contacts WHERE email=?", (em,)
                        ).fetchone()
                        if row is None:
                            conn.execute(
                                "INSERT INTO contacts(email, name, freq, last_seen) "
                                "VALUES (?, ?, 1, ?)", (em, name, now)
                            )
                        else:
                            existing_name = row[0] or ""
                            new_name = existing_name
                            # Keep an existing curated name unless the new one
                            # is non-empty AND we don't have one yet.
                            if name and (not existing_name or not prefer_existing_name):
                                new_name = name
                            conn.execute(
                                "UPDATE contacts SET name=?, freq=freq+1, last_seen=? "
                                "WHERE email=?", (new_name, now, em)
                            )
                    elif op == "upsert":
                        _, em, name, notes, freq, last_seen = item
                        conn.execute("""
                            INSERT INTO contacts(email, name, notes, freq, last_seen)
                            VALUES (?, ?, ?, ?, ?)
                            ON CONFLICT(email) DO UPDATE SET
                                name=excluded.name,
                                notes=excluded.notes
                        """, (em, name, notes, freq, last_seen))
                    elif op == "delete":
                        _, em = item
                        conn.execute("DELETE FROM contacts WHERE email=?", (em,))
                    conn.commit()
                except Exception as e:
                    print(f"AddressBook writer: {e}", file=sys.stderr)
        finally:
            try: conn.close()
            except Exception: pass


# =============================================================================
# Email parsing helpers
# =============================================================================

def _decode_header(value) -> str:
    if value is None:
        return ""
    try:
        parts = email.header.decode_header(str(value))
        out = []
        for txt, enc in parts:
            if isinstance(txt, bytes):
                try:
                    out.append(txt.decode(enc or "utf-8", errors="replace"))
                except (LookupError, TypeError):
                    out.append(txt.decode("utf-8", errors="replace"))
            else:
                out.append(txt)
        return "".join(out)
    except Exception:
        return str(value)


def _parse_date(value: str) -> str:
    """Parse RFC 2822 date string -> ISO-8601 string."""
    if not value:
        return ""
    try:
        dt = email.utils.parsedate_to_datetime(value)
        if dt is None:
            return ""
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.isoformat()
    except Exception:
        return value


def _format_date_short(iso: str) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso)
        # If today, show time. Otherwise show short date.
        now = datetime.now(timezone.utc) if dt.tzinfo else datetime.now()
        if dt.date() == now.date():
            return dt.strftime("%H:%M")
        if dt.year == now.year:
            return dt.strftime("%b %d")
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return iso[:10]


def _parse_message_bytes(raw: bytes) -> dict:
    """Turn raw RFC822 bytes into a dict with extracted bits."""
    msg = email.message_from_bytes(raw, policy=email.policy.default)

    text_body = ""
    html_body = ""
    attachments = []  # list of (filename, content_type, bytes)

    for part in msg.walk():
        if part.is_multipart():
            continue
        ctype = part.get_content_type()
        cdisp = str(part.get("Content-Disposition", "")).lower()
        filename = part.get_filename()
        if filename:
            filename = _decode_header(filename)
        if "attachment" in cdisp or filename:
            try:
                payload = part.get_payload(decode=True) or b""
            except Exception:
                payload = b""
            attachments.append((filename or "attachment.bin", ctype, payload))
            continue
        try:
            payload = part.get_content()
        except Exception:
            try:
                payload_bytes = part.get_payload(decode=True) or b""
                charset = part.get_content_charset() or "utf-8"
                payload = payload_bytes.decode(charset, errors="replace")
            except Exception:
                payload = ""
        if not isinstance(payload, str):
            try:
                payload = payload.decode("utf-8", errors="replace")
            except Exception:
                payload = str(payload)
        if ctype == "text/plain" and not text_body:
            text_body = payload
        elif ctype == "text/html" and not html_body:
            html_body = payload

    return {
        "msg_id": _decode_header(msg.get("Message-ID", "")),
        "from_addr": _decode_header(msg.get("From", "")),
        "to_addrs": _decode_header(msg.get("To", "")),
        "cc_addrs": _decode_header(msg.get("Cc", "")),
        "subject": _decode_header(msg.get("Subject", "")),
        "date_iso": _parse_date(msg.get("Date", "")),
        "body_text": text_body,
        "body_html": html_body,
        "has_attachments": bool(attachments),
        "attachments": attachments,
        "raw": raw,
    }


def _parse_envelope_only(raw: bytes) -> dict:
    """Cheaper parse for list view - headers only."""
    try:
        msg = email.message_from_bytes(raw, policy=email.policy.default)
    except Exception:
        return {}
    return {
        "msg_id": _decode_header(msg.get("Message-ID", "")),
        "from_addr": _decode_header(msg.get("From", "")),
        "to_addrs": _decode_header(msg.get("To", "")),
        "subject": _decode_header(msg.get("Subject", "")),
        "date_iso": _parse_date(msg.get("Date", "")),
    }


# =============================================================================
# IMAP client
# =============================================================================

# Match: (\HasNoChildren) "/" "INBOX"   or   (\HasChildren) "." INBOX.Sent
_LIST_RE = re.compile(
    rb'\((?P<flags>[^)]*)\)\s+(?:"(?P<delim>[^"]*)"|NIL)\s+(?P<name>"[^"]+"|\S+)\s*$'
)


class ImapClient(QObject):
    """Threaded IMAP wrapper. Each public method spawns a daemon thread that
    grabs the per-account lock and emits results via signals."""

    folders_ready = pyqtSignal(str, list)                 # account_email, [(name, flags), ...]
    folder_status = pyqtSignal(str, str, int, int)        # account, folder, total, unseen
    headers_ready = pyqtSignal(str, str, list)            # account, folder, [header_dict]
    message_ready = pyqtSignal(str, str, int, dict)       # account, folder, uid, message_dict
    error_occurred = pyqtSignal(str, str)                 # account, error
    status = pyqtSignal(str)
    connected_changed = pyqtSignal(str, bool)             # account, ok
    idle_change = pyqtSignal(str, str)                    # account, folder (a change was pushed)
    idle_supported = pyqtSignal(str, bool)                # account, server supports IDLE
    search_results = pyqtSignal(str, str, str, list)      # account, folder, query, [header_dict]

    def __init__(self):
        super().__init__()
        self._conns: Dict[str, imaplib.IMAP4] = {}
        self._locks: Dict[str, threading.Lock] = {}
        self._accounts: Dict[str, Account] = {}
        # IDLE state — separate connection per account so it doesn't block the main one.
        self._idle_threads: Dict[str, threading.Thread] = {}
        self._idle_stops: Dict[str, threading.Event] = {}

    # -- public API -----------------------------------------------------------

    def register(self, acc: Account):
        self._accounts[acc.email_addr] = acc
        self._locks.setdefault(acc.email_addr, threading.Lock())

    def unregister(self, email_addr: str):
        self.stop_idle(email_addr)
        self._accounts.pop(email_addr, None)
        self._locks.pop(email_addr, None)
        self._close(email_addr)

    def connect(self, acc: Account):
        self.register(acc)
        threading.Thread(target=self._do_connect, args=(acc,), daemon=True).start()

    def list_folders(self, acc: Account):
        threading.Thread(target=self._do_list_folders, args=(acc,), daemon=True).start()

    def select_folder(self, acc: Account, folder: str, limit: int = 100):
        threading.Thread(target=self._do_select, args=(acc, folder, limit), daemon=True).start()

    def search_folder(self, acc: Account, folder: str, query: str, limit: int = 500):
        """Server-side IMAP SEARCH TEXT. Emits search_results."""
        threading.Thread(
            target=self._do_search, args=(acc, folder, query, limit), daemon=True
        ).start()

    def fetch_message(self, acc: Account, folder: str, uid: int):
        threading.Thread(target=self._do_fetch, args=(acc, folder, uid), daemon=True).start()

    def mark_seen(self, acc: Account, folder: str, uid: int, seen: bool = True):
        threading.Thread(target=self._do_mark_seen,
                         args=(acc, folder, uid, seen), daemon=True).start()

    def delete_message(self, acc: Account, folder: str, uid: int):
        threading.Thread(target=self._do_delete, args=(acc, folder, uid), daemon=True).start()

    def start_idle(self, acc: Account, folder: str = "INBOX"):
        """Start a background IDLE listener on its own connection. No-op if already running."""
        if acc.email_addr in self._idle_threads:
            return
        stop = threading.Event()
        self._idle_stops[acc.email_addr] = stop
        t = threading.Thread(target=self._do_idle, args=(acc, folder, stop), daemon=True)
        self._idle_threads[acc.email_addr] = t
        t.start()

    def stop_idle(self, email_addr: str):
        stop = self._idle_stops.pop(email_addr, None)
        if stop:
            stop.set()
        self._idle_threads.pop(email_addr, None)

    def disconnect_all(self):
        for k in list(self._idle_stops):
            self.stop_idle(k)
        for k in list(self._conns):
            self._close(k)

    # -- internals ------------------------------------------------------------

    def _lock(self, acc: Account) -> threading.Lock:
        return self._locks.setdefault(acc.email_addr, threading.Lock())

    def _close(self, email_addr: str):
        c = self._conns.pop(email_addr, None)
        if c is None:
            return
        try:
            c.logout()
        except Exception:
            try:
                c.shutdown()
            except Exception:
                pass

    def _ensure_connected(self, acc: Account) -> imaplib.IMAP4:
        c = self._conns.get(acc.email_addr)
        if c is not None:
            try:
                # Cheap liveness check.
                c.noop()
                return c
            except Exception:
                self._close(acc.email_addr)

        ctx = _ssl_context()
        if acc.imap_ssl:
            c = imaplib.IMAP4_SSL(acc.imap_host, acc.imap_port, ssl_context=ctx, timeout=30)
        else:
            c = imaplib.IMAP4(acc.imap_host, acc.imap_port, timeout=30)
            try:
                c.starttls(ssl_context=ctx)
            except Exception:
                pass
        c.login(acc.imap_user, acc.imap_pass)
        self._conns[acc.email_addr] = c
        return c

    def _do_connect(self, acc: Account):
        with self._lock(acc):
            try:
                self.status.emit(f"Connecting to {acc.imap_host}...")
                self._ensure_connected(acc)
                self.connected_changed.emit(acc.email_addr, True)
                self.status.emit(f"Connected: {acc.email_addr}")
            except Exception as e:
                self.error_occurred.emit(acc.email_addr, f"Connect failed: {_fmt_exc(e)}")
                self.connected_changed.emit(acc.email_addr, False)
                return
        # auto-list folders right after connect
        self._do_list_folders(acc)

    def _do_list_folders(self, acc: Account):
        with self._lock(acc):
            try:
                c = self._ensure_connected(acc)
                typ, data = c.list()
                if typ != "OK":
                    self.error_occurred.emit(acc.email_addr, f"LIST failed: {typ}")
                    return
                folders = []
                for row in data:
                    if not row:
                        continue
                    if isinstance(row, tuple):
                        # quoted strings come back as (b'flags...', b'name')
                        try:
                            line = (row[0] + b" " + row[1]).strip()
                        except Exception:
                            line = b" ".join(x for x in row if isinstance(x, (bytes, bytearray)))
                    else:
                        line = row
                    m = _LIST_RE.search(line)
                    if not m:
                        continue
                    flags = m.group("flags").decode("utf-8", errors="replace")
                    name_raw = m.group("name")
                    if name_raw.startswith(b'"') and name_raw.endswith(b'"'):
                        name_raw = name_raw[1:-1]
                    try:
                        name = imaplib.IMAP4._decode(c, name_raw) if hasattr(imaplib.IMAP4, "_decode") else name_raw.decode("utf-8", errors="replace")
                    except Exception:
                        name = name_raw.decode("utf-8", errors="replace")
                    # Skip noselect folders
                    if "\\Noselect" in flags or "\\NonExistent" in flags:
                        continue
                    folders.append((name, flags))
                self.folders_ready.emit(acc.email_addr, folders)
            except Exception as e:
                self.error_occurred.emit(acc.email_addr, f"List folders failed: {e}")

    def _do_select(self, acc: Account, folder: str, limit: int):
        with self._lock(acc):
            try:
                c = self._ensure_connected(acc)
                # Encode folder name for IMAP UTF-7 if needed; for now assume ASCII.
                typ, data = c.select(self._quote_folder(folder), readonly=False)
                if typ != "OK":
                    self.error_occurred.emit(acc.email_addr, f"SELECT {folder}: {typ}")
                    return
                total = int(data[0]) if data and data[0] else 0

                # Get UIDVALIDITY for cache invalidation.
                typ, data = c.response("UIDVALIDITY")
                uidv = None
                if data and data[0]:
                    try:
                        uidv = int(data[0])
                    except Exception:
                        uidv = None

                # Search all UIDs.
                typ, data = c.uid("SEARCH", None, "ALL")
                if typ != "OK":
                    self.headers_ready.emit(acc.email_addr, folder, [])
                    return
                uids = data[0].split() if data and data[0] else []
                # Newest first; cap at limit.
                uids = [int(u) for u in uids]
                uids.sort(reverse=True)
                uids = uids[:limit]

                if not uids:
                    self.headers_ready.emit(acc.email_addr, folder, [])
                    self.folder_status.emit(acc.email_addr, folder, total, 0)
                    return

                # Fetch envelope/flags in one batch.
                seq = ",".join(str(u) for u in uids)
                typ, data = c.uid(
                    "FETCH", seq,
                    "(UID FLAGS RFC822.SIZE BODY.PEEK[HEADER.FIELDS (FROM TO CC SUBJECT DATE MESSAGE-ID IN-REPLY-TO REFERENCES)])"
                )
                if typ != "OK":
                    self.error_occurred.emit(acc.email_addr, f"FETCH headers failed: {typ}")
                    return

                headers = self._parse_fetch_headers(data)
                # Re-sort newest first by date if we have it.
                self.headers_ready.emit(acc.email_addr, folder, headers)

                unseen = sum(1 for h in headers if not h.get("seen"))
                self.folder_status.emit(acc.email_addr, folder, total, unseen)
            except Exception as e:
                tb = traceback.format_exc()
                self.error_occurred.emit(acc.email_addr, f"Select {folder} failed: {e}\n{tb}")

    def _do_fetch(self, acc: Account, folder: str, uid: int):
        with self._lock(acc):
            try:
                c = self._ensure_connected(acc)
                typ, _ = c.select(self._quote_folder(folder), readonly=False)
                if typ != "OK":
                    self.error_occurred.emit(acc.email_addr, f"SELECT {folder} failed")
                    return
                typ, data = c.uid("FETCH", str(uid), "(RFC822 FLAGS)")
                if typ != "OK" or not data or not data[0]:
                    self.error_occurred.emit(acc.email_addr, f"FETCH UID {uid} failed")
                    return
                raw = b""
                flags = ""
                for item in data:
                    if isinstance(item, tuple):
                        meta = item[0].decode("utf-8", errors="replace") if isinstance(item[0], (bytes, bytearray)) else str(item[0])
                        raw = item[1] if isinstance(item[1], (bytes, bytearray)) else b""
                        mflags = re.search(r"FLAGS \(([^)]*)\)", meta)
                        if mflags:
                            flags = mflags.group(1)
                parsed = _parse_message_bytes(raw)
                parsed["seen"] = "\\Seen" in flags
                parsed["flagged"] = "\\Flagged" in flags
                self.message_ready.emit(acc.email_addr, folder, uid, parsed)
            except Exception as e:
                self.error_occurred.emit(acc.email_addr, f"Fetch UID {uid} failed: {e}")

    def _do_mark_seen(self, acc: Account, folder: str, uid: int, seen: bool):
        with self._lock(acc):
            try:
                c = self._ensure_connected(acc)
                c.select(self._quote_folder(folder), readonly=False)
                cmd = "+FLAGS" if seen else "-FLAGS"
                c.uid("STORE", str(uid), cmd, "(\\Seen)")
            except Exception as e:
                self.error_occurred.emit(acc.email_addr, f"Mark seen failed: {e}")

    def _do_delete(self, acc: Account, folder: str, uid: int):
        with self._lock(acc):
            try:
                c = self._ensure_connected(acc)
                c.select(self._quote_folder(folder), readonly=False)
                # Try moving to Trash via MOVE; fall back to copy+delete.
                trash = self._accounts.get(acc.email_addr).trash_folder if self._accounts.get(acc.email_addr) else "Trash"
                moved = False
                try:
                    typ, _ = c.uid("MOVE", str(uid), self._quote_folder(trash))
                    moved = (typ == "OK")
                except Exception:
                    moved = False
                if not moved:
                    try:
                        c.uid("COPY", str(uid), self._quote_folder(trash))
                    except Exception:
                        pass
                    c.uid("STORE", str(uid), "+FLAGS", "(\\Deleted)")
                    c.expunge()
            except Exception as e:
                self.error_occurred.emit(acc.email_addr, f"Delete failed: {e}")

    def _do_search(self, acc: Account, folder: str, query: str, limit: int):
        """Server-side IMAP SEARCH TEXT. Headers for matching UIDs are emitted via search_results."""
        with self._lock(acc):
            try:
                c = self._ensure_connected(acc)
                typ, _ = c.select(self._quote_folder(folder), readonly=True)
                if typ != "OK":
                    self.error_occurred.emit(acc.email_addr, f"SELECT {folder}: {typ}")
                    return

                q = (query or "").strip()
                if not q:
                    self.search_results.emit(acc.email_addr, folder, query, [])
                    return

                # IMAP requires the search string to be a quoted string or a
                # literal. Quote it (escape backslash and dquote per RFC 3501).
                quoted = '"' + q.replace('\\', '\\\\').replace('"', '\\"') + '"'
                ascii_only = all(ord(ch) < 128 for ch in q)

                typ, data = (None, None)
                if ascii_only:
                    # Plain quoted ASCII works on every server.
                    typ, data = c.uid("SEARCH", "TEXT", quoted)
                else:
                    # Non-ASCII: try CHARSET UTF-8 with quoted form, then fall
                    # back to literal continuation, then to bare TEXT.
                    try:
                        c.literal = q.encode("utf-8")
                        typ, data = c.uid("SEARCH", "CHARSET", "UTF-8", "TEXT")
                    except Exception:
                        try:
                            typ, data = c.uid("SEARCH", "CHARSET", "UTF-8",
                                              "TEXT", quoted)
                        except Exception:
                            typ, data = c.uid("SEARCH", "TEXT", quoted)

                if typ != "OK":
                    self.error_occurred.emit(acc.email_addr,
                                             f"SEARCH failed: {typ} {data}")
                    return
                uids = data[0].split() if data and data[0] else []
                if not uids:
                    self.search_results.emit(acc.email_addr, folder, query, [])
                    return
                uids = [int(u) for u in uids]
                uids.sort(reverse=True)
                uids = uids[:limit]

                seq = ",".join(str(u) for u in uids)
                typ, data = c.uid(
                    "FETCH", seq,
                    "(UID FLAGS RFC822.SIZE BODY.PEEK[HEADER.FIELDS (FROM TO CC SUBJECT DATE MESSAGE-ID IN-REPLY-TO REFERENCES)])"
                )
                if typ != "OK":
                    self.error_occurred.emit(acc.email_addr, f"FETCH (search) failed: {typ}")
                    return
                headers = self._parse_fetch_headers(data)
                self.search_results.emit(acc.email_addr, folder, query, headers)
            except Exception as e:
                self.error_occurred.emit(acc.email_addr, f"Search failed: {_fmt_exc(e)}")

    def _do_idle(self, acc: Account, folder: str, stop: threading.Event):
        """Push-notification listener using IMAP IDLE on a dedicated connection.
        Reconnects with backoff on failure. Emits idle_change on EXISTS/EXPUNGE/FETCH pushes."""
        backoff = 5
        while not stop.is_set():
            c = None
            try:
                ctx = _ssl_context()
                if acc.imap_ssl:
                    c = imaplib.IMAP4_SSL(acc.imap_host, acc.imap_port, ssl_context=ctx, timeout=30)
                else:
                    c = imaplib.IMAP4(acc.imap_host, acc.imap_port, timeout=30)
                    try:
                        c.starttls(ssl_context=ctx)
                    except Exception:
                        pass
                c.login(acc.imap_user, acc.imap_pass)

                # CAPABILITY check.
                typ, data = c.capability()
                caps = b" ".join(data).upper() if (typ == "OK" and data) else b""
                if b"IDLE" not in caps:
                    self.idle_supported.emit(acc.email_addr, False)
                    try: c.logout()
                    except Exception: pass
                    return

                self.idle_supported.emit(acc.email_addr, True)
                typ, _ = c.select(self._quote_folder(folder), readonly=True)
                if typ != "OK":
                    raise RuntimeError(f"IDLE select {folder} failed")

                backoff = 5  # reset after successful connect

                # Outer loop: re-issue IDLE every ~28 minutes (RFC 2177 recommends < 30).
                while not stop.is_set():
                    tag = c._new_tag()
                    if isinstance(tag, str):
                        tag_b = tag.encode("ascii")
                    else:
                        tag_b = tag
                    try:
                        c.send(tag_b + b" IDLE\r\n")
                    except Exception:
                        break

                    # Wait for "+ idling" continuation.
                    line = c.readline()
                    if not line.startswith(b"+"):
                        # Server didn't accept IDLE for some reason — bail and reconnect.
                        break

                    idle_started = time.monotonic()
                    got_change = False
                    # Use short socket timeouts so we can poll the stop event.
                    try:
                        c.sock.settimeout(5.0)
                    except Exception:
                        pass

                    while not stop.is_set():
                        if time.monotonic() - idle_started > 28 * 60:
                            break  # renew idle

                        try:
                            resp = c.readline()
                        except (socket.timeout, OSError):
                            continue
                        if not resp:
                            # Connection closed by server.
                            raise RuntimeError("IDLE connection closed")

                        # Untagged push notifications.
                        upper = resp.upper()
                        if (b"EXISTS" in upper) or (b"EXPUNGE" in upper) or \
                           (b"FETCH" in upper and b"FLAGS" in upper):
                            got_change = True
                            # Don't break — let any other pushed lines arrive too.

                    # Send DONE to leave IDLE.
                    try:
                        c.sock.settimeout(30.0)
                    except Exception:
                        pass
                    try:
                        c.send(b"DONE\r\n")
                        # Drain until tagged response.
                        while True:
                            line = c.readline()
                            if not line:
                                break
                            if line.startswith(tag_b):
                                break
                    except Exception:
                        break

                    if got_change and not stop.is_set():
                        self.idle_change.emit(acc.email_addr, folder)

                # Clean exit.
                try: c.logout()
                except Exception: pass
                return

            except Exception as e:
                if not stop.is_set():
                    self.error_occurred.emit(acc.email_addr, f"IDLE: {e}")
                try:
                    if c is not None: c.shutdown()
                except Exception:
                    pass
                # Backoff with stop-event polling.
                wait = min(backoff, 300)
                for _ in range(wait):
                    if stop.is_set(): return
                    time.sleep(1)
                backoff = min(backoff * 2, 300)

    @staticmethod
    def _quote_folder(name: str) -> str:
        if " " in name or '"' in name:
            return '"' + name.replace('"', '\\"') + '"'
        return name

    @staticmethod
    def _parse_fetch_headers(data) -> List[dict]:
        """Parse the response from FETCH ... (UID FLAGS BODY.PEEK[HEADER.FIELDS ...])."""
        headers = []
        for item in data:
            if not isinstance(item, tuple):
                continue
            meta_b, hdr_b = item[0], item[1]
            if not isinstance(meta_b, (bytes, bytearray)):
                continue
            meta = meta_b.decode("utf-8", errors="replace")
            uid_m = re.search(r"UID (\d+)", meta)
            if not uid_m:
                continue
            uid = int(uid_m.group(1))
            flags_m = re.search(r"FLAGS \(([^)]*)\)", meta)
            flags = flags_m.group(1) if flags_m else ""

            try:
                msg = email.message_from_bytes(hdr_b, policy=email.policy.default)
            except Exception:
                msg = None
            headers.append({
                "uid": uid,
                "from_addr": _decode_header(msg.get("From", "")) if msg else "",
                "to_addrs": _decode_header(msg.get("To", "")) if msg else "",
                "subject": _decode_header(msg.get("Subject", "")) if msg else "",
                "date_iso": _parse_date(msg.get("Date", "")) if msg else "",
                "msg_id": _decode_header(msg.get("Message-ID", "")) if msg else "",
                "in_reply_to": _decode_header(msg.get("In-Reply-To", "")) if msg else "",
                "references": _decode_header(msg.get("References", "")) if msg else "",
                "seen": "\\Seen" in flags,
                "flagged": "\\Flagged" in flags,
                "answered": "\\Answered" in flags,
            })
        # newest first by date if parseable
        def _key(h):
            try:
                return datetime.fromisoformat(h["date_iso"])
            except Exception:
                return datetime.min.replace(tzinfo=timezone.utc)
        headers.sort(key=_key, reverse=True)
        return headers


# =============================================================================
# SMTP client
# =============================================================================

class SmtpClient(QObject):
    sent = pyqtSignal(str, str)            # account, message_id
    error_occurred = pyqtSignal(str, str)
    status = pyqtSignal(str)

    def send(self, acc: Account, to_addrs: List[str], cc_addrs: List[str],
             bcc_addrs: List[str], subject: str, body_text: str, body_html: str,
             attachments: List[Tuple[str, bytes]],
             in_reply_to: str = "", references: str = "") -> None:
        threading.Thread(
            target=self._do_send,
            args=(acc, to_addrs, cc_addrs, bcc_addrs, subject, body_text, body_html,
                  attachments, in_reply_to, references),
            daemon=True
        ).start()

    def _do_send(self, acc, to_addrs, cc_addrs, bcc_addrs, subject,
                 body_text, body_html, attachments, in_reply_to, references):
        try:
            self.status.emit(f"Sending via {acc.smtp_host}...")
            msg = MIMEMultipart("mixed") if attachments else MIMEMultipart("alternative")
            from_addr = email.utils.formataddr((acc.real_name, acc.email_addr)) \
                if acc.real_name else acc.email_addr
            msg["From"] = from_addr
            msg["To"] = ", ".join(to_addrs)
            if cc_addrs:
                msg["Cc"] = ", ".join(cc_addrs)
            msg["Subject"] = subject
            msg["Date"] = email.utils.formatdate(localtime=True)
            msg_id = email.utils.make_msgid(domain=acc.email_addr.split("@")[-1])
            msg["Message-ID"] = msg_id
            if in_reply_to:
                msg["In-Reply-To"] = in_reply_to
            if references:
                msg["References"] = references

            if attachments:
                alt = MIMEMultipart("alternative")
                alt.attach(MIMEText(body_text or "", "plain", "utf-8"))
                if body_html:
                    alt.attach(MIMEText(body_html, "html", "utf-8"))
                msg.attach(alt)
                for filename, data in attachments:
                    ctype, enc = mimetypes.guess_type(filename)
                    if ctype is None or enc is not None:
                        ctype = "application/octet-stream"
                    maintype, subtype = ctype.split("/", 1)
                    part = MIMEBase(maintype, subtype)
                    part.set_payload(data)
                    email_encoders.encode_base64(part)
                    part.add_header("Content-Disposition", "attachment", filename=filename)
                    msg.attach(part)
            else:
                msg.attach(MIMEText(body_text or "", "plain", "utf-8"))
                if body_html:
                    msg.attach(MIMEText(body_html, "html", "utf-8"))

            ctx = _ssl_context()
            recipients = list(to_addrs) + list(cc_addrs) + list(bcc_addrs)

            if acc.smtp_ssl:
                with smtplib.SMTP_SSL(acc.smtp_host, acc.smtp_port,
                                      context=ctx, timeout=30) as s:
                    s.login(acc.smtp_user, acc.smtp_pass)
                    s.send_message(msg, from_addr=acc.email_addr, to_addrs=recipients)
            else:
                with smtplib.SMTP(acc.smtp_host, acc.smtp_port, timeout=30) as s:
                    s.ehlo()
                    if acc.smtp_starttls:
                        s.starttls(context=ctx)
                        s.ehlo()
                    s.login(acc.smtp_user, acc.smtp_pass)
                    s.send_message(msg, from_addr=acc.email_addr, to_addrs=recipients)

            self.sent.emit(acc.email_addr, msg_id)
            self.status.emit("Message sent.")
        except Exception as e:
            self.error_occurred.emit(acc.email_addr, f"Send failed: {e}")


# =============================================================================
# Theme / Stylesheet
# =============================================================================

DARK_QSS = """
* {
    color: #e0e0e0;
    selection-background-color: #660000;
    selection-color: #ffffff;
}

QMainWindow, QDialog, QWidget {
    background-color: #0d0d0d;
}

QToolBar {
    background-color: #141414;
    border: 0px;
    spacing: 4px;
    padding: 4px;
}

QToolBar QToolButton, QToolBar QPushButton {
    background-color: #1a1a1a;
    border: 1px solid #2a2a2a;
    padding: 6px 10px;
    color: #e0e0e0;
}
QToolBar QToolButton:hover, QToolBar QPushButton:hover {
    background-color: #2a0000;
    border-color: #aa0000;
    color: #ff4040;
}
QToolBar QToolButton:disabled, QToolBar QPushButton:disabled {
    color: #555555;
}

QStatusBar {
    background-color: #141414;
    border-top: 1px solid #2a2a2a;
}

QMenuBar {
    background-color: #141414;
}
QMenuBar::item:selected {
    background-color: #2a0000;
    color: #ff4040;
}
QMenu {
    background-color: #141414;
    border: 1px solid #2a2a2a;
}
QMenu::item:selected {
    background-color: #660000;
    color: #ffffff;
}

QLineEdit, QTextEdit, QTextBrowser {
    background-color: #141414;
    border: 1px solid #2a2a2a;
    color: #e0e0e0;
    selection-background-color: #660000;
    selection-color: #ffffff;
    padding: 4px;
}
QLineEdit:focus, QTextEdit:focus {
    border: 1px solid #aa0000;
}

QPushButton {
    background-color: #1a1a1a;
    border: 1px solid #2a2a2a;
    color: #e0e0e0;
    padding: 6px 14px;
}
QPushButton:hover {
    background-color: #2a0000;
    border-color: #aa0000;
    color: #ff4040;
}
QPushButton:pressed {
    background-color: #aa0000;
    color: #ffffff;
}
QPushButton:disabled {
    color: #555555;
    background-color: #141414;
}

QComboBox, QSpinBox {
    background-color: #141414;
    border: 1px solid #2a2a2a;
    padding: 4px;
}
QComboBox QAbstractItemView {
    background-color: #141414;
    selection-background-color: #660000;
    border: 1px solid #2a2a2a;
}

QCheckBox {
    spacing: 6px;
}

QTreeWidget, QListWidget, QTableView {
    background-color: #0d0d0d;
    alternate-background-color: #141414;
    border: 1px solid #2a2a2a;
    color: #e0e0e0;
    selection-background-color: #660000;
    selection-color: #ffffff;
    outline: 0;
}
QTreeWidget::item, QListWidget::item {
    padding: 4px;
}
QTreeWidget::item:selected, QListWidget::item:selected {
    background-color: #660000;
    color: #ffffff;
}
QHeaderView::section {
    background-color: #1a1a1a;
    color: #cc0000;
    border: 0px;
    border-right: 1px solid #2a2a2a;
    padding: 6px;
    font-weight: bold;
}

QSplitter::handle {
    background-color: #1a1a1a;
}
QSplitter::handle:horizontal { width: 2px; }
QSplitter::handle:vertical { height: 2px; }

QScrollBar:vertical {
    background: #0d0d0d;
    width: 12px;
    margin: 0px;
    border: 0px;
}
QScrollBar::handle:vertical {
    background: #2a2a2a;
    min-height: 20px;
}
QScrollBar::handle:vertical:hover {
    background: #aa0000;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QScrollBar:horizontal {
    background: #0d0d0d;
    height: 12px;
    margin: 0px;
}
QScrollBar::handle:horizontal {
    background: #2a2a2a;
    min-width: 20px;
}
QScrollBar::handle:horizontal:hover {
    background: #aa0000;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0px;
}

QGroupBox {
    border: 1px solid #2a2a2a;
    margin-top: 12px;
    padding-top: 8px;
    color: #cc0000;
    font-weight: bold;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
}

QTabWidget::pane {
    border: 1px solid #2a2a2a;
    background-color: #0d0d0d;
}
QTabBar::tab {
    background-color: #141414;
    color: #888;
    padding: 6px 12px;
    border: 1px solid #2a2a2a;
    border-bottom: 0;
}
QTabBar::tab:selected {
    background-color: #0d0d0d;
    color: #cc0000;
    border-color: #aa0000;
}

QProgressBar {
    background-color: #141414;
    border: 1px solid #2a2a2a;
    text-align: center;
}
QProgressBar::chunk {
    background-color: #aa0000;
}

QLabel[role="title"] {
    color: #cc0000;
    font-weight: bold;
    font-size: 14px;
}
QLabel[role="warning"] {
    color: #ff4040;
}
"""


# =============================================================================
# Account dialog
# =============================================================================

class AccountDialog(QDialog):
    """Add or edit an account. Includes a 'Test connection' button that
    actually tries IMAP login + SMTP login (synchronously, on a worker thread)."""

    def __init__(self, parent=None, account: Optional[Account] = None):
        super().__init__(parent)
        self.setWindowTitle("Account")
        self.setMinimumWidth(560)
        self.setMinimumHeight(480)
        self.resize(620, 720)
        self.account = account or Account()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        outer.addWidget(scroll, 1)

        content = QWidget()
        scroll.setWidget(content)
        layout = QVBoxLayout(content)
        layout.setContentsMargins(12, 12, 12, 12)

        ident = QGroupBox("Identity")
        ident_form = QFormLayout(ident)
        self.le_name = QLineEdit(self.account.name)
        self.le_real = QLineEdit(self.account.real_name)
        self.le_email = QLineEdit(self.account.email_addr)
        self.le_sig = QTextEdit()
        self.le_sig.setPlainText(self.account.signature)
        self.le_sig.setMaximumHeight(80)
        ident_form.addRow("Display name:", self.le_name)
        ident_form.addRow("Your name:", self.le_real)
        ident_form.addRow("Email address:", self.le_email)
        ident_form.addRow("Signature:", self.le_sig)
        # Provider hint that updates as the user types.
        self.lbl_provider_hint = QLabel("")
        self.lbl_provider_hint.setTextFormat(Qt.TextFormat.RichText)
        self.lbl_provider_hint.setOpenExternalLinks(True)
        self.lbl_provider_hint.setWordWrap(True)
        self.lbl_provider_hint.setStyleSheet("color: #ffaa00; padding-top: 4px;")
        self.lbl_provider_hint.setVisible(False)
        ident_form.addRow("", self.lbl_provider_hint)
        layout.addWidget(ident)

        imap_box = QGroupBox("Incoming (IMAP)")
        imap_form = QFormLayout(imap_box)
        self.le_imap_host = QLineEdit(self.account.imap_host)
        self.sp_imap_port = QSpinBox(); self.sp_imap_port.setRange(1, 65535)
        self.sp_imap_port.setValue(self.account.imap_port)
        self.cb_imap_ssl = QCheckBox("SSL/TLS"); self.cb_imap_ssl.setChecked(self.account.imap_ssl)
        self.le_imap_user = QLineEdit(self.account.imap_user)
        self.le_imap_pass = QLineEdit(self.account.imap_pass)
        self.le_imap_pass.setEchoMode(QLineEdit.EchoMode.Password)
        imap_form.addRow("Server:", self.le_imap_host)
        imap_form.addRow("Port:", self.sp_imap_port)
        imap_form.addRow("Security:", self.cb_imap_ssl)
        imap_form.addRow("Username:", self.le_imap_user)
        imap_form.addRow("Password:", self.le_imap_pass)
        layout.addWidget(imap_box)

        smtp_box = QGroupBox("Outgoing (SMTP)")
        smtp_form = QFormLayout(smtp_box)
        self.le_smtp_host = QLineEdit(self.account.smtp_host)
        self.sp_smtp_port = QSpinBox(); self.sp_smtp_port.setRange(1, 65535)
        self.sp_smtp_port.setValue(self.account.smtp_port)
        self.cmb_smtp_sec = QComboBox()
        self.cmb_smtp_sec.addItems(["SSL/TLS (implicit)", "STARTTLS", "None (not recommended)"])
        if self.account.smtp_ssl:
            self.cmb_smtp_sec.setCurrentIndex(0)
        elif self.account.smtp_starttls:
            self.cmb_smtp_sec.setCurrentIndex(1)
        else:
            self.cmb_smtp_sec.setCurrentIndex(2)
        self.le_smtp_user = QLineEdit(self.account.smtp_user)
        self.le_smtp_pass = QLineEdit(self.account.smtp_pass)
        self.le_smtp_pass.setEchoMode(QLineEdit.EchoMode.Password)
        smtp_form.addRow("Server:", self.le_smtp_host)
        smtp_form.addRow("Port:", self.sp_smtp_port)
        smtp_form.addRow("Security:", self.cmb_smtp_sec)
        smtp_form.addRow("Username:", self.le_smtp_user)
        smtp_form.addRow("Password:", self.le_smtp_pass)
        layout.addWidget(smtp_box)

        folders_box = QGroupBox("Special folders")
        folders_form = QFormLayout(folders_box)
        self.le_sent = QLineEdit(self.account.sent_folder)
        self.le_drafts = QLineEdit(self.account.drafts_folder)
        self.le_trash = QLineEdit(self.account.trash_folder)
        folders_form.addRow("Sent:", self.le_sent)
        folders_form.addRow("Drafts:", self.le_drafts)
        folders_form.addRow("Trash:", self.le_trash)
        layout.addWidget(folders_box)

        # Security / show-password row
        sec_box = QGroupBox("Security")
        sec_layout = QVBoxLayout(sec_box)

        ps = password_store()
        backend_color = {"keyring": "#7fff7f", "fernet": "#ffaa00", "base64": "#ff4040"}.get(
            ps.backend, "#888"
        )
        backend_pretty = {
            "keyring": "OS keyring (encrypted)",
            "fernet": "Fernet AES (encrypted, key on disk)",
            "base64": "base64 obfuscation (NOT encrypted — install 'keyring' or 'cryptography' for real encryption)",
        }.get(ps.backend, ps.backend_note)
        lbl_backend = QLabel(f"Password storage: <span style='color:{backend_color};'>{backend_pretty}</span>")
        lbl_backend.setTextFormat(Qt.TextFormat.RichText)
        lbl_backend.setWordWrap(True)
        sec_layout.addWidget(lbl_backend)

        self.cb_show_pw = QCheckBox("Show passwords")
        self.cb_show_pw.toggled.connect(self._on_toggle_show_pw)
        sec_layout.addWidget(self.cb_show_pw)

        warn = QLabel(
            "Tip: most providers (Gmail, Yahoo, iCloud, Fastmail, Outlook with MFA) "
            "require an <b>app-specific password</b> rather than your account password."
        )
        warn.setTextFormat(Qt.TextFormat.RichText)
        warn.setProperty("role", "warning")
        warn.setWordWrap(True)
        sec_layout.addWidget(warn)
        layout.addWidget(sec_box)
        layout.addStretch()

        # Button row: outside the scroll area so OK/Cancel are always visible.
        btn_row_widget = QFrame()
        btn_row_widget.setStyleSheet("background-color: #141414; border-top: 1px solid #2a2a2a;")
        btn_row = QHBoxLayout(btn_row_widget)
        btn_row.setContentsMargins(12, 8, 12, 8)
        self.btn_test = QPushButton("Test Connection")
        self.btn_test.clicked.connect(self._on_test)
        btn_row.addWidget(self.btn_test)
        btn_row.addStretch()
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        btn_row.addWidget(bb)
        outer.addWidget(btn_row_widget)

        # Auto-fill SMTP user from email if blank.
        self.le_email.editingFinished.connect(self._auto_fill)
        self.le_email.textChanged.connect(self._update_provider_hint)
        self.le_imap_user.editingFinished.connect(self._auto_fill_smtp_user)
        self._update_provider_hint(self.le_email.text())

    PROVIDER_HINTS = {
        "gmail.com": (
            "<b>Gmail</b> requires an <b>app password</b> (not your account password). "
            "Generate one at <a href='https://myaccount.google.com/apppasswords'>"
            "myaccount.google.com/apppasswords</a> "
            "(2-Step Verification must be on first). "
            "Also enable IMAP at <a href='https://mail.google.com'>mail.google.com</a> → "
            "Settings → Forwarding and POP/IMAP."
        ),
        "googlemail.com": "see gmail.com",  # alias resolved below
        "yahoo.com": (
            "<b>Yahoo</b> requires an app password. Generate one at "
            "<a href='https://login.yahoo.com/account/security'>"
            "login.yahoo.com/account/security</a> → Generate app password."
        ),
        "icloud.com": (
            "<b>iCloud</b> requires an app-specific password. Create one at "
            "<a href='https://appleid.apple.com'>appleid.apple.com</a> → "
            "Sign-In and Security → App-Specific Passwords."
        ),
        "outlook.com": (
            "<b>Outlook</b> with MFA enabled requires an app password "
            "(<a href='https://account.microsoft.com/security'>account.microsoft.com → Security</a> "
            "→ Advanced security options)."
        ),
        "hotmail.com": "see outlook.com",
        "live.com": "see outlook.com",
        "fastmail.com": (
            "<b>Fastmail</b> requires an app password "
            "(<a href='https://app.fastmail.com/settings/security/devices'>"
            "Settings → Privacy & Security → App passwords</a>)."
        ),
        "mailfence.com": (
            "<b>Mailfence</b> IMAP/SMTP requires a paid plan. Free accounts are "
            "webmail-only. If you have a paid plan with 2FA, generate an app "
            "password in Account → Security."
        ),
        "proton.me": (
            "<b>Proton Mail</b> requires the <b>Proton Bridge</b> running locally. "
            "Bridge proxies on 127.0.0.1 and gives you per-app credentials — use "
            "those, not your Proton account password."
        ),
        "protonmail.com": "see proton.me",
    }

    def _update_provider_hint(self, text: str = ""):
        em = (text or self.le_email.text()).strip()
        domain = em.split("@", 1)[-1].lower() if "@" in em else ""
        hint = self.PROVIDER_HINTS.get(domain, "")
        # Resolve aliases ("see other.com")
        if hint.startswith("see "):
            hint = self.PROVIDER_HINTS.get(hint[4:].strip(), "")
        if hint:
            self.lbl_provider_hint.setText(hint)
            self.lbl_provider_hint.setVisible(True)
        else:
            self.lbl_provider_hint.setVisible(False)

    def _auto_fill(self):
        em = self.le_email.text().strip()
        if not em:
            return
        if not self.le_imap_user.text():
            self.le_imap_user.setText(em)
        if not self.le_smtp_user.text():
            self.le_smtp_user.setText(em)
        # Try to guess servers from common providers.
        domain = em.split("@", 1)[-1].lower() if "@" in em else ""
        # Each entry: (imap_host, smtp_host, smtp_security_index)
        # smtp_security_index: 0 = SSL/TLS implicit (port 465), 1 = STARTTLS (port 587)
        guesses = {
            "gmail.com":      ("imap.gmail.com",        "smtp.gmail.com",        0),
            "googlemail.com": ("imap.gmail.com",        "smtp.gmail.com",        0),
            "outlook.com":    ("outlook.office365.com", "smtp.office365.com",    1),
            "hotmail.com":    ("outlook.office365.com", "smtp.office365.com",    1),
            "live.com":       ("outlook.office365.com", "smtp.office365.com",    1),
            "yahoo.com":      ("imap.mail.yahoo.com",   "smtp.mail.yahoo.com",   0),
            "icloud.com":     ("imap.mail.me.com",      "smtp.mail.me.com",      1),
            "fastmail.com":   ("imap.fastmail.com",     "smtp.fastmail.com",     0),
            "mailfence.com":  ("imap.mailfence.com",    "smtp.mailfence.com",    0),
            "proton.me":      ("127.0.0.1",             "127.0.0.1",             0),
            "protonmail.com": ("127.0.0.1",             "127.0.0.1",             0),
        }
        if domain in guesses and not self.le_imap_host.text():
            imap_host, smtp_host, smtp_sec = guesses[domain]
            self.le_imap_host.setText(imap_host)
            self.le_smtp_host.setText(smtp_host)
            # Set ports to match the security mode.
            self.sp_imap_port.setValue(993)
            self.cb_imap_ssl.setChecked(True)
            if smtp_sec == 1:  # STARTTLS
                self.sp_smtp_port.setValue(587)
                self.cmb_smtp_sec.setCurrentIndex(1)
            else:  # SSL/TLS
                self.sp_smtp_port.setValue(465)
                self.cmb_smtp_sec.setCurrentIndex(0)

    def _auto_fill_smtp_user(self):
        if not self.le_smtp_user.text():
            self.le_smtp_user.setText(self.le_imap_user.text())

    def _on_toggle_show_pw(self, checked: bool):
        mode = QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password
        self.le_imap_pass.setEchoMode(mode)
        self.le_smtp_pass.setEchoMode(mode)

    @staticmethod
    def _missing_fields(a: Account) -> List[str]:
        out = []
        if not a.email_addr:  out.append("Email address")
        if not a.imap_host:   out.append("IMAP server")
        if not a.imap_user:   out.append("IMAP username")
        if not a.imap_pass:   out.append("IMAP password")
        if not a.smtp_host:   out.append("SMTP server")
        if not a.smtp_user:   out.append("SMTP username")
        if not a.smtp_pass:   out.append("SMTP password")
        return out

    def get_account(self) -> Account:
        a = self.account
        a.name = self.le_name.text().strip() or self.le_email.text().strip()
        a.real_name = self.le_real.text().strip()
        a.email_addr = self.le_email.text().strip()
        a.signature = self.le_sig.toPlainText()

        a.imap_host = self.le_imap_host.text().strip()
        a.imap_port = self.sp_imap_port.value()
        a.imap_ssl = self.cb_imap_ssl.isChecked()
        a.imap_user = self.le_imap_user.text().strip()
        # Strip ws — common copy-paste hazard with Gmail app passwords (Google
        # displays them in 4-char groups separated by spaces; the actual password
        # has no leading/trailing whitespace).
        a.imap_pass = self.le_imap_pass.text().strip()

        a.smtp_host = self.le_smtp_host.text().strip()
        a.smtp_port = self.sp_smtp_port.value()
        sec = self.cmb_smtp_sec.currentIndex()
        a.smtp_ssl = (sec == 0)
        a.smtp_starttls = (sec == 1)
        a.smtp_user = self.le_smtp_user.text().strip()
        a.smtp_pass = self.le_smtp_pass.text().strip()

        a.sent_folder = self.le_sent.text().strip() or "Sent"
        a.drafts_folder = self.le_drafts.text().strip() or "Drafts"
        a.trash_folder = self.le_trash.text().strip() or "Trash"
        return a

    def _on_test(self):
        a = self.get_account()
        missing = self._missing_fields(a)
        if missing:
            QMessageBox.warning(
                self, "Test",
                "Fill in these fields first:\n\n• " + "\n• ".join(missing)
            )
            return
        self.btn_test.setEnabled(False)
        self.btn_test.setText("Testing...")

        results: Dict[str, Any] = {"imap": None, "smtp": None}

        def worker():
            # ------- IMAP -------
            stage = "connect"
            try:
                ctx = _ssl_context()
                if a.imap_ssl:
                    stage = f"connect (IMAP4_SSL {a.imap_host}:{a.imap_port})"
                    c = imaplib.IMAP4_SSL(a.imap_host, a.imap_port,
                                          ssl_context=ctx, timeout=20)
                else:
                    stage = f"connect (IMAP4 {a.imap_host}:{a.imap_port})"
                    c = imaplib.IMAP4(a.imap_host, a.imap_port, timeout=20)
                    try:
                        stage = "STARTTLS"
                        c.starttls(ssl_context=ctx)
                    except Exception as e:
                        results["imap"] = ("FAIL", stage, type(e).__name__, str(e))
                        raise
                stage = "login"
                c.login(a.imap_user, a.imap_pass)
                stage = "logout"
                try: c.logout()
                except Exception: pass
                results["imap"] = ("OK", "", "", "")
            except imaplib.IMAP4.error as e:
                # imaplib raises this for AUTHENTICATIONFAILED, etc.
                results["imap"] = ("FAIL", stage, "IMAP4.error", str(e))
            except ssl.SSLError as e:
                results["imap"] = ("FAIL", stage, "SSLError", str(e))
            except socket.gaierror as e:
                results["imap"] = ("FAIL", stage, "DNS lookup",
                                   f"Could not resolve '{a.imap_host}': {e}")
            except (TimeoutError, socket.timeout) as e:
                results["imap"] = ("FAIL", stage, "Timeout",
                                   f"Connection to {a.imap_host}:{a.imap_port} timed out")
            except (ConnectionRefusedError, OSError) as e:
                if results.get("imap") is None:
                    results["imap"] = ("FAIL", stage, type(e).__name__, str(e))
            except Exception as e:
                if results.get("imap") is None:
                    results["imap"] = ("FAIL", stage, type(e).__name__, str(e))

            # ------- SMTP -------
            stage = "connect"
            try:
                ctx = _ssl_context()
                if a.smtp_ssl:
                    stage = f"connect (SMTP_SSL {a.smtp_host}:{a.smtp_port})"
                    s = smtplib.SMTP_SSL(a.smtp_host, a.smtp_port,
                                         context=ctx, timeout=20)
                else:
                    stage = f"connect (SMTP {a.smtp_host}:{a.smtp_port})"
                    s = smtplib.SMTP(a.smtp_host, a.smtp_port, timeout=20)
                    s.ehlo()
                    if a.smtp_starttls:
                        stage = "STARTTLS"
                        s.starttls(context=ctx)
                        s.ehlo()
                stage = "login"
                s.login(a.smtp_user, a.smtp_pass)
                stage = "quit"
                try: s.quit()
                except Exception: pass
                results["smtp"] = ("OK", "", "", "")
            except smtplib.SMTPAuthenticationError as e:
                results["smtp"] = ("FAIL", stage, "SMTPAuthenticationError",
                                   f"{e.smtp_code}: {e.smtp_error.decode('utf-8', 'replace') if isinstance(e.smtp_error, bytes) else e.smtp_error}")
            except smtplib.SMTPException as e:
                results["smtp"] = ("FAIL", stage, type(e).__name__, str(e))
            except ssl.SSLError as e:
                results["smtp"] = ("FAIL", stage, "SSLError", str(e))
            except socket.gaierror as e:
                results["smtp"] = ("FAIL", stage, "DNS lookup",
                                   f"Could not resolve '{a.smtp_host}': {e}")
            except (TimeoutError, socket.timeout) as e:
                results["smtp"] = ("FAIL", stage, "Timeout",
                                   f"Connection to {a.smtp_host}:{a.smtp_port} timed out")
            except (ConnectionRefusedError, OSError) as e:
                if results.get("smtp") is None:
                    results["smtp"] = ("FAIL", stage, type(e).__name__, str(e))
            except Exception as e:
                if results.get("smtp") is None:
                    results["smtp"] = ("FAIL", stage, type(e).__name__, str(e))

            QTimer.singleShot(0, lambda: self._show_test_result(results, a))

        threading.Thread(target=worker, daemon=True).start()

    def _show_test_result(self, results: Dict[str, Any], a: Account):
        self.btn_test.setEnabled(True)
        self.btn_test.setText("Test Connection")

        def fmt(label: str, r):
            if r is None:
                return f"{label}: ?"
            status, stage, etype, emsg = r
            if status == "OK":
                return f"{label}: OK"
            return f"{label}: FAIL at {stage}\n  {etype}: {emsg}"

        body = fmt("IMAP", results.get("imap")) + "\n\n" + fmt("SMTP", results.get("smtp"))

        # Reuse the shared hint generator so Test Connection and connect-failure
        # popups give the same advice.
        hints = _auth_hints(body, a.email_addr)
        if hints:
            body += "\n\nHints:\n• " + "\n• ".join(hints)

        any_fail = any(r and r[0] == "FAIL" for r in results.values())
        if any_fail:
            QMessageBox.critical(self, "Test Connection", body)
        else:
            QMessageBox.information(self, "Test Connection", body)


# =============================================================================
# Compose window
# =============================================================================

class MultiAddressCompleter(QCompleter):
    """QCompleter that completes the *last* comma-separated token of a
    QLineEdit, instead of treating the whole field as one search term.

    On selection, it replaces only the last token with the picked entry and
    appends ', ' so the user can keep typing the next address."""

    def __init__(self, book: AddressBook, parent=None):
        super().__init__(parent)
        self.book = book
        self._refresh_model()

    def _refresh_model(self):
        contacts = self.book.list_all()
        # Use 'Name <email>' as the completion string so name-search works.
        items: List[str] = []
        for ct in contacts:
            items.append(ct.display())
        self.setModel(QStringListModel(items, self))

    def splitPath(self, path: str) -> List[str]:
        # We only care about the part after the last comma.
        last = path.rsplit(",", 1)[-1].lstrip()
        return [last]

    def pathFromIndex(self, index) -> str:
        # Reconstruct the full field with the picked completion in place of
        # the last token.
        chosen = super().pathFromIndex(index)
        widget = self.widget()
        prefix = ""
        if isinstance(widget, QLineEdit):
            full = widget.text()
            if "," in full:
                prefix = full.rsplit(",", 1)[0].rstrip() + ", "
        return prefix + chosen


class ComposeWindow(QDialog):
    def __init__(self, parent, accounts: List[Account], smtp: SmtpClient,
                 default_account: Optional[Account] = None,
                 reply_to: Optional[dict] = None,
                 forward_of: Optional[dict] = None,
                 address_book: Optional[AddressBook] = None):
        super().__init__(parent)
        self.setWindowTitle("Compose - Email of Death")
        self.resize(800, 600)
        self.accounts = accounts
        self.smtp = smtp
        self.address_book = address_book
        self.attachments: List[Tuple[str, bytes]] = []  # (filename, raw)
        self.in_reply_to = ""
        self.references = ""

        layout = QVBoxLayout(self)

        form = QFormLayout()
        self.cmb_from = QComboBox()
        for a in accounts:
            label = f"{a.real_name} <{a.email_addr}>" if a.real_name else a.email_addr
            self.cmb_from.addItem(label, userData=a.email_addr)
        if default_account:
            for i in range(self.cmb_from.count()):
                if self.cmb_from.itemData(i) == default_account.email_addr:
                    self.cmb_from.setCurrentIndex(i)
                    break
        form.addRow("From:", self.cmb_from)

        self.le_to = QLineEdit()
        self.le_cc = QLineEdit()
        self.le_bcc = QLineEdit()
        self.le_subj = QLineEdit()
        # Address book autocomplete on the recipient fields. Custom completer
        # so it works for *each* address in a comma-separated list.
        if self.address_book is not None:
            for le in (self.le_to, self.le_cc, self.le_bcc):
                self._install_address_completer(le)
        form.addRow("To:", self.le_to)
        form.addRow("Cc:", self.le_cc)
        form.addRow("Bcc:", self.le_bcc)
        form.addRow("Subject:", self.le_subj)
        layout.addLayout(form)

        # Attachments row
        att_row = QHBoxLayout()
        self.lbl_attach = QLabel("No attachments.")
        self.lbl_attach.setProperty("role", "warning")
        self.lbl_attach.setStyleSheet("color: #888;")
        btn_attach = QPushButton("Attach...")
        btn_attach.clicked.connect(self._on_attach)
        btn_clear = QPushButton("Clear attachments")
        btn_clear.clicked.connect(self._on_clear_attach)
        att_row.addWidget(btn_attach)
        att_row.addWidget(btn_clear)
        att_row.addWidget(self.lbl_attach, 1)
        layout.addLayout(att_row)

        # Format toolbar (HTML compose).
        self.fmt_bar = QToolBar("Format")
        self.fmt_bar.setIconSize(QSize(18, 18))
        self.fmt_bar.setStyleSheet(
            "QToolBar { background-color: #141414; border-bottom: 1px solid #2a2a2a; }"
            "QToolButton { color: #e0e0e0; padding: 4px 8px; }"
            "QToolButton:checked { background-color: #2a0000; color: #ff4040; }"
        )

        self.act_html = QAction("HTML", self)
        self.act_html.setCheckable(True)
        self.act_html.setChecked(True)
        self.act_html.setToolTip("Compose as HTML (uncheck for plain text)")
        self.act_html.toggled.connect(self._on_toggle_html)
        self.fmt_bar.addAction(self.act_html)
        self.fmt_bar.addSeparator()

        self.act_bold = QAction("B", self); self.act_bold.setCheckable(True)
        f = self.act_bold.font(); f.setBold(True); self.act_bold.setFont(f)
        self.act_bold.setShortcut(QKeySequence.StandardKey.Bold)
        self.act_bold.triggered.connect(self._on_bold)
        self.fmt_bar.addAction(self.act_bold)

        self.act_italic = QAction("I", self); self.act_italic.setCheckable(True)
        f = self.act_italic.font(); f.setItalic(True); self.act_italic.setFont(f)
        self.act_italic.setShortcut(QKeySequence.StandardKey.Italic)
        self.act_italic.triggered.connect(self._on_italic)
        self.fmt_bar.addAction(self.act_italic)

        self.act_underline = QAction("U", self); self.act_underline.setCheckable(True)
        f = self.act_underline.font(); f.setUnderline(True); self.act_underline.setFont(f)
        self.act_underline.setShortcut(QKeySequence.StandardKey.Underline)
        self.act_underline.triggered.connect(self._on_underline)
        self.fmt_bar.addAction(self.act_underline)

        self.fmt_bar.addSeparator()

        act_ul = QAction("• List", self)
        act_ul.triggered.connect(lambda: self._insert_list(QTextListFormat.Style.ListDisc))
        self.fmt_bar.addAction(act_ul)

        act_ol = QAction("1. List", self)
        act_ol.triggered.connect(lambda: self._insert_list(QTextListFormat.Style.ListDecimal))
        self.fmt_bar.addAction(act_ol)

        self.fmt_bar.addSeparator()

        act_link = QAction("Link", self)
        act_link.triggered.connect(self._insert_link)
        self.fmt_bar.addAction(act_link)

        layout.addWidget(self.fmt_bar)

        self.te_body = QTextEdit()
        self.te_body.setAcceptRichText(True)
        self.te_body.cursorPositionChanged.connect(self._sync_format_state)
        layout.addWidget(self.te_body, 1)

        # Buttons
        btns = QHBoxLayout()
        btns.addStretch()
        self.btn_send = QPushButton("Send")
        self.btn_send.clicked.connect(self._on_send)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        btns.addWidget(self.btn_send)
        btns.addWidget(self.btn_cancel)
        layout.addLayout(btns)

        # Pre-fill for reply / forward
        if reply_to:
            self._populate_reply(reply_to, default_account)
        elif forward_of:
            self._populate_forward(forward_of, default_account)
        else:
            # Insert signature
            if default_account and default_account.signature:
                self.te_body.setPlainText("\n\n-- \n" + default_account.signature)

        self.smtp.sent.connect(self._on_sent)
        self.smtp.error_occurred.connect(self._on_send_error)

    # ---------- attachments ----------
    def _on_attach(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Attach files")
        for f in files:
            try:
                p = Path(f)
                self.attachments.append((p.name, p.read_bytes()))
            except Exception as e:
                QMessageBox.warning(self, "Attach", f"Failed to read {f}: {e}")
        self._refresh_attach_label()

    def _on_clear_attach(self):
        self.attachments.clear()
        self._refresh_attach_label()

    def _refresh_attach_label(self):
        if not self.attachments:
            self.lbl_attach.setText("No attachments.")
        else:
            total = sum(len(d) for _, d in self.attachments)
            self.lbl_attach.setText(
                f"{len(self.attachments)} attachment(s), {total // 1024} KB"
            )

    # ---------- reply / forward population ----------
    def _populate_reply(self, msg: dict, default_account: Optional[Account]):
        from_addr = msg.get("from_addr", "")
        subj = msg.get("subject", "")
        if not subj.lower().startswith("re:"):
            subj = "Re: " + subj
        self.le_subj.setText(subj)
        # Reply-To if present in raw, else From
        self.le_to.setText(from_addr)
        self.in_reply_to = msg.get("msg_id", "")
        self.references = msg.get("msg_id", "")
        quote = self._build_quote(msg)
        sig = ""
        if default_account and default_account.signature:
            sig = "\n\n-- \n" + default_account.signature
        self.te_body.setPlainText("\n\n" + quote + sig)
        cur = self.te_body.textCursor()
        cur.movePosition(cur.MoveOperation.Start)
        self.te_body.setTextCursor(cur)

    def _populate_forward(self, msg: dict, default_account: Optional[Account]):
        subj = msg.get("subject", "")
        if not subj.lower().startswith("fwd:"):
            subj = "Fwd: " + subj
        self.le_subj.setText(subj)
        quote = self._build_forward(msg)
        sig = ""
        if default_account and default_account.signature:
            sig = "\n\n-- \n" + default_account.signature
        self.te_body.setPlainText("\n\n" + quote + sig)
        # Carry original attachments through
        for fname, ctype, data in msg.get("attachments", []) or []:
            self.attachments.append((fname, data))
        self._refresh_attach_label()

    @staticmethod
    def _build_quote(msg: dict) -> str:
        date = msg.get("date_iso", "")
        sender = msg.get("from_addr", "")
        body = msg.get("body_text", "") or _strip_html(msg.get("body_html", ""))
        quoted = "\n".join("> " + line for line in body.splitlines())
        return f"On {date}, {sender} wrote:\n{quoted}\n"

    @staticmethod
    def _build_forward(msg: dict) -> str:
        body = msg.get("body_text", "") or _strip_html(msg.get("body_html", ""))
        header = (
            "---------- Forwarded message ----------\n"
            f"From: {msg.get('from_addr', '')}\n"
            f"Date: {msg.get('date_iso', '')}\n"
            f"Subject: {msg.get('subject', '')}\n"
            f"To: {msg.get('to_addrs', '')}\n\n"
        )
        return header + body + "\n"

    # ---------- send ----------
    def _on_send(self):
        em = self.cmb_from.currentData()
        acc = next((a for a in self.accounts if a.email_addr == em), None)
        if not acc:
            QMessageBox.warning(self, "Send", "No account selected.")
            return
        to = _split_addrs(self.le_to.text())
        cc = _split_addrs(self.le_cc.text())
        bcc = _split_addrs(self.le_bcc.text())
        if not to and not cc and not bcc:
            QMessageBox.warning(self, "Send", "Add at least one recipient.")
            return
        subj = self.le_subj.text()
        body_text = self.te_body.toPlainText()
        if self.act_html.isChecked():
            body_html = self.te_body.toHtml()
        else:
            body_html = ""

        # Auto-collect every recipient into the address book before send.
        if self.address_book is not None:
            try:
                self.address_book.see_many(to + cc + bcc)
            except Exception:
                pass

        self.btn_send.setEnabled(False)
        self.btn_send.setText("Sending...")
        self.smtp.send(acc, to, cc, bcc, subj, body_text, body_html, self.attachments,
                       in_reply_to=self.in_reply_to,
                       references=self.references)

    def _install_address_completer(self, le: QLineEdit):
        """Wire a multi-address-aware QCompleter to a recipient line edit.
        Completes the address after the last comma so 'a@x.com, fo' offers
        completions for 'fo' against the address book."""
        completer = MultiAddressCompleter(self.address_book, le)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        completer.setFilterMode(Qt.MatchFlag.MatchContains)
        completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        le.setCompleter(completer)

    # ---------- formatting ----------
    def _on_toggle_html(self, checked: bool):
        # Switching to plain: flatten content to plain text. Switching to HTML: leave as-is.
        if not checked:
            text = self.te_body.toPlainText()
            self.te_body.setAcceptRichText(False)
            self.te_body.setPlainText(text)
        else:
            self.te_body.setAcceptRichText(True)
        for a in (self.act_bold, self.act_italic, self.act_underline):
            a.setEnabled(checked)

    def _on_bold(self):
        if not self.act_html.isChecked(): return
        fmt = QTextCharFormat()
        cur = self.te_body.textCursor()
        weight = QFont.Weight.Bold if not cur.charFormat().font().bold() else QFont.Weight.Normal
        fmt.setFontWeight(weight)
        self._merge_format(fmt)

    def _on_italic(self):
        if not self.act_html.isChecked(): return
        fmt = QTextCharFormat()
        cur = self.te_body.textCursor()
        fmt.setFontItalic(not cur.charFormat().fontItalic())
        self._merge_format(fmt)

    def _on_underline(self):
        if not self.act_html.isChecked(): return
        fmt = QTextCharFormat()
        cur = self.te_body.textCursor()
        fmt.setFontUnderline(not cur.charFormat().fontUnderline())
        self._merge_format(fmt)

    def _merge_format(self, fmt: QTextCharFormat):
        cur = self.te_body.textCursor()
        if not cur.hasSelection():
            cur.select(cur.SelectionType.WordUnderCursor)
        cur.mergeCharFormat(fmt)
        self.te_body.mergeCurrentCharFormat(fmt)

    def _insert_list(self, style):
        if not self.act_html.isChecked(): return
        cur = self.te_body.textCursor()
        lf = QTextListFormat()
        lf.setStyle(style)
        cur.createList(lf)

    def _insert_link(self):
        if not self.act_html.isChecked():
            QMessageBox.information(self, "Link", "Switch to HTML mode to insert links.")
            return
        cur = self.te_body.textCursor()
        default = cur.selectedText() if cur.hasSelection() else ""
        url, ok = QInputDialog.getText(self, "Insert link", "URL:", text=default or "https://")
        if not ok or not url:
            return
        text, ok = QInputDialog.getText(self, "Insert link", "Display text:",
                                        text=default or url)
        if not ok:
            return
        text = text or url
        cur.insertHtml(f'<a href="{html_escape(url)}" style="color:#ff4040;">{html_escape(text)}</a>')

    def _sync_format_state(self):
        if not self.act_html.isChecked():
            return
        fmt = self.te_body.currentCharFormat()
        self.act_bold.setChecked(fmt.font().bold())
        self.act_italic.setChecked(fmt.fontItalic())
        self.act_underline.setChecked(fmt.fontUnderline())

    @pyqtSlot(str, str)
    def _on_sent(self, account_email: str, msg_id: str):
        em = self.cmb_from.currentData()
        if account_email != em:
            return
        QMessageBox.information(self, "Sent", "Message delivered.")
        self.accept()

    @pyqtSlot(str, str)
    def _on_send_error(self, account_email: str, err: str):
        em = self.cmb_from.currentData()
        if account_email != em:
            return
        self.btn_send.setEnabled(True)
        self.btn_send.setText("Send")
        QMessageBox.critical(self, "Send failed", err)


def _split_addrs(s: str) -> List[str]:
    if not s.strip():
        return []
    parts = re.split(r"[,;]+", s)
    return [p.strip() for p in parts if p.strip()]


def _strip_html(html: str) -> str:
    if not html:
        return ""
    doc = QTextDocument()
    doc.setHtml(html)
    return doc.toPlainText()


# =============================================================================
# Folder Tree
# =============================================================================

# Identify special folder types from server flags or names.
_SPECIAL_BY_FLAG = {
    "\\Inbox": "inbox",
    "\\Sent": "sent",
    "\\Drafts": "drafts",
    "\\Trash": "trash",
    "\\Junk": "junk",
    "\\Archive": "archive",
    "\\All": "all",
    "\\Important": "important",
    "\\Flagged": "flagged",
}

_SPECIAL_BY_NAME = {
    # English
    "inbox": "inbox", "sent": "sent", "sent items": "sent", "sent mail": "sent",
    "drafts": "drafts", "draft": "drafts",
    "trash": "trash", "deleted": "trash", "deleted items": "trash",
    "deleted messages": "trash", "bin": "trash",
    "junk": "junk", "spam": "junk", "junk e-mail": "junk", "junk email": "junk",
    "archive": "archive", "all mail": "all",
    # German (IONOS / 1&1 / web.de / GMX often use these)
    "papierkorb":  "trash",
    "gesendet":    "sent",
    "entwürfe":    "drafts",
    "entwurfe":    "drafts",
    "werbung":     "junk",
    "spam-verdacht": "junk",
    # French
    "corbeille":   "trash",
    "envoyé":      "sent",   "envoyés": "sent", "envoye": "sent",
    "brouillons":  "drafts",
    "indésirables": "junk",  "indesirables": "junk",
    # Spanish
    "papelera":    "trash",
    "enviados":    "sent",
    "borradores":  "drafts",
    "no deseado":  "junk",
    # Italian
    "cestino":     "trash",
    "inviata":     "sent", "posta inviata": "sent",
    "bozze":       "drafts",
    "indesiderata": "junk", "posta indesiderata": "junk",
    # Portuguese
    "lixeira":     "trash", "lixo": "trash",
    "enviadas":    "sent",
    "rascunhos":   "drafts",
    # Dutch
    "prullenbak":  "trash",
    "verzonden":   "sent",
    "concepten":   "drafts",
    "ongewenste":  "junk",
}


def folder_kind(name: str, flags: str) -> str:
    for f, k in _SPECIAL_BY_FLAG.items():
        if f in flags:
            return k
    short = name.split("/")[-1].split(".")[-1].lower().strip()
    return _SPECIAL_BY_NAME.get(short, "folder")


_KIND_PRIORITY = {
    "inbox": 0, "drafts": 1, "sent": 2, "archive": 3,
    "junk": 4, "trash": 5, "all": 6, "flagged": 7, "important": 8,
    "folder": 9,
}


# =============================================================================
# Address book dialogs
# =============================================================================

class ContactEditDialog(QDialog):
    """Tiny dialog to add or edit a single contact (name, email, notes)."""

    def __init__(self, parent, ct: Contact, is_new: bool = False):
        super().__init__(parent)
        self.setWindowTitle("New Contact" if is_new else "Edit Contact")
        self.setMinimumWidth(420)
        self.contact = Contact(email=ct.email, name=ct.name, notes=ct.notes,
                               freq=ct.freq, last_seen=ct.last_seen)
        self._is_new = is_new

        layout = QFormLayout(self)
        self.le_name = QLineEdit(self.contact.name)
        self.le_email = QLineEdit(self.contact.email)
        if not is_new:
            # Editing — don't let the user change the primary key.
            self.le_email.setReadOnly(True)
            self.le_email.setStyleSheet("color: #888;")
        self.te_notes = QTextEdit()
        self.te_notes.setPlainText(self.contact.notes)
        self.te_notes.setMaximumHeight(120)
        layout.addRow("Name:", self.le_name)
        layout.addRow("Email:", self.le_email)
        layout.addRow("Notes:", self.te_notes)

        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self._accept)
        bb.rejected.connect(self.reject)
        layout.addRow(bb)

    def _accept(self):
        em = self.le_email.text().strip().lower()
        if not em or "@" not in em:
            QMessageBox.warning(self, "Save", "Email address is required.")
            return
        self.contact.email = em
        self.contact.name = self.le_name.text().strip()
        self.contact.notes = self.te_notes.toPlainText().strip()
        self.accept()


class AddressBookDialog(QDialog):
    """Browse, search, add, edit, delete contacts."""

    def __init__(self, parent, book: AddressBook):
        super().__init__(parent)
        self.setWindowTitle("Address Book")
        self.resize(720, 480)
        self.book = book

        layout = QVBoxLayout(self)

        # Search bar
        sr = QHBoxLayout()
        self.le_search = QLineEdit()
        self.le_search.setPlaceholderText("Search contacts...")
        self.le_search.setClearButtonEnabled(True)
        self.le_search.textChanged.connect(self._refresh)
        sr.addWidget(self.le_search, 1)
        layout.addLayout(sr)

        # Body: list on left, buttons on right
        body = QHBoxLayout()
        self.model = QStandardItemModel(0, 3, self)
        self.model.setHorizontalHeaderLabels(["Name", "Email", "Seen"])
        self.view = QTreeView()
        self.view.setModel(self.model)
        self.view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.view.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.view.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.view.setRootIsDecorated(False)
        self.view.setAlternatingRowColors(True)
        self.view.setSortingEnabled(True)
        h = self.view.header()
        h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.view.setColumnWidth(0, 220)
        self.view.setColumnWidth(1, 320)
        self.view.setColumnWidth(2, 80)
        self.view.doubleClicked.connect(self._on_edit)
        body.addWidget(self.view, 1)

        col = QVBoxLayout()
        btn_add = QPushButton("Add")
        btn_edit = QPushButton("Edit")
        btn_remove = QPushButton("Remove")
        btn_close = QPushButton("Close")
        btn_add.clicked.connect(self._on_add)
        btn_edit.clicked.connect(self._on_edit)
        btn_remove.clicked.connect(self._on_remove)
        btn_close.clicked.connect(self.accept)
        col.addWidget(btn_add)
        col.addWidget(btn_edit)
        col.addWidget(btn_remove)
        col.addStretch()
        col.addWidget(btn_close)
        body.addLayout(col)

        layout.addLayout(body, 1)
        self._refresh()

    def _refresh(self):
        self.model.removeRows(0, self.model.rowCount())
        for ct in self.book.list_all(self.le_search.text()):
            n = QStandardItem(ct.name or "")
            e = QStandardItem(ct.email)
            f = QStandardItem(str(ct.freq))
            f.setData(ct.freq, Qt.ItemDataRole.UserRole)
            n.setData(ct.email, Qt.ItemDataRole.UserRole)
            e.setData(ct.email, Qt.ItemDataRole.UserRole)
            self.model.appendRow([n, e, f])

    def _selected_email(self) -> str:
        idxs = self.view.selectionModel().selectedRows()
        if not idxs:
            return ""
        item = self.model.itemFromIndex(idxs[0])
        return item.data(Qt.ItemDataRole.UserRole) or ""

    def _on_add(self):
        ct = Contact()
        dlg = ContactEditDialog(self, ct, is_new=True)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.book.upsert(dlg.contact)
            self._refresh()

    def _on_edit(self):
        em = self._selected_email()
        if not em:
            return
        ct = self.book.get(em)
        if not ct:
            return
        dlg = ContactEditDialog(self, ct, is_new=False)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.book.upsert(dlg.contact)
            self._refresh()

    def _on_remove(self):
        em = self._selected_email()
        if not em:
            return
        if QMessageBox.question(
            self, "Remove",
            f"Remove {em} from address book?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        ) != QMessageBox.StandardButton.Yes:
            return
        self.book.delete(em)
        self._refresh()


# =============================================================================
# Message viewer (QTextBrowser with optional remote-content support)
# =============================================================================

class MessageBrowser(QTextBrowser):
    """QTextBrowser that can serve pre-fetched remote resources.

    QTextBrowser by default cannot load http(s) resources at all. When the user
    clicks 'Load remote content', MainWindow pre-fetches the URLs on a worker
    thread, then calls set_remote_resources() with {url: bytes}. After that,
    setHtml() will pick the bytes up via loadResource().

    URL matching uses QUrl equality so that HTML-entity differences (`&amp;`
    vs `&`) and percent-encoding variants resolve to the same resource."""

    def __init__(self, parent=None):
        super().__init__(parent)
        # We index by QUrl, which compares equal across the entity/encoding
        # variants Qt produces during HTML parsing.
        self._remote: Dict[QUrl, bytes] = {}

    def set_remote_resources(self, mapping: Dict[str, bytes]):
        self._remote = {QUrl(u): b for u, b in mapping.items() if b is not None}
        # Drop any cached resources from the document so loadResource fires fresh.
        self.document().clear()

    def clear_remote_resources(self):
        self._remote = {}

    def loadResource(self, resource_type, url):
        try:
            if url in self._remote:
                return QByteArray(self._remote[url])
            # Fall back to string match in case Qt hands us a slightly-
            # different QUrl form than what we stored.
            url_str = url.toString()
            for key, data in self._remote.items():
                if key.toString() == url_str:
                    return QByteArray(data)
        except Exception:
            pass
        return super().loadResource(resource_type, url)


# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} - {ORG_NAME}")
        self.resize(1280, 800)
        icon_path = resource_path("icon.png")
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        else:
            sp = resource_path("splash.png")
            if sp.exists():
                self.setWindowIcon(QIcon(str(sp)))

        self.cache = MessageCache(CACHE_FILE)
        self.contacts = AddressBook(CACHE_FILE)
        self.imap = ImapClient()
        self.smtp = SmtpClient()
        self.accounts: List[Account] = load_accounts()

        # state
        self.current_account: Optional[Account] = None
        self.current_folder: Optional[str] = None
        self.current_uid: Optional[int] = None
        self.headers_cache: Dict[Tuple[str, str], List[dict]] = {}
        self.allow_remote = False  # block tracking pixels by default
        self.threaded_mode = True
        self.search_active = False
        self._idle_status: Dict[str, bool] = {}  # email -> IDLE supported
        self._connect_failure_shown: Dict[str, set] = {}  # email -> bucket set
        # Status-bar throttle: coalesce rapid updates into one repaint per 100ms.
        self._status_pending: Optional[str] = None
        self._status_timer = QTimer(self)
        self._status_timer.setSingleShot(True)
        self._status_timer.setInterval(100)
        self._status_timer.timeout.connect(self._flush_status)
        # IDLE refresh debounce — Gmail can EXISTS-spam during a sync, and we
        # don't want to issue a 100-header FETCH on every push.
        self._idle_refresh_timer = QTimer(self)
        self._idle_refresh_timer.setSingleShot(True)
        self._idle_refresh_timer.setInterval(5000)
        self._idle_refresh_timer.timeout.connect(self._do_idle_refresh)

        self._build_ui()
        self._wire_signals()

        # Connect all configured accounts.
        QTimer.singleShot(50, self._connect_all)

        # Periodic refresh of currently-selected folder
        self.refresh_timer = QTimer(self)
        self.refresh_timer.setInterval(2 * 60 * 1000)  # 2 min
        self.refresh_timer.timeout.connect(self._refresh_current_folder)
        self.refresh_timer.start()

        if not self.accounts:
            QTimer.singleShot(300, self._first_run_prompt)

    # -- UI construction ------------------------------------------------------

    def _build_ui(self):
        # Toolbar
        tb = QToolBar("Main")
        tb.setMovable(False)
        tb.setIconSize(QSize(20, 20))
        self.addToolBar(tb)

        self.act_compose = QAction("New", self)
        self.act_compose.setShortcut(QKeySequence("Ctrl+N"))
        self.act_compose.triggered.connect(self._on_compose_new)
        tb.addAction(self.act_compose)

        self.act_reply = QAction("Reply", self)
        self.act_reply.setShortcut(QKeySequence("Ctrl+R"))
        self.act_reply.triggered.connect(self._on_reply)
        tb.addAction(self.act_reply)

        self.act_forward = QAction("Forward", self)
        self.act_forward.setShortcut(QKeySequence("Ctrl+Shift+F"))
        self.act_forward.triggered.connect(self._on_forward)
        tb.addAction(self.act_forward)

        tb.addSeparator()

        self.act_delete = QAction("Delete", self)
        self.act_delete.setShortcut(QKeySequence("Del"))
        self.act_delete.triggered.connect(self._on_delete)
        tb.addAction(self.act_delete)

        self.act_mark_unread = QAction("Mark unread", self)
        self.act_mark_unread.triggered.connect(self._on_mark_unread)
        tb.addAction(self.act_mark_unread)

        tb.addSeparator()

        self.act_refresh = QAction("Refresh", self)
        self.act_refresh.setShortcut(QKeySequence("F5"))
        self.act_refresh.triggered.connect(self._refresh_current_folder)
        tb.addAction(self.act_refresh)

        self.act_threaded = QAction("Threaded", self)
        self.act_threaded.setCheckable(True)
        self.act_threaded.setChecked(True)
        self.act_threaded.setToolTip("Group messages into conversation threads")
        self.act_threaded.toggled.connect(self._on_toggle_threaded)
        tb.addAction(self.act_threaded)

        self.act_focus_search = QAction("Search", self)
        self.act_focus_search.setShortcut(QKeySequence("Ctrl+F"))
        self.act_focus_search.triggered.connect(lambda: self.search_edit.setFocus())
        tb.addAction(self.act_focus_search)

        self.act_settings = QAction("Accounts...", self)
        self.act_settings.triggered.connect(self._on_manage_accounts)
        tb.addAction(self.act_settings)

        self.act_address_book = QAction("Address Book", self)
        self.act_address_book.setShortcut(QKeySequence("Ctrl+Shift+A"))
        self.act_address_book.triggered.connect(self._on_open_address_book)
        tb.addAction(self.act_address_book)

        # Menus
        mb = self.menuBar()
        m_file = mb.addMenu("&File")
        m_file.addAction(self.act_compose)
        m_file.addSeparator()
        act_quit = QAction("Quit", self)
        act_quit.setShortcut(QKeySequence("Ctrl+Q"))
        act_quit.triggered.connect(self.close)
        m_file.addAction(act_quit)

        m_msg = mb.addMenu("&Message")
        m_msg.addAction(self.act_reply)
        m_msg.addAction(self.act_forward)
        m_msg.addAction(self.act_delete)
        m_msg.addAction(self.act_mark_unread)

        m_tools = mb.addMenu("&Tools")
        m_tools.addAction(self.act_address_book)

        m_acct = mb.addMenu("&Accounts")
        m_acct.addAction(self.act_settings)

        m_help = mb.addMenu("&Help")
        act_about = QAction("About", self)
        act_about.triggered.connect(self._on_about)
        m_help.addAction(act_about)

        # Status bar
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.lbl_status = QLabel("Ready.")
        self.status.addWidget(self.lbl_status, 1)
        self.lbl_count = QLabel("")
        self.status.addPermanentWidget(self.lbl_count)

        # Splitter layout
        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.setCentralWidget(splitter)

        # Folder tree
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Folders"])
        self.tree.setMinimumWidth(140)
        self.tree.itemSelectionChanged.connect(self._on_folder_selected)
        splitter.addWidget(self.tree)

        # Message list pane: search bar + QTreeView (threaded or flat).
        msg_pane = QWidget()
        mp_layout = QVBoxLayout(msg_pane)
        mp_layout.setContentsMargins(0, 0, 0, 0); mp_layout.setSpacing(0)

        search_row = QFrame()
        search_row.setStyleSheet("background-color: #141414; border-bottom: 1px solid #2a2a2a;")
        sr = QHBoxLayout(search_row)
        sr.setContentsMargins(8, 6, 8, 6); sr.setSpacing(6)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search this folder (Ctrl+F)...")
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.returnPressed.connect(self._on_search_submit)
        self.search_edit.textChanged.connect(self._on_search_changed)
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(500)
        self._search_timer.timeout.connect(self._on_search_submit)
        sr.addWidget(self.search_edit, 1)
        self.btn_clear_search = QPushButton("Clear")
        self.btn_clear_search.clicked.connect(self._on_clear_search)
        self.btn_clear_search.setVisible(False)
        sr.addWidget(self.btn_clear_search)
        mp_layout.addWidget(search_row)

        self.msg_model = QStandardItemModel(0, 4, self)
        self.msg_model.setHorizontalHeaderLabels(["From", "Subject", "Date", ""])
        self.msg_view = QTreeView()
        self.msg_view.setModel(self.msg_model)
        self.msg_view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.msg_view.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.msg_view.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.msg_view.setRootIsDecorated(True)
        self.msg_view.setUniformRowHeights(True)
        self.msg_view.setAlternatingRowColors(True)
        self.msg_view.setAllColumnsShowFocus(True)
        self.msg_view.setExpandsOnDoubleClick(False)
        self.msg_view.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.msg_view.customContextMenuRequested.connect(self._on_msg_context_menu)
        # Larger, more readable font for the message list.
        list_font = QFont(self.msg_view.font())
        list_font.setPointSize(max(11, list_font.pointSize() + 1))
        self.msg_view.setFont(list_font)
        h = self.msg_view.header()
        # All columns user-resizable. (Previously col 1 was Stretch which made
        # it tricky to resize the others on some systems.)
        h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        h.setStretchLastSection(False)
        h.setSectionsMovable(True)
        self.msg_view.setColumnWidth(0, 260)
        self.msg_view.setColumnWidth(1, 480)
        self.msg_view.setColumnWidth(2, 130)
        self.msg_view.setColumnWidth(3, 32)
        self.msg_view.selectionModel().selectionChanged.connect(self._on_msg_selected)
        self.msg_view.doubleClicked.connect(self._on_msg_double)
        mp_layout.addWidget(self.msg_view, 1)

        splitter.addWidget(msg_pane)

        # Right pane: header + viewer
        right = QWidget()
        rl = QVBoxLayout(right); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(0)

        self.hdr_box = QFrame()
        self.hdr_box.setStyleSheet("background-color: #141414; border-bottom: 1px solid #2a2a2a;")
        hdr_layout = QVBoxLayout(self.hdr_box)
        hdr_layout.setContentsMargins(12, 8, 12, 8)
        self.lbl_subj = QLabel("")
        self.lbl_subj.setStyleSheet("color: #cc0000; font-weight: bold; font-size: 14px;")
        self.lbl_subj.setWordWrap(True)
        self.lbl_from = QLabel("")
        self.lbl_from.setStyleSheet("color: #aaa;")
        self.lbl_to = QLabel("")
        self.lbl_to.setStyleSheet("color: #888; font-size: 11px;")
        self.lbl_to.setWordWrap(True)
        self.lbl_date = QLabel("")
        self.lbl_date.setStyleSheet("color: #888; font-size: 11px;")
        hdr_layout.addWidget(self.lbl_subj)
        hdr_layout.addWidget(self.lbl_from)
        hdr_layout.addWidget(self.lbl_to)
        hdr_layout.addWidget(self.lbl_date)

        self.remote_bar = QWidget()
        rb_layout = QHBoxLayout(self.remote_bar)
        rb_layout.setContentsMargins(8, 6, 8, 6)
        rb_lbl = QLabel("Remote content blocked.")
        rb_lbl.setStyleSheet("color: #ff4040;")
        btn_load_remote = QPushButton("Load remote content")
        btn_load_remote.clicked.connect(self._on_load_remote)
        rb_layout.addWidget(rb_lbl)
        rb_layout.addStretch()
        rb_layout.addWidget(btn_load_remote)
        self.remote_bar.setVisible(False)
        self.remote_bar.setStyleSheet("background-color: #2a0000; border-bottom: 1px solid #aa0000;")

        self.viewer = MessageBrowser()
        self.viewer.setOpenExternalLinks(True)
        self.viewer.setReadOnly(True)

        # Attachment row
        self.attach_bar = QWidget()
        ab = QHBoxLayout(self.attach_bar)
        ab.setContentsMargins(8, 4, 8, 4)
        self.attach_label = QLabel("")
        self.attach_label.setStyleSheet("color: #cc0000; font-weight: bold;")
        ab.addWidget(self.attach_label)
        self.attach_buttons_widget = QWidget()
        self.attach_buttons_layout = QHBoxLayout(self.attach_buttons_widget)
        self.attach_buttons_layout.setContentsMargins(0, 0, 0, 0)
        ab.addWidget(self.attach_buttons_widget, 1)
        self.attach_bar.setVisible(False)
        self.attach_bar.setStyleSheet("background-color: #141414; border-top: 1px solid #2a2a2a;")

        rl.addWidget(self.hdr_box)
        rl.addWidget(self.remote_bar)
        rl.addWidget(self.viewer, 1)
        rl.addWidget(self.attach_bar)

        splitter.addWidget(right)
        splitter.setSizes([170, 480, 630])
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 2)

        self._update_actions_enabled()

    def _wire_signals(self):
        self.imap.folders_ready.connect(self._on_folders_ready)
        self.imap.headers_ready.connect(self._on_headers_ready)
        self.imap.message_ready.connect(self._on_message_ready)
        self.imap.error_occurred.connect(self._on_imap_error)
        self.imap.status.connect(self._set_status)
        self.imap.connected_changed.connect(self._on_connected_changed)
        self.imap.folder_status.connect(self._on_folder_status)
        self.imap.idle_change.connect(self._on_idle_change)
        self.imap.idle_supported.connect(self._on_idle_supported)
        self.imap.search_results.connect(self._on_search_results)

        self.smtp.error_occurred.connect(self._on_smtp_error)
        self.smtp.status.connect(self._set_status)
        self.smtp.sent.connect(self._on_smtp_sent)

    # -- account management ---------------------------------------------------

    def _connect_all(self):
        for acc in self.accounts:
            self._add_account_node(acc)
            self.imap.connect(acc)

    def _add_account_node(self, acc: Account):
        item = QTreeWidgetItem(self.tree)
        item.setText(0, acc.name or acc.email_addr)
        item.setData(0, Qt.ItemDataRole.UserRole, ("account", acc.email_addr))
        # Add a placeholder until folders arrive.
        loading = QTreeWidgetItem(item)
        loading.setText(0, "Connecting...")
        loading.setData(0, Qt.ItemDataRole.UserRole, ("placeholder", ""))
        item.setExpanded(True)

    def _find_account_node(self, email_addr: str) -> Optional[QTreeWidgetItem]:
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            data = it.data(0, Qt.ItemDataRole.UserRole)
            if data and data[0] == "account" and data[1] == email_addr:
                return it
        return None

    def _first_run_prompt(self):
        ret = QMessageBox.question(
            self, APP_NAME,
            "No accounts configured.\n\nWould you like to add one now?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if ret == QMessageBox.StandardButton.Yes:
            self._on_add_account()

    def _on_manage_accounts(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Accounts")
        dlg.setMinimumSize(480, 320)
        layout = QHBoxLayout(dlg)
        lst = QListWidget()
        for a in self.accounts:
            lst.addItem(a.name or a.email_addr)
        layout.addWidget(lst, 1)

        col = QVBoxLayout()
        btn_add = QPushButton("Add")
        btn_edit = QPushButton("Edit")
        btn_remove = QPushButton("Remove")
        btn_close = QPushButton("Close")
        col.addWidget(btn_add)
        col.addWidget(btn_edit)
        col.addWidget(btn_remove)
        col.addStretch()
        col.addWidget(btn_close)
        layout.addLayout(col)

        def refresh():
            lst.clear()
            for a in self.accounts:
                lst.addItem(a.name or a.email_addr)

        def add():
            d = AccountDialog(dlg)
            if d.exec() == QDialog.DialogCode.Accepted:
                a = d.get_account()
                missing = AccountDialog._missing_fields(a)
                if missing:
                    QMessageBox.warning(dlg, "Add",
                                        "Account is incomplete. Missing:\n\n• " +
                                        "\n• ".join(missing))
                    return
                self.accounts.append(a)
                save_accounts(self.accounts)
                self._add_account_node(a)
                self.imap.connect(a)
                refresh()

        def edit():
            row = lst.currentRow()
            if row < 0:
                return
            d = AccountDialog(dlg, self.accounts[row])
            if d.exec() == QDialog.DialogCode.Accepted:
                a = d.get_account()
                self.accounts[row] = a
                save_accounts(self.accounts)
                node = self._find_account_node(a.email_addr)
                if node:
                    node.setText(0, a.name or a.email_addr)
                self.imap.unregister(a.email_addr)
                self.imap.connect(a)
                refresh()

        def remove():
            row = lst.currentRow()
            if row < 0:
                return
            a = self.accounts[row]
            ret = QMessageBox.question(
                dlg, "Remove",
                f"Remove account {a.email_addr}?\n(Cached messages on this device will also be removed.)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if ret != QMessageBox.StandardButton.Yes:
                return
            self.imap.unregister(a.email_addr)
            # Best-effort cleanup of any keyring entries we created for this account.
            ps = password_store()
            ps.forget(f"{a.email_addr}:imap")
            ps.forget(f"{a.email_addr}:smtp")
            del self.accounts[row]
            save_accounts(self.accounts)
            node = self._find_account_node(a.email_addr)
            if node:
                idx = self.tree.indexOfTopLevelItem(node)
                self.tree.takeTopLevelItem(idx)
            refresh()

        btn_add.clicked.connect(add)
        btn_edit.clicked.connect(edit)
        btn_remove.clicked.connect(remove)
        btn_close.clicked.connect(dlg.accept)
        dlg.exec()

    def _on_add_account(self):
        d = AccountDialog(self)
        if d.exec() == QDialog.DialogCode.Accepted:
            a = d.get_account()
            missing = AccountDialog._missing_fields(a)
            if missing:
                QMessageBox.warning(self, "Add",
                                    "Account is incomplete. Missing:\n\n• " +
                                    "\n• ".join(missing))
                return
            self.accounts.append(a)
            save_accounts(self.accounts)
            self._add_account_node(a)
            self.imap.connect(a)

    # -- IMAP signal handlers -------------------------------------------------

    @pyqtSlot(str, bool)
    def _on_connected_changed(self, email_addr: str, ok: bool):
        node = self._find_account_node(email_addr)
        if not node:
            return
        if not ok:
            node.setText(0, (next((a.name for a in self.accounts if a.email_addr == email_addr), email_addr)) + "  [offline]")
        else:
            acc = next((a for a in self.accounts if a.email_addr == email_addr), None)
            if acc:
                node.setText(0, acc.name or acc.email_addr)
                # Successful connect — clear the once-per-session failure-shown
                # buckets so a *future* failure (e.g. password rotated) can popup.
                self._connect_failure_shown.pop(email_addr, None)
                # Kick off IDLE listener on INBOX for push notifications.
                self.imap.start_idle(acc, "INBOX")

    @pyqtSlot(str, list)
    def _on_folders_ready(self, email_addr: str, folders: list):
        node = self._find_account_node(email_addr)
        if not node:
            return

        # Auto-detect special folders via RFC 6154 SPECIAL-USE flags
        # (\Trash, \Sent, \Drafts). Without this, Gmail accounts try to MOVE
        # to "Trash" instead of "[Gmail]/Trash" and silently fail.
        acc = next((a for a in self.accounts if a.email_addr == email_addr), None)
        if acc is not None:
            changed = False
            for name, flags in folders:
                fl = (flags or "").lower()
                if "\\trash" in fl and acc.trash_folder != name:
                    acc.trash_folder = name
                    changed = True
                elif "\\sent" in fl and acc.sent_folder != name:
                    acc.sent_folder = name
                    changed = True
                elif "\\drafts" in fl and acc.drafts_folder != name:
                    acc.drafts_folder = name
                    changed = True
            if changed:
                try:
                    save_accounts(self.accounts)
                except Exception:
                    pass

        # Clear current children
        while node.childCount() > 0:
            node.takeChild(0)

        # Sort by special-folder priority, then alphabetical.
        decorated = []
        for name, flags in folders:
            kind = folder_kind(name, flags)
            decorated.append((_KIND_PRIORITY.get(kind, 9), name.lower(), name, flags, kind))
        decorated.sort()

        for prio, _l, name, flags, kind in decorated:
            child = QTreeWidgetItem(node)
            display = name
            if kind == "inbox":
                display = "Inbox"
            child.setText(0, display)
            child.setData(0, Qt.ItemDataRole.UserRole, ("folder", email_addr, name, kind))

        node.setExpanded(True)

        # Auto-select inbox the first time we hear from this account
        if self.current_account is None or self.current_account.email_addr == email_addr:
            for i in range(node.childCount()):
                ch = node.child(i)
                d = ch.data(0, Qt.ItemDataRole.UserRole)
                if d and len(d) >= 4 and d[3] == "inbox":
                    self.tree.setCurrentItem(ch)
                    break

    @pyqtSlot(str, str, int, int)
    def _on_folder_status(self, email_addr: str, folder: str, total: int, unseen: int):
        if (self.current_account and self.current_account.email_addr == email_addr
                and self.current_folder == folder):
            self.lbl_count.setText(f"{total} messages, {unseen} unread")

    @pyqtSlot(str, str, list)
    def _on_headers_ready(self, email_addr: str, folder: str, headers: list):
        self.headers_cache[(email_addr, folder)] = headers
        if not (self.current_account and self.current_account.email_addr == email_addr
                and self.current_folder == folder):
            return
        # Don't clobber a search result that's currently being shown.
        if self.search_active:
            return
        self._populate_message_view(headers)
        self._set_status(f"{folder}: {len(headers)} message(s) loaded")

    @pyqtSlot(str, str, int, dict)
    def _on_message_ready(self, email_addr: str, folder: str, uid: int, message: dict):
        # Cache it
        cache_data = {k: message.get(k, "") for k in
                      ("msg_id", "from_addr", "to_addrs", "cc_addrs",
                       "subject", "date_iso", "body_text", "body_html")}
        cache_data["seen"] = message.get("seen", True)
        cache_data["flagged"] = message.get("flagged", False)
        cache_data["has_attachments"] = message.get("has_attachments", False)
        cache_data["raw"] = message.get("raw", b"")
        self.cache.store_message(email_addr, folder, uid, cache_data)

        # Auto-collect the From: into the address book. We keep an existing
        # display name unless it was empty, so manual edits aren't clobbered.
        try:
            self.contacts.see(message.get("from_addr", ""), prefer_existing_name=True)
        except Exception:
            pass

        if not (self.current_account and self.current_account.email_addr == email_addr
                and self.current_folder == folder and self.current_uid == uid):
            return
        self._render_message(message)

    @pyqtSlot(str, str)
    def _on_imap_error(self, email_addr: str, err: str):
        first_line = err.splitlines()[0] if err else err
        self._set_status(f"[{email_addr}] {first_line}")
        print(f"IMAP error [{email_addr}]: {err}", file=sys.stderr)

        # If this is a connect-stage failure, popup a dialog with hints — but
        # only once per account per session for a given error class so we don't
        # spam the user (e.g. when both _do_connect and IDLE re-connect fail).
        if not err.startswith("Connect failed") and not err.startswith("IDLE"):
            return
        seen = self._connect_failure_shown.setdefault(email_addr, set())
        # Bucket by hint set (so a different *kind* of failure on the same
        # account does get shown again — e.g. auth then later DNS).
        hints = _auth_hints(err, email_addr)
        bucket = ("auth" if hints and "rejected" in " ".join(hints).lower()
                          or hints and "app password" in " ".join(hints).lower()
                  else "timeout" if "timeout" in err.lower()
                  else "dns" if "resolve" in err.lower() or "gaierror" in err.lower()
                  else "other")
        if bucket in seen:
            return
        seen.add(bucket)

        body = f"Couldn't connect {email_addr}.\n\n{err}"
        if hints:
            body += "\n\n" + "\n\n".join(hints)
        # Use a non-blocking warning so the user can keep working.
        mb = QMessageBox(self)
        mb.setIcon(QMessageBox.Icon.Warning)
        mb.setWindowTitle("Connect failed")
        mb.setText(body)
        mb.setStandardButtons(QMessageBox.StandardButton.Ok)
        mb.setModal(False)
        mb.show()

    @pyqtSlot(str, str)
    def _on_smtp_error(self, email_addr: str, err: str):
        QMessageBox.critical(self, "SMTP error", f"{email_addr}: {err}")

    @pyqtSlot(str, str)
    def _on_smtp_sent(self, email_addr: str, msg_id: str):
        self._set_status(f"Message sent from {email_addr}.")

    # -- folder + message selection ------------------------------------------

    def _on_folder_selected(self):
        items = self.tree.selectedItems()
        if not items:
            return
        item = items[0]
        d = item.data(0, Qt.ItemDataRole.UserRole)
        if not d or d[0] != "folder":
            return
        _, email_addr, folder, _ = d
        acc = next((a for a in self.accounts if a.email_addr == email_addr), None)
        if not acc:
            return
        self.current_account = acc
        self.current_folder = folder
        self.current_uid = None
        # Reset search state when changing folders.
        self.search_active = False
        if self.search_edit.text():
            self.search_edit.blockSignals(True)
            self.search_edit.clear()
            self.search_edit.blockSignals(False)
            self.btn_clear_search.setVisible(False)
        self._set_status(f"Loading {folder}...")
        self._clear_viewer()
        self._reset_msg_model()

        # Show cached headers if any while we wait for fresh ones?
        # For simplicity, just request fresh.
        self.imap.select_folder(acc, folder, limit=100)

    def _refresh_current_folder(self):
        if self.current_account and self.current_folder and not self.search_active:
            self.imap.select_folder(self.current_account, self.current_folder, limit=100)

    def _reset_msg_model(self):
        self.msg_model.clear()
        self.msg_model.setHorizontalHeaderLabels(["From", "Subject", "Date", ""])
        # Don't re-apply resize modes here; clearing the model preserves the
        # header configuration and column widths the user has set.

    def _make_row_items(self, h: dict, font_unread: QFont) -> List[QStandardItem]:
        from_item = QStandardItem(_pretty_addr(h.get("from_addr", "")))
        subj_item = QStandardItem(h.get("subject", "(no subject)") or "(no subject)")
        date_item = QStandardItem(_format_date_short(h.get("date_iso", "")))
        flag_item = QStandardItem("●" if h.get("flagged") else "")
        for it in (from_item, subj_item, date_item, flag_item):
            it.setData(h.get("uid"), Qt.ItemDataRole.UserRole)
            if not h.get("seen"):
                it.setFont(font_unread)
                it.setForeground(QColor("#ffffff"))
            else:
                it.setForeground(QColor("#aaaaaa"))
        flag_item.setForeground(QColor("#cc0000"))
        return [from_item, subj_item, date_item, flag_item]

    def _compute_thread_tree(self, headers: List[dict]):
        """Build a parent/child tree from References + In-Reply-To headers.
        Returns (roots, children_dict) keyed by uid."""
        by_id: Dict[str, dict] = {}
        for h in headers:
            mid = (h.get("msg_id") or "").strip()
            m = re.search(r"<([^>]+)>", mid)
            if m:
                mid = m.group(1)
            mid = mid.strip("<>").strip()
            if mid:
                by_id[mid] = h

        parent_of: Dict[int, Optional[int]] = {}
        for h in headers:
            parent_h = None
            refs_str = h.get("references") or ""
            refs = re.findall(r"<([^>]+)>", refs_str) or refs_str.split()
            for r in reversed(refs):
                r = r.strip().strip("<>")
                if r and r in by_id and by_id[r] is not h:
                    parent_h = by_id[r]
                    break
            if parent_h is None:
                irt = h.get("in_reply_to") or ""
                m = re.search(r"<([^>]+)>", irt)
                irt_id = m.group(1) if m else irt.strip().strip("<>").strip()
                if irt_id and irt_id in by_id and by_id[irt_id] is not h:
                    parent_h = by_id[irt_id]
            parent_of[h["uid"]] = parent_h["uid"] if parent_h else None

        children: Dict[int, List[dict]] = {}
        for h in headers:
            p = parent_of.get(h["uid"])
            if p is not None:
                children.setdefault(p, []).append(h)

        roots = [h for h in headers if parent_of.get(h["uid"]) is None]

        def date_key(h):
            try:
                return datetime.fromisoformat(h.get("date_iso", ""))
            except Exception:
                return datetime.min.replace(tzinfo=timezone.utc)

        for k in children:
            children[k].sort(key=date_key)

        def thread_latest(h, seen=None):
            if seen is None:
                seen = set()
            if h["uid"] in seen:
                return date_key(h)
            seen.add(h["uid"])
            latest = date_key(h)
            for c in children.get(h["uid"], []):
                cl = thread_latest(c, seen)
                if cl > latest:
                    latest = cl
            return latest

        roots.sort(key=lambda h: thread_latest(h), reverse=True)
        return roots, children

    def _populate_message_view(self, headers: List[dict]):
        t0 = time.monotonic()
        self._reset_msg_model()
        font_unread = QFont(); font_unread.setBold(True)
        if self.threaded_mode:
            roots, children = self._compute_thread_tree(headers)

            def thread_size(h, seen=None):
                if seen is None: seen = set()
                if h["uid"] in seen: return 0
                seen.add(h["uid"])
                n = 1
                for c in children.get(h["uid"], []):
                    n += thread_size(c, seen)
                return n

            def add_node(parent_item: QStandardItem, h: dict, seen: set):
                if h["uid"] in seen:
                    return
                seen.add(h["uid"])
                items = self._make_row_items(h, font_unread)
                parent_item.appendRow(items)
                for c in children.get(h["uid"], []):
                    add_node(items[0], c, seen)

            root_invisible = self.msg_model.invisibleRootItem()
            seen: set = set()
            for h in roots:
                if h["uid"] in seen:
                    continue
                items = self._make_row_items(h, font_unread)
                size = thread_size(h)
                if size > 1:
                    items[1].setText(f"{items[1].text()}  ({size})")
                seen.add(h["uid"])
                root_invisible.appendRow(items)
                for c in children.get(h["uid"], []):
                    add_node(items[0], c, seen)
            self.msg_view.expandAll()
        else:
            root_invisible = self.msg_model.invisibleRootItem()
            for h in headers:
                root_invisible.appendRow(self._make_row_items(h, font_unread))

        t_total = time.monotonic() - t0
        if t_total > 0.3:
            print(f"[perf] populate_message_view: {t_total*1000:.0f}ms "
                  f"(n={len(headers)}, threaded={self.threaded_mode})",
                  file=sys.stderr)

    def _items_for_row(self, idx) -> List[QStandardItem]:
        """Get all column items for the row at the given QModelIndex."""
        parent_idx = idx.parent()
        if parent_idx.isValid():
            parent_item = self.msg_model.itemFromIndex(parent_idx)
        else:
            parent_item = self.msg_model.invisibleRootItem()
        return [parent_item.child(idx.row(), c)
                for c in range(self.msg_model.columnCount())]

    def _on_msg_selected(self):
        idxs = self.msg_view.selectionModel().selectedRows()
        if not idxs:
            self._update_actions_enabled()
            return
        idx = idxs[0]
        item = self.msg_model.itemFromIndex(idx)
        if item is None:
            return
        uid = item.data(Qt.ItemDataRole.UserRole)
        if uid is None:
            return
        # New message — drop any cached remote resources from the previous one.
        if uid != self.current_uid:
            self.viewer.clear_remote_resources()
        self.current_uid = int(uid)
        # Try cache first.
        cached = self.cache.get_message(
            self.current_account.email_addr, self.current_folder, self.current_uid
        )
        if cached and (cached.get("body_text") or cached.get("body_html")):
            attachments = []
            # Only re-parse the raw bytes if we know the message has
            # attachments; for the common case (no attachments) we save the
            # MIME parse cost entirely.
            if cached.get("has_attachments"):
                raw = cached.get("raw")
                if raw:
                    try:
                        parsed = _parse_message_bytes(bytes(raw))
                        attachments = parsed.get("attachments", [])
                    except Exception:
                        attachments = []
            cached["attachments"] = attachments
            self._render_message(cached)
        else:
            self.viewer.setPlainText("Loading...")
            self.imap.fetch_message(self.current_account, self.current_folder, self.current_uid)

        # Mark seen if it was unread
        row_items = self._items_for_row(idx)
        if row_items and row_items[0] is not None and row_items[0].font().bold():
            for it in row_items:
                if it is None: continue
                f = QFont(it.font()); f.setBold(False); it.setFont(f)
                it.setForeground(QColor("#aaaaaa"))
            self.imap.mark_seen(self.current_account, self.current_folder,
                                self.current_uid, True)
            self.cache.update_seen(self.current_account.email_addr,
                                   self.current_folder, self.current_uid, True)

        self._update_actions_enabled()

    def _on_msg_double(self, index):
        # Same effect as selection for now, but could open in a new window.
        self._on_msg_selected()

    def _render_message(self, msg: dict):
        t0 = time.monotonic()
        self.lbl_subj.setText(msg.get("subject") or "(no subject)")
        self.lbl_from.setText(f"From: {msg.get('from_addr', '')}")
        to = msg.get("to_addrs", "")
        cc = msg.get("cc_addrs", "")
        s = f"To: {to}"
        if cc:
            s += f"   |   Cc: {cc}"
        self.lbl_to.setText(s)
        self.lbl_date.setText(f"Date: {msg.get('date_iso', '')}")

        html = msg.get("body_html") or ""
        text = msg.get("body_text") or ""
        html_size = len(html)

        if html:
            had_remote = bool(re.search(r'<img\s[^>]*src=["\']https?://', html, re.IGNORECASE)) or \
                         bool(re.search(r'url\(\s*["\']?https?://', html, re.IGNORECASE))
            self.remote_bar.setVisible(had_remote and not self.allow_remote)
            sanitized = self._sanitize_html(html, allow_remote=self.allow_remote)
            # QTextBrowser handles a useful subset of HTML.
            self.viewer.setHtml(sanitized)
        else:
            self.remote_bar.setVisible(False)
            # Convert plain text -> light HTML so we can style it.
            esc = html_escape(text or "")
            esc = re.sub(
                r"(https?://[^\s<>]+)",
                r'<a href="\1" style="color:#ff4040;">\1</a>',
                esc
            )
            self.viewer.setHtml(
                f"<div style='color:#e0e0e0;font-family:monospace;white-space:pre-wrap;'>{esc}</div>"
            )

        # Attachments
        for i in reversed(range(self.attach_buttons_layout.count())):
            w = self.attach_buttons_layout.itemAt(i).widget()
            if w:
                w.setParent(None)
        attachments = msg.get("attachments", []) or []
        if attachments:
            self.attach_label.setText(f"Attachments ({len(attachments)}):")
            for fname, ctype, data in attachments:
                btn = QPushButton(f"{fname}  ({len(data)//1024} KB)")
                btn.clicked.connect(
                    lambda _checked, n=fname, d=data: self._save_attachment(n, d)
                )
                self.attach_buttons_layout.addWidget(btn)
            self.attach_buttons_layout.addStretch()
            self.attach_bar.setVisible(True)
        else:
            self.attach_bar.setVisible(False)

        self._current_message = msg
        self._update_actions_enabled()

        # Surface slow renders. setHtml on heavy email HTML is the most likely
        # cause of "Not Responding" once the SQLite path is async, so we want
        # the user to be able to point at exact numbers.
        t_total = time.monotonic() - t0
        if t_total > 0.5:
            print(f"[perf] render_message: {t_total*1000:.0f}ms total "
                  f"(html={html_size//1024}KB)", file=sys.stderr)

    def _clear_viewer(self):
        self.lbl_subj.setText("")
        self.lbl_from.setText("")
        self.lbl_to.setText("")
        self.lbl_date.setText("")
        self.viewer.clear()
        self.viewer.clear_remote_resources()
        self.remote_bar.setVisible(False)
        self.attach_bar.setVisible(False)
        self._current_message = None
        self._update_actions_enabled()

    def _save_attachment(self, filename: str, data: bytes):
        path, _ = QFileDialog.getSaveFileName(self, "Save attachment",
                                              str(Path.home() / filename))
        if not path:
            return
        try:
            Path(path).write_bytes(data)
            self._set_status(f"Saved {Path(path).name}")
        except Exception as e:
            QMessageBox.critical(self, "Save failed", str(e))

    @staticmethod
    def _sanitize_html(html: str, allow_remote: bool) -> str:
        """Minimal HTML sanitization: strip script/iframe/object/embed/style+link.
        If !allow_remote, replace external img src with blank to block tracking pixels."""
        # Remove dangerous tags entirely.
        html = re.sub(r"<\s*(script|iframe|object|embed|link|meta)[^>]*>.*?<\s*/\s*\1\s*>",
                      "", html, flags=re.IGNORECASE | re.DOTALL)
        html = re.sub(r"<\s*(script|iframe|object|embed|link|meta)[^>]*/?>", "",
                      html, flags=re.IGNORECASE)
        # Strip on* event handlers and javascript: URLs.
        html = re.sub(r"\son\w+\s*=\s*\"[^\"]*\"", "", html, flags=re.IGNORECASE)
        html = re.sub(r"\son\w+\s*=\s*'[^']*'", "", html, flags=re.IGNORECASE)
        html = re.sub(r"\son\w+\s*=\s*[^\s>]+", "", html, flags=re.IGNORECASE)
        html = re.sub(r"javascript\s*:", "blocked:", html, flags=re.IGNORECASE)
        if not allow_remote:
            # Neuter remote images
            html = re.sub(
                r'(<img\b[^>]*?\bsrc=["\'])https?://[^"\']*(["\'])',
                r'\1about:blank\2',
                html, flags=re.IGNORECASE
            )
            # Neuter remote backgrounds
            html = re.sub(
                r'url\(\s*["\']?https?://[^)]+\)',
                "url(about:blank)",
                html, flags=re.IGNORECASE
            )
        return html

    def _on_load_remote(self):
        msg = getattr(self, "_current_message", None)
        if not msg:
            return
        html = msg.get("body_html") or ""
        if not html:
            return
        # Find every remote URL the message references. Qt's HTML parser
        # decodes &amp; → & and similar before calling loadResource, so we
        # decode here too — the cache key has to match what Qt asks for.
        urls: set = set()
        for m in re.finditer(r'<img\b[^>]*?\bsrc=["\']([^"\']+)["\']', html, re.IGNORECASE):
            u = html_unescape(m.group(1))
            if u.startswith(("http://", "https://")):
                urls.add(u)
        for m in re.finditer(r'url\(\s*["\']?(https?://[^)\'"]+)', html, re.IGNORECASE):
            urls.add(html_unescape(m.group(1)))
        if not urls:
            self.allow_remote = True
            self._render_message(msg)
            self.allow_remote = False
            return

        self.remote_bar.setVisible(False)
        self._set_status(f"Loading {len(urls)} remote resource(s)...")

        urls_list = list(urls)
        target_uid = self.current_uid
        target_folder = self.current_folder
        target_account = self.current_account.email_addr if self.current_account else ""

        def worker():
            results: Dict[str, bytes] = {}
            errors = 0
            for u in urls_list:
                try:
                    req = urllib.request.Request(
                        u, headers={"User-Agent": "Mozilla/5.0 (EmailOfDeath)"}
                    )
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        data = resp.read(10 * 1024 * 1024)
                        results[u] = data
                except Exception:
                    errors += 1
            QTimer.singleShot(0, lambda: self._on_remote_loaded(
                msg, results, errors, target_account, target_folder, target_uid
            ))

        threading.Thread(target=worker, daemon=True).start()

    def _on_remote_loaded(self, msg, results, errors, target_account,
                          target_folder, target_uid):
        # Bail if the user has navigated away.
        if not (self.current_account and self.current_account.email_addr == target_account
                and self.current_folder == target_folder
                and self.current_uid == target_uid):
            return
        # Rewrite the message HTML so each fetched URL becomes an inline
        # data: URL. This bypasses QTextBrowser.loadResource entirely, which
        # has been unreliable for HTTP URLs in practice.
        html = msg.get("body_html") or ""
        rewritten = self._embed_data_urls(html, results)
        msg_for_render = dict(msg)
        msg_for_render["body_html"] = rewritten

        self.allow_remote = True
        self._render_message(msg_for_render)
        self.allow_remote = False
        ok = sum(1 for d in results.values() if d)
        total = ok + errors
        self._set_status(f"Loaded {ok}/{total} remote resource(s)")

    @staticmethod
    def _sniff_image_mime(url: str, data: bytes) -> str:
        """Identify image type from magic bytes, falling back to URL extension.
        Returns a MIME type string suitable for a data: URL."""
        if not data:
            return "image/png"
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            return "image/png"
        if data[:3] == b"\xff\xd8\xff":
            return "image/jpeg"
        if data[:6] in (b"GIF87a", b"GIF89a"):
            return "image/gif"
        if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp"
        if data[:4] == b"<svg" or data[:5] == b"<?xml":
            return "image/svg+xml"
        guess = mimetypes.guess_type(url)[0]
        if guess and guess.startswith("image/"):
            return guess
        return "image/png"

    def _embed_data_urls(self, html: str, results: Dict[str, bytes]) -> str:
        """Rewrite remote img-src and CSS url(...) references to inline
        data: URLs for any URLs we successfully fetched. URLs we couldn't
        fetch are left as-is (and will render as broken images, which the
        user can interpret as 'failed to load')."""
        if not results or not html:
            return html

        def lookup(raw_src: str) -> Optional[bytes]:
            # Try the raw form, then the entity-decoded form.
            if raw_src in results:
                return results[raw_src]
            decoded = html_unescape(raw_src)
            if decoded in results:
                return results[decoded]
            return None

        def replace_img(match):
            full = match.group(0)
            src = match.group(1)
            data = lookup(src)
            if data is None:
                return full
            mime = self._sniff_image_mime(src, data)
            b64 = base64.b64encode(data).decode("ascii")
            return full.replace(src, f"data:{mime};base64,{b64}", 1)

        new_html = re.sub(
            r'<img\b[^>]*?\bsrc=["\']([^"\']+)["\']',
            replace_img, html, flags=re.IGNORECASE
        )

        def replace_css_url(match):
            full = match.group(0)
            url = match.group(1)
            data = lookup(url)
            if data is None:
                return full
            mime = self._sniff_image_mime(url, data)
            b64 = base64.b64encode(data).decode("ascii")
            return full.replace(url, f"data:{mime};base64,{b64}", 1)

        new_html = re.sub(
            r'url\(\s*["\']?(https?://[^)\'"]+)',
            replace_css_url, new_html, flags=re.IGNORECASE
        )
        return new_html

    # -- actions -------------------------------------------------------------

    def _update_actions_enabled(self):
        has_msg = getattr(self, "_current_message", None) is not None
        self.act_reply.setEnabled(has_msg)
        self.act_forward.setEnabled(has_msg)
        self.act_delete.setEnabled(has_msg)
        self.act_mark_unread.setEnabled(has_msg)
        self.act_compose.setEnabled(bool(self.accounts))

    def _on_compose_new(self):
        if not self.accounts:
            QMessageBox.information(self, APP_NAME, "Add an account first.")
            return
        dlg = ComposeWindow(self, self.accounts, self.smtp,
                            default_account=self.current_account or self.accounts[0],
                            address_book=self.contacts)
        dlg.exec()

    def _on_reply(self):
        msg = getattr(self, "_current_message", None)
        if not msg:
            return
        dlg = ComposeWindow(self, self.accounts, self.smtp,
                            default_account=self.current_account, reply_to=msg,
                            address_book=self.contacts)
        dlg.exec()

    def _on_forward(self):
        msg = getattr(self, "_current_message", None)
        if not msg:
            return
        dlg = ComposeWindow(self, self.accounts, self.smtp,
                            default_account=self.current_account, forward_of=msg,
                            address_book=self.contacts)
        dlg.exec()

    def _on_delete(self):
        if not (self.current_account and self.current_folder
                and self.current_uid is not None):
            return
        ret = QMessageBox.question(
            self, "Delete",
            f"Move this message to {self.current_account.trash_folder}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if ret != QMessageBox.StandardButton.Yes:
            return
        self.imap.delete_message(self.current_account, self.current_folder,
                                 self.current_uid)
        self.cache.delete(self.current_account.email_addr, self.current_folder,
                          self.current_uid)
        # Remove from list view + clear viewer
        sel = self.msg_view.selectionModel().selectedRows()
        if sel:
            idx = sel[0]
            parent_idx = idx.parent()
            if parent_idx.isValid():
                parent_item = self.msg_model.itemFromIndex(parent_idx)
                if parent_item is not None:
                    parent_item.removeRow(idx.row())
            else:
                self.msg_model.removeRow(idx.row())
        self._clear_viewer()
        self.current_uid = None
        # Refresh folder shortly
        QTimer.singleShot(800, self._refresh_current_folder)

    def _on_mark_unread(self):
        if not (self.current_account and self.current_folder
                and self.current_uid is not None):
            return
        self.imap.mark_seen(self.current_account, self.current_folder,
                            self.current_uid, False)
        self.cache.update_seen(self.current_account.email_addr,
                               self.current_folder, self.current_uid, False)
        sel = self.msg_view.selectionModel().selectedRows()
        if sel:
            f = QFont(); f.setBold(True)
            for it in self._items_for_row(sel[0]):
                if it is None: continue
                it.setFont(f)
                it.setForeground(QColor("#ffffff"))

    # -- search / idle / threading -------------------------------------------

    def _on_search_changed(self, text: str):
        self.btn_clear_search.setVisible(bool(text))
        if not text.strip():
            # Restore folder view immediately
            self._on_clear_search()
            return
        # Debounce
        self._search_timer.start()

    def _on_search_submit(self):
        text = self.search_edit.text().strip()
        if not text:
            self._on_clear_search()
            return
        if not (self.current_account and self.current_folder):
            return
        self.search_active = True
        self._set_status(f"Searching {self.current_folder} for '{text}'...")
        self.imap.search_folder(self.current_account, self.current_folder, text)

    def _on_clear_search(self):
        self.search_edit.blockSignals(True)
        self.search_edit.clear()
        self.search_edit.blockSignals(False)
        self.btn_clear_search.setVisible(False)
        was_active = self.search_active
        self.search_active = False
        # Restore the original folder view from cache or refetch.
        if self.current_account and self.current_folder:
            cached = self.headers_cache.get(
                (self.current_account.email_addr, self.current_folder)
            )
            if cached is not None:
                self._populate_message_view(cached)
            elif was_active:
                self._refresh_current_folder()

    @pyqtSlot(str, str, str, list)
    def _on_search_results(self, email_addr: str, folder: str, query: str, headers: list):
        if not (self.current_account and self.current_account.email_addr == email_addr
                and self.current_folder == folder):
            return
        # Stale result (user typed more since)?
        if query != self.search_edit.text().strip():
            return
        self._set_status(f"Search '{query}': {len(headers)} result(s)")
        self._populate_message_view(headers)

    def _on_toggle_threaded(self, checked: bool):
        self.threaded_mode = checked
        # Re-render whatever is currently being shown.
        if self.search_active and self.current_account and self.current_folder:
            self._on_search_submit()
            return
        if self.current_account and self.current_folder:
            cached = self.headers_cache.get(
                (self.current_account.email_addr, self.current_folder)
            )
            if cached is not None:
                self._populate_message_view(cached)

    @pyqtSlot(str, str)
    def _on_idle_change(self, email_addr: str, folder: str):
        # IDLE detected new mail / flag change. Don't act on every single push
        # — Gmail can fire EXISTS several times in a row during a sync. Coalesce
        # via a short timer so we do at most one refetch per ~5 seconds.
        if (self.current_account and self.current_account.email_addr == email_addr
                and self.current_folder == folder and not self.search_active):
            if not self._idle_refresh_timer.isActive():
                self._idle_refresh_timer.start()
        else:
            self._set_status(f"New activity in {email_addr}:{folder}")

    def _do_idle_refresh(self):
        if (self.current_account and self.current_folder
                and not self.search_active):
            self.imap.select_folder(self.current_account, self.current_folder, limit=100)

    @pyqtSlot(str, bool)
    def _on_idle_supported(self, email_addr: str, supported: bool):
        self._idle_status[email_addr] = supported
        if not supported:
            self._set_status(f"{email_addr}: server doesn't support IDLE — using 2-min polling")

    # -- misc ----------------------------------------------------------------

    def _set_status(self, text: str):
        # Coalesce: many signals can fire per second on a busy connection;
        # repainting the status bar each time chews CPU and steals the GUI
        # thread's time budget. Buffer + flush via a 100ms QTimer.
        self._status_pending = text
        if not self._status_timer.isActive():
            self._status_timer.start()

    def _flush_status(self):
        if self._status_pending is not None:
            self.lbl_status.setText(self._status_pending)
            self._status_pending = None

    def _on_about(self):
        QMessageBox.about(
            self, f"About {APP_NAME}",
            f"<h2>{APP_NAME}</h2>"
            f"<p>Version {APP_VERSION}</p>"
            f"<p>{ORG_NAME}</p>"
            f"<p>A PyQt6 IMAP/SMTP email client.</p>"
            f"<p style='color:#888;'>Remote content is blocked by default to defeat tracking pixels.</p>"
        )

    # -- address book ---------------------------------------------------------

    def _on_open_address_book(self):
        dlg = AddressBookDialog(self, self.contacts)
        dlg.exec()

    def _on_msg_context_menu(self, pos):
        idx = self.msg_view.indexAt(pos)
        if not idx.isValid():
            return
        item = self.msg_model.itemFromIndex(idx)
        if item is None:
            return
        uid = item.data(Qt.ItemDataRole.UserRole)
        if uid is None:
            return
        # Look up the From: from the headers cache for this folder.
        if not (self.current_account and self.current_folder):
            return
        cache_key = (self.current_account.email_addr, self.current_folder)
        headers = self.headers_cache.get(cache_key, [])
        h = next((hh for hh in headers if hh.get("uid") == int(uid)), None)
        if h is None:
            return

        menu = QMenu(self.msg_view)
        from_addr = h.get("from_addr", "")
        name, em = email.utils.parseaddr(from_addr)
        if em:
            act_add = menu.addAction(f"Add {em} to Address Book")
            act_add.triggered.connect(
                lambda _checked=False, fa=from_addr: self._add_sender_to_book(fa)
            )
            existing = self.contacts.get(em)
            if existing:
                act_edit = menu.addAction(f"Edit contact: {existing.display()}")
                act_edit.triggered.connect(
                    lambda _checked=False, e=em: self._edit_contact_by_email(e)
                )
        menu.addSeparator()
        act_reply = menu.addAction("Reply")
        act_reply.triggered.connect(self._on_reply)
        act_fwd = menu.addAction("Forward")
        act_fwd.triggered.connect(self._on_forward)
        act_del = menu.addAction("Delete")
        act_del.triggered.connect(self._on_delete)
        menu.exec(self.msg_view.viewport().mapToGlobal(pos))

    def _add_sender_to_book(self, raw_addr: str):
        name, em = email.utils.parseaddr(raw_addr)
        if not em:
            return
        existing = self.contacts.get(em)
        ct = existing or Contact(email=em, name=name)
        dlg = ContactEditDialog(self, ct, is_new=existing is None)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.contacts.upsert(dlg.contact)
            self._set_status(f"Saved {dlg.contact.email} to address book")

    def _edit_contact_by_email(self, em: str):
        ct = self.contacts.get(em)
        if not ct:
            return
        dlg = ContactEditDialog(self, ct, is_new=False)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.contacts.upsert(dlg.contact)

    def closeEvent(self, event):
        try:
            self.imap.disconnect_all()
        except Exception:
            pass
        try:
            self.cache.shutdown()
        except Exception:
            pass
        try:
            self.contacts.shutdown()
        except Exception:
            pass
        event.accept()


def _pretty_addr(addr: str) -> str:
    """Turn 'Foo Bar <foo@bar.com>' into 'Foo Bar' if name is present."""
    if not addr:
        return ""
    name, em = email.utils.parseaddr(addr)
    if name:
        return name
    return em or addr


# =============================================================================
# Entry point
# =============================================================================

# =============================================================================
# Provider hints: server settings + setup notes for popular email providers,
# keyed by domain. Used by /api/provider_hints to autofill the account form.
# Aliases collapse to a canonical entry via "alias:<domain>".
# =============================================================================

PROVIDER_HINTS: Dict[str, Any] = {
    "gmail.com": {
        "imap_host": "imap.gmail.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.gmail.com", "smtp_port": 587,
        "smtp_ssl": False, "smtp_starttls": True,
        "note": ("Gmail requires an APP PASSWORD, not your account password. "
                 "Generate one at myaccount.google.com/apppasswords (after enabling "
                 "2-Step Verification). Also enable IMAP at "
                 "Gmail Settings → Forwarding and POP/IMAP."),
    },
    "googlemail.com": "alias:gmail.com",

    "outlook.com": {
        "imap_host": "outlook.office365.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.office365.com", "smtp_port": 587,
        "smtp_ssl": False, "smtp_starttls": True,
        "note": ("Microsoft 365 / Outlook.com. With MFA enabled, generate an "
                 "app password at account.microsoft.com → Security → "
                 "Advanced security options."),
    },
    "hotmail.com": "alias:outlook.com",
    "live.com":    "alias:outlook.com",
    "msn.com":     "alias:outlook.com",

    "yahoo.com": {
        "imap_host": "imap.mail.yahoo.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.mail.yahoo.com", "smtp_port": 465,
        "smtp_ssl": True, "smtp_starttls": False,
        "note": ("Yahoo requires an app password. Generate at "
                 "login.yahoo.com → Account Security → Generate app password."),
    },
    "ymail.com": "alias:yahoo.com",

    "icloud.com": {
        "imap_host": "imap.mail.me.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.mail.me.com", "smtp_port": 587,
        "smtp_ssl": False, "smtp_starttls": True,
        "note": ("iCloud requires an app-specific password. Generate at "
                 "appleid.apple.com → Sign-In and Security → "
                 "App-Specific Passwords."),
    },
    "me.com":  "alias:icloud.com",
    "mac.com": "alias:icloud.com",

    "fastmail.com": {
        "imap_host": "imap.fastmail.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.fastmail.com", "smtp_port": 465,
        "smtp_ssl": True, "smtp_starttls": False,
        "note": ("Fastmail requires an app password "
                 "(Settings → Privacy & Security → App Passwords)."),
    },
    "fastmail.fm": "alias:fastmail.com",

    "mailfence.com": {
        "imap_host": "imap.mailfence.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.mailfence.com", "smtp_port": 465,
        "smtp_ssl": True, "smtp_starttls": False,
        "note": ("Mailfence IMAP/SMTP requires a paid subscription — "
                 "free accounts are webmail only."),
    },

    "proton.me": {
        "imap_host": "127.0.0.1", "imap_port": 1143,
        "imap_ssl": False,
        "smtp_host": "127.0.0.1", "smtp_port": 1025,
        "smtp_ssl": False, "smtp_starttls": True,
        "note": ("Proton Mail does not expose IMAP/SMTP directly — you need the "
                 "Proton Mail Bridge desktop app running locally. Host/ports "
                 "shown are the Bridge's local listeners; check the app for "
                 "your specific Bridge password."),
    },
    "protonmail.com": "alias:proton.me",
    "pm.me":          "alias:proton.me",

    "aol.com": {
        "imap_host": "imap.aol.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.aol.com", "smtp_port": 465,
        "smtp_ssl": True, "smtp_starttls": False,
        "note": ("AOL requires an app password "
                 "(login.aol.com → Account Security)."),
    },

    "zoho.com": {
        "imap_host": "imap.zoho.com", "imap_port": 993, "imap_ssl": True,
        "smtp_host": "smtp.zoho.com", "smtp_port": 465,
        "smtp_ssl": True, "smtp_starttls": False,
        "note": "Zoho requires an app password if 2FA is enabled.",
    },

    "tutanota.com": {
        "imap_host": "", "imap_port": 0,
        "smtp_host": "", "smtp_port": 0,
        "note": ("Tutanota does not support standard IMAP/SMTP — they use "
                 "proprietary encrypted protocols. This client cannot "
                 "connect to Tutanota."),
        "unsupported": True,
    },
}


def resolve_provider_hint(domain: str) -> Optional[Dict[str, Any]]:
    """Return the hints dict for a domain, following aliases. None if unknown."""
    h = PROVIDER_HINTS.get((domain or "").lower())
    if isinstance(h, str) and h.startswith("alias:"):
        return PROVIDER_HINTS.get(h[len("alias:"):])
    if isinstance(h, dict):
        return h
    return None


# =============================================================================
# IMAP client (web edition) — synchronous, one persistent connection per account.
#
# The desktop ImapClient is a QObject with pyqtSignals; we don't want a Qt event
# loop here. This wrapper is plain Python: per-account locks, per-account long-
# lived connection, reconnect on drop, no signals.
# =============================================================================

class WebImap:
    # Max UIDs per IMAP command line. With UIDs up to 10 digits + comma
    # (~11 bytes each), 500 UIDs ≈ 5.5 KB — safely under the 8 KB limit
    # most servers enforce. Going lower hurts performance; going higher
    # risks "501 Syntax error - line too long" on strict servers.
    UID_CHUNK = 500

    def __init__(self):
        self._conns: Dict[str, imaplib.IMAP4] = {}
        self._locks: Dict[str, threading.Lock] = {}

    @staticmethod
    def _chunk_uids(uids: list) -> "List[list]":
        """Split a UID list into chunks that fit within one IMAP command."""
        chunk = WebImap.UID_CHUNK
        return [uids[i:i + chunk] for i in range(0, len(uids), chunk)]

    def _lock(self, acc) -> threading.Lock:
        return self._locks.setdefault(acc.email_addr, threading.Lock())

    def _ensure(self, acc) -> imaplib.IMAP4:
        c = self._conns.get(acc.email_addr)
        if c is not None:
            try:
                # NOOP succeeds even when no mailbox is selected (AUTH state).
                # Check the actual state: if it returns "AUTH" we need to
                # re-select after a failed mark_seen, set_flag, etc.
                typ, _ = c.noop()
                if typ == "OK":
                    return c
            except Exception:
                pass
            self._close(acc.email_addr)
        ctx = _ssl_context()
        if acc.imap_ssl:
            c = imaplib.IMAP4_SSL(acc.imap_host, acc.imap_port,
                                  ssl_context=ctx, timeout=30)
        else:
            c = imaplib.IMAP4(acc.imap_host, acc.imap_port, timeout=30)
            try:
                c.starttls(ssl_context=ctx)
            except Exception:
                pass
        c.login(acc.imap_user, acc.imap_pass)
        self._conns[acc.email_addr] = c
        return c

    def _close(self, em: str):
        c = self._conns.pop(em, None)
        if c is None:
            return
        try: c.logout()
        except Exception:
            try: c.shutdown()
            except Exception: pass

    def disconnect_all(self):
        for em in list(self._conns):
            self._close(em)

    @staticmethod
    def _quote(name: str) -> str:
        if " " in name or '"' in name:
            return '"' + name.replace('"', '\\"') + '"'
        return name

    # -- folders ---------------------------------------------------------------

    def list_folders(self, acc) -> List[Dict[str, Any]]:
        with self._lock(acc):
            c = self._ensure(acc)
            typ, data = c.list()
            if typ != "OK":
                return []
            out = []
            for row in data or []:
                if not row:
                    continue
                if isinstance(row, tuple):
                    line = (row[0] + b" " + row[1]).strip()
                else:
                    line = row
                m = _LIST_RE.search(line)
                if not m:
                    continue
                flags = m.group("flags").decode("utf-8", errors="replace")
                name_raw = m.group("name")
                if name_raw.startswith(b'"') and name_raw.endswith(b'"'):
                    name_raw = name_raw[1:-1]
                try:
                    name = name_raw.decode("utf-8", errors="replace")
                except Exception:
                    name = repr(name_raw)
                if "\\Noselect" in flags or "\\NonExistent" in flags:
                    continue
                out.append({"name": name, "flags": flags,
                            "kind": folder_kind(name, flags)})
            # Side-effect: auto-detect special folders by SPECIAL-USE flags.
            self._update_special_folders(acc, out)
            return out

    @staticmethod
    def _update_special_folders(acc, folders: List[dict]):
        """Auto-detect Trash/Sent/Drafts folders from the LIST response. Uses
        the same heuristic as folder_kind() — RFC 6154 SPECIAL-USE flag first,
        then a name match against common patterns. Without this fallback,
        servers that don't advertise SPECIAL-USE (some IONOS / older Dovecot
        setups) leave acc.trash_folder pointing at a default "Trash" that
        doesn't exist, which makes Delete fail.

        Manually-set values take precedence: if the user typed a custom
        folder in the settings UI we don't overwrite it just because the
        server happens to also have a folder with the SPECIAL-USE flag."""
        changed = False
        # Track whether each kind has been claimed yet — first match wins.
        claimed = {"trash": False, "sent": False, "drafts": False}
        # Default values (which mean "auto-detect, please") shouldn't block
        # auto-detection. Empty strings or the literal default names are
        # treated as un-set.
        DEFAULTS = {"trash": "Trash", "sent": "Sent", "drafts": "Drafts"}

        # First pass: SPECIAL-USE flag matches (authoritative when present).
        for f in folders:
            fl   = (f.get("flags") or "").lower()
            kind = f.get("kind")
            n    = f["name"]
            for k, attr, default in (
                ("trash",  "trash_folder",  DEFAULTS["trash"]),
                ("sent",   "sent_folder",   DEFAULTS["sent"]),
                ("drafts", "drafts_folder", DEFAULTS["drafts"]),
            ):
                if claimed[k]: continue
                # SPECIAL-USE flag explicitly identifies it.
                if f"\\{k}" in fl:
                    if getattr(acc, attr) != n:
                        # Only overwrite if user is on the default — otherwise
                        # respect the manual setting.
                        cur = getattr(acc, attr)
                        if cur in ("", default):
                            setattr(acc, attr, n)
                            changed = True
                    claimed[k] = True

        # Second pass: name-based detection for servers that don't advertise
        # SPECIAL-USE flags. Same precedence rule: don't trample manual config.
        for f in folders:
            kind = f.get("kind")
            n    = f["name"]
            if kind in claimed and not claimed[kind]:
                attr = {"trash": "trash_folder", "sent": "sent_folder",
                        "drafts": "drafts_folder"}[kind]
                cur = getattr(acc, attr)
                if cur in ("", DEFAULTS[kind]):
                    setattr(acc, attr, n)
                    changed = True
                claimed[kind] = True

        if changed:
            try: save_accounts(_state.accounts)
            except Exception: pass

    # -- headers ---------------------------------------------------------------

    def list_messages(self, acc, folder: str, limit: int = HEADERS_LIMIT
                      ) -> Tuple[List[dict], int, int]:
        """Returns (headers, total, unseen)."""
        with self._lock(acc):
            c = self._ensure(acc)
            typ, data = c.select(self._quote(folder), readonly=False)
            if typ != "OK":
                return [], 0, 0
            total = int(data[0]) if data and data[0] else 0
            typ, data = c.uid("SEARCH", None, "ALL")
            if typ != "OK":
                return [], total, 0
            uids = data[0].split() if data and data[0] else []
            uids = [int(u) for u in uids]
            uids.sort(reverse=True)
            uids = uids[:limit]
            if not uids:
                return [], total, 0
            headers: List[dict] = []
            for chunk in self._chunk_uids(uids):
                seq = ",".join(str(u) for u in chunk)
                typ, data = c.uid(
                    "FETCH", seq,
                    "(UID FLAGS RFC822.SIZE BODY.PEEK[HEADER.FIELDS "
                    "(FROM TO CC SUBJECT DATE MESSAGE-ID IN-REPLY-TO REFERENCES)])"
                )
                if typ != "OK":
                    return [], total, 0
                headers.extend(ImapClient._parse_fetch_headers(data))
            unseen = sum(1 for h in headers if not h.get("seen"))
            return headers, total, unseen

    # -- single message --------------------------------------------------------

    def fetch_message(self, acc, folder: str, uid: int) -> Optional[dict]:
        with self._lock(acc):
            c = self._ensure(acc)
            # readonly=True so servers that reject write access on Sent/Trash
            # (e.g. IONOS) don't refuse the select.
            typ, _ = c.select(self._quote(folder), readonly=True)
            if typ != "OK":
                return None
            typ, data = c.uid("FETCH", str(uid), "(RFC822 FLAGS)")
            if typ != "OK" or not data or not data[0]:
                return None
            raw = b""
            flags = ""
            for item in data:
                if isinstance(item, tuple):
                    meta_b = item[0]
                    raw_b = item[1]
                    meta = (meta_b.decode("utf-8", errors="replace")
                            if isinstance(meta_b, (bytes, bytearray))
                            else str(meta_b))
                    raw = raw_b if isinstance(raw_b, (bytes, bytearray)) else b""
                    m = re.search(r"FLAGS \(([^)]*)\)", meta)
                    if m:
                        flags = m.group(1)
            parsed = _parse_message_bytes(raw)
            parsed["seen"] = "\\Seen" in flags
            parsed["flagged"] = "\\Flagged" in flags
            return parsed

    # -- search ----------------------------------------------------------------

    def search_messages(self, acc, folder: str, query: str,
                        limit: int = 500) -> List[dict]:
        """Server-side IMAP SEARCH TEXT. Returns matching headers."""
        with self._lock(acc):
            c = self._ensure(acc)
            typ, _ = c.select(self._quote(folder), readonly=True)
            if typ != "OK":
                return []
            q = (query or "").strip()
            if not q:
                return []
            quoted = '"' + q.replace('\\', '\\\\').replace('"', '\\"') + '"'
            ascii_only = all(ord(ch) < 128 for ch in q)
            try:
                if ascii_only:
                    typ, data = c.uid("SEARCH", "TEXT", quoted)
                else:
                    try:
                        c.literal = q.encode("utf-8")
                        typ, data = c.uid("SEARCH", "CHARSET", "UTF-8", "TEXT")
                    except Exception:
                        typ, data = c.uid("SEARCH", "CHARSET", "UTF-8",
                                          "TEXT", quoted)
            except Exception:
                typ, data = c.uid("SEARCH", "TEXT", quoted)
            if typ != "OK":
                return []
            uids = data[0].split() if data and data[0] else []
            if not uids:
                return []
            uids = [int(u) for u in uids]
            uids.sort(reverse=True)
            uids = uids[:limit]
            headers: List[dict] = []
            for chunk in self._chunk_uids(uids):
                seq = ",".join(str(u) for u in chunk)
                typ, data = c.uid(
                    "FETCH", seq,
                    "(UID FLAGS RFC822.SIZE BODY.PEEK[HEADER.FIELDS "
                    "(FROM TO CC SUBJECT DATE MESSAGE-ID IN-REPLY-TO REFERENCES)])"
                )
                if typ != "OK":
                    return []
                headers.extend(ImapClient._parse_fetch_headers(data))
            return headers

    # -- mutations -------------------------------------------------------------

    def mark_seen(self, acc, folder: str, uid: int, seen: bool):
        with self._lock(acc):
            c = self._ensure(acc)
            typ, _ = c.select(self._quote(folder), readonly=False)
            if typ != "OK":
                # Folder is read-only (e.g. IONOS Sent/Trash). Close it cleanly
                # so the connection returns to AUTH state rather than leaving it
                # in a half-open state that breaks subsequent fetches.
                try: c.close()
                except Exception: pass
                return
            cmd = "+FLAGS" if seen else "-FLAGS"
            c.uid("STORE", str(uid), cmd, r"(\Seen)")

    def set_flag(self, acc, folder: str, uid: int, flagged: bool):
        """Set or clear the \\Flagged flag on a message via IMAP STORE.

        Raises RuntimeError if the server returns anything other than OK,
        so the caller can surface the error rather than silently doing nothing
        (some Dovecot/IONOS configurations return NO without raising if the
        flag operation isn't permitted on that folder)."""
        with self._lock(acc):
            c = self._ensure(acc)
            c.select(self._quote(folder), readonly=False)
            cmd = "+FLAGS" if flagged else "-FLAGS"
            typ, data = c.uid("STORE", str(uid), cmd, r"(\Flagged)")
            if typ != "OK":
                raise RuntimeError(
                    f"STORE {cmd} \\Flagged returned {typ}: {data!r}. "
                    f"This folder may not support flagging."
                )

    def append_to_folder(self, acc, folder: str, msg_bytes: bytes,
                         flags: str = "\\Seen"):
        """IMAP APPEND a raw RFC-822 message into the given folder."""
        with self._lock(acc):
            c = self._ensure(acc)
            try:
                c.append(self._quote(folder), f"({flags})",
                         imaplib.Time2Internaldate(time.time()), msg_bytes)
            except Exception as e:
                raise RuntimeError(
                    f"APPEND to {folder!r} failed: {e}") from e

    def save_draft(self, acc, msg_bytes: bytes) -> str:
        """APPEND msg_bytes to the account's Drafts folder with \\Draft flag.
        Returns the folder name used. Tries configured folder then fallbacks."""
        candidates: List[str] = []
        if acc.drafts_folder:
            candidates.append(acc.drafts_folder)
        for fb in ("Drafts", "Draft", "INBOX/Drafts", "INBOX.Drafts",
                   "Entwürfe", "Brouillons", "Borradores", "Bozze",
                   "Rascunhos", "Concepten"):
            if fb not in candidates:
                candidates.append(fb)
        last_err = ""
        for folder in candidates:
            try:
                self.append_to_folder(acc, folder, msg_bytes, flags=r"\Draft")
                if folder != acc.drafts_folder:
                    acc.drafts_folder = folder
                    try: save_accounts(_state.accounts)
                    except Exception: pass
                return folder
            except Exception as e:
                last_err = str(e)
                continue
        raise RuntimeError(
            f"Could not save draft to any Drafts folder. Last error: {last_err}"
        )

    def empty_folder(self, acc, folder: str) -> int:
        """Permanently delete every message in the given folder. Marks all
        messages \\Deleted then EXPUNGEs.

        Used for "Empty Trash" — destroys data without going through trash
        again. Returns the number of messages that were expunged.

        Refuses to operate on INBOX as a safety measure (no user should ever
        be one click away from emptying their inbox)."""
        if folder.lower() == "inbox":
            raise RuntimeError("Refusing to empty INBOX")
        with self._lock(acc):
            c = self._ensure(acc)
            typ, _ = c.select(self._quote(folder), readonly=False)
            if typ != "OK":
                raise RuntimeError(f"Could not select {folder!r}")

            # Get the message count before we wipe so we can report it.
            typ, data = c.uid("SEARCH", None, "ALL")
            if typ != "OK":
                raise RuntimeError(f"SEARCH ALL failed: {data!r}")
            uids = (data[0] or b"").split()
            if not uids:
                return 0

            # Mark them all deleted in one STORE for efficiency.
            uids_decoded = [u.decode("ascii") for u in uids]
            for chunk in self._chunk_uids(uids_decoded):
                uid_set = ",".join(chunk)
                typ, _ = c.uid("STORE", uid_set, "+FLAGS", r"(\Deleted)")
                if typ != "OK":
                    raise RuntimeError(f"STORE \\Deleted failed on {folder!r}")

            c.expunge()
            return len(uids)

    def batch_delete_messages(self, acc, folder: str, uids: List[int]) -> Tuple[List[int], List[dict]]:
        """Move multiple messages to trash in one IMAP session using UID sets."""
        trash = acc.trash_folder or "Trash"
        sys.stderr.write(f"[imap] batch_delete: {len(uids)} uids in {folder!r} -> {trash!r}: {uids}\n")
        with self._lock(acc):
            c = self._ensure(acc)
            typ, _ = c.select(self._quote(folder), readonly=False)
            sys.stderr.write(f"[imap] batch_delete SELECT {folder!r}: {typ}\n")
            if typ != "OK":
                return [], [{"uid": u, "error": f"could not select {folder!r}"} for u in uids]

            if folder == trash:
                uid_set = ",".join(str(u) for u in uids)
                try:
                    t2, _ = c.uid("STORE", uid_set, "+FLAGS", r"(\Deleted)")
                    sys.stderr.write(f"[imap] batch_delete STORE {uid_set} +Deleted: {t2}\n")
                    c.expunge()
                    return uids, []
                except Exception as e:
                    return [], [{"uid": u, "error": str(e)} for u in uids]

            # Try batch MOVE first
            uid_set = ",".join(str(u) for u in uids)
            try:
                t2, data = c.uid("MOVE", uid_set, self._quote(trash))
                sys.stderr.write(f"[imap] batch_delete MOVE {uid_set}: {t2} {data!r}\n")
                if t2 == "OK":
                    return uids, []
            except Exception as e:
                sys.stderr.write(f"[imap] batch_delete MOVE failed: {e}\n")

            # Fallback: batch COPY then batch STORE then EXPUNGE
            try:
                t2, data = c.uid("COPY", uid_set, self._quote(trash))
                sys.stderr.write(f"[imap] batch_delete COPY {uid_set} -> {trash!r}: {t2} {data!r}\n")
                if t2 != "OK":
                    return [], [{"uid": u, "error": f"COPY to {trash!r} failed: {data!r}"} for u in uids]
                t3, data2 = c.uid("STORE", uid_set, "+FLAGS", r"(\Deleted)")
                sys.stderr.write(f"[imap] batch_delete STORE {uid_set} +Deleted: {t3} {data2!r}\n")
                t4, data3 = c.expunge()
                sys.stderr.write(f"[imap] batch_delete EXPUNGE: {t4} {data3!r}\n")
                return uids, []
            except Exception as e:
                sys.stderr.write(f"[imap] batch_delete fallback path failed: {e}\n")
                return [], [{"uid": u, "error": str(e)} for u in uids]

    def delete_message(self, acc, folder: str, uid: int):
        """Move a message to the account's trash folder, or expunge in place
        if we're already in trash.

        Failure modes we care about:
        - MOVE not supported (RFC 6851) → fall back to COPY+STORE+EXPUNGE.
        - Trash folder doesn't exist on the server → raise a clear error
          rather than silently EXPUNGE the source (which would destroy the
          message permanently with nowhere to recover it from).
        - Already in trash → just expunge."""
        with self._lock(acc):
            c = self._ensure(acc)
            typ, _ = c.select(self._quote(folder), readonly=False)
            if typ != "OK":
                raise RuntimeError(f"could not select source folder {folder!r}")

            trash = acc.trash_folder or "Trash"

            # If the user is deleting from inside the trash itself, just
            # expunge — copying trash→trash is wasteful and on some servers
            # creates duplicates.
            if folder == trash:
                t1, _ = c.uid("STORE", str(uid), "+FLAGS", r"(\Deleted)")
                if t1 != "OK":
                    raise RuntimeError(f"STORE \\Deleted failed: {_!r}")
                c.expunge()
                return

            # Try MOVE first (RFC 6851 — atomic, supported by most modern
            # IMAP servers including Gmail, Fastmail, Dovecot 2.1+). Some
            # imaplib versions raise on unknown commands; others return NO.
            move_err = None
            try:
                typ, data = c.uid("MOVE", str(uid), self._quote(trash))
                if typ == "OK":
                    return
                move_err = f"MOVE returned {typ}: {data!r}"
            except imaplib.IMAP4.error as e:
                move_err = f"MOVE not supported / failed: {e}"
            except Exception as e:
                move_err = f"MOVE error: {e}"

            # Fallback: COPY then mark deleted then expunge. If COPY fails
            # we MUST NOT expunge — otherwise the message vanishes with no
            # copy in trash. Surface the error instead so the caller knows.
            try:
                typ, data = c.uid("COPY", str(uid), self._quote(trash))
            except imaplib.IMAP4.error as e:
                raise RuntimeError(
                    f"Could not move message to {trash!r}: {e}. "
                    f"The trash folder may not exist on the server. "
                    f"Set the right trash folder under account settings. "
                    f"(MOVE attempt: {move_err})"
                ) from e
            if typ != "OK":
                raise RuntimeError(
                    f"COPY to {trash!r} returned {typ}: {data!r}. "
                    f"Trash folder probably doesn't exist on this server — "
                    f"check your account settings. (MOVE attempt: {move_err})"
                )

            # COPY succeeded → mark source as deleted and expunge.
            typ, data = c.uid("STORE", str(uid), "+FLAGS", r"(\Deleted)")
            if typ != "OK":
                # Source still has the message; trash now has a copy. Not a
                # disaster, but worth telling the user.
                raise RuntimeError(
                    f"Copy to trash succeeded but STORE \\Deleted on source "
                    f"failed: {data!r}. Source message is duplicated.")
            c.expunge()

    def move_message(self, acc, src_folder: str, uid: int, dst_folder: str):
        """Move a message between two folders.

        Tries IMAP MOVE first (RFC 6851 - atomic, supported by Gmail,
        Fastmail, Dovecot 2.1+). Falls back to COPY+STORE+EXPUNGE on servers
        without MOVE. Refuses to expunge the source if the COPY failed - that
        would silently destroy the message."""
        if src_folder == dst_folder:
            return  # nothing to do
        with self._lock(acc):
            c = self._ensure(acc)
            typ, _ = c.select(self._quote(src_folder), readonly=False)
            if typ != "OK":
                raise RuntimeError(f"could not select source folder {src_folder!r}")

            # Try MOVE first.
            move_err = None
            try:
                typ, data = c.uid("MOVE", str(uid), self._quote(dst_folder))
                if typ == "OK":
                    return
                move_err = f"MOVE returned {typ}: {data!r}"
            except imaplib.IMAP4.error as e:
                move_err = f"MOVE not supported / failed: {e}"
            except Exception as e:
                move_err = f"MOVE error: {e}"

            # Fallback: COPY then STORE \Deleted then EXPUNGE.
            try:
                typ, data = c.uid("COPY", str(uid), self._quote(dst_folder))
            except imaplib.IMAP4.error as e:
                raise RuntimeError(
                    f"Could not move to {dst_folder!r}: {e}. "
                    f"The destination folder may not exist. "
                    f"(MOVE attempt: {move_err})"
                ) from e
            if typ != "OK":
                raise RuntimeError(
                    f"COPY to {dst_folder!r} returned {typ}: {data!r}. "
                    f"Destination folder may not exist. "
                    f"(MOVE attempt: {move_err})"
                )

            typ, data = c.uid("STORE", str(uid), "+FLAGS", r"(\Deleted)")
            if typ != "OK":
                raise RuntimeError(
                    f"COPY to {dst_folder!r} succeeded but STORE \\Deleted on "
                    f"source failed: {data!r}. Message is now duplicated."
                )
            c.expunge()


class WebSmtp:
    """SMTP send (synchronous). Each send opens a new connection — same model
    as the desktop app, simplest correct behaviour."""

    @staticmethod
    def send(acc, to_addrs: List[str], cc_addrs: List[str], bcc_addrs: List[str],
             subject: str, body_text: str, body_html: str,
             attachments: List[Tuple[str, bytes]],
             in_reply_to: str = "", references: str = "") -> Tuple[str, bytes]:
        """Returns (Message-ID, raw RFC 822 bytes). Raw bytes are returned so
        the caller can IMAP APPEND a copy to the Sent folder — most SMTP
        servers do not auto-save sent mail; the client has to do it."""
        import email.utils as _eu
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from email.mime.base import MIMEBase
        from email import encoders as _enc
        import smtplib

        # Outer container
        msg = MIMEMultipart("mixed") if attachments else MIMEMultipart("alternative")
        from_disp = (f"{acc.real_name} <{acc.email_addr}>"
                     if acc.real_name else acc.email_addr)
        msg["From"] = from_disp
        if to_addrs: msg["To"] = ", ".join(to_addrs)
        if cc_addrs: msg["Cc"] = ", ".join(cc_addrs)
        msg["Subject"] = subject or ""
        msg["Date"] = _eu.formatdate(localtime=True)
        domain = acc.email_addr.split("@", 1)[-1] if "@" in acc.email_addr else "localhost"
        msg["Message-ID"] = _eu.make_msgid(domain=domain)
        if in_reply_to:
            msg["In-Reply-To"] = in_reply_to
        if references:
            msg["References"] = references

        # Body — multipart/alternative goes inside multipart/mixed if there
        # are attachments, otherwise the outer container IS the alternative.
        if attachments:
            alt = MIMEMultipart("alternative")
            alt.attach(MIMEText(body_text or "", "plain", "utf-8"))
            if body_html:
                alt.attach(MIMEText(body_html, "html", "utf-8"))
            msg.attach(alt)
            for fname, data in attachments:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(data)
                _enc.encode_base64(part)
                part.add_header("Content-Disposition",
                                f'attachment; filename="{fname}"')
                msg.attach(part)
        else:
            msg.attach(MIMEText(body_text or "", "plain", "utf-8"))
            if body_html:
                msg.attach(MIMEText(body_html, "html", "utf-8"))

        # Serialize using BytesGenerator with linesep='\r\n'. This is the
        # correct way to produce SMTP-compliant message bytes in Python 3:
        # - CRLF line endings (required by SMTP DATA and IMAP APPEND)
        # - maxheaderlen=998 enforces RFC 5321 header line limits
        # - mangle_from_=False avoids mangling "From " at line starts
        # msg.as_bytes() uses the legacy compat32 policy which produces
        # bare LF line endings and doesn't enforce line length limits,
        # causing some SMTP servers to return "501 Syntax error - line too long".
        import io as _io, email.generator as _eg
        _buf = _io.BytesIO()
        _eg.BytesGenerator(
            _buf, mangle_from_=False, maxheaderlen=998,
        ).flatten(msg, linesep="\r\n")
        msg_bytes = _buf.getvalue()

        ctx = _ssl_context()

        def _attempt_send():
            s = WebSmtp._connect(acc, ctx)
            try:
                s.login(acc.smtp_user, acc.smtp_pass)
                all_recipients = (list(to_addrs) + list(cc_addrs)
                                  + list(bcc_addrs))
                # Remove socket timeout for the DATA transfer so large
                # attachments don't time out mid-stream. The server's own
                # idle timeout (typically 10+ min) is the effective limit.
                try: s.sock.settimeout(300)   # 5 min hard cap, not None
                except Exception: pass
                s.sendmail(acc.smtp_user, all_recipients, msg_bytes)
            finally:
                try: s.quit()
                except Exception:
                    try: s.close()
                    except Exception: pass

        # One automatic retry on unexpected disconnect. IONOS and some other
        # servers close idle connections quickly; the first attempt may land
        # on a connection that was silently closed between TCP connect and
        # DATA. A second attempt with a fresh connection succeeds.
        import smtplib as _smtplib
        try:
            _attempt_send()
        except (_smtplib.SMTPServerDisconnected, ConnectionResetError,
                BrokenPipeError, OSError) as first_err:
            sys.stderr.write(
                f"[smtp] First attempt failed ({first_err!r}), retrying...\n")
            try:
                _attempt_send()
            except Exception:
                raise  # surface the second error, not the first

        return msg["Message-ID"], msg_bytes

    @staticmethod
    def _connect(acc, ctx) -> "smtplib.SMTP":
        """Open an SMTP connection using the account's SSL settings.

        If implicit SSL (smtp_ssl=True) fails with WRONG_VERSION_NUMBER,
        automatically retries with STARTTLS. This handles the common
        misconfiguration where smtp_ssl=True is set for a port-587 STARTTLS
        server, or when the server temporarily refuses an implicit-SSL
        connection. The corrected method is not persisted — the user should
        update their settings if this fallback fires every time."""
        if acc.smtp_ssl:
            try:
                s = smtplib.SMTP_SSL(acc.smtp_host, acc.smtp_port,
                                     context=ctx, timeout=60)
                s.ehlo()
                return s
            except ssl.SSLError as e:
                if "WRONG_VERSION_NUMBER" not in str(e) and \
                   "wrong version" not in str(e).lower():
                    raise
                # Server is speaking plain text on this port — fall through
                # to STARTTLS. Typical cause: smtp_ssl=True on port 587.
                sys.stderr.write(
                    f"[smtp] SSL connect to {acc.smtp_host}:{acc.smtp_port} "
                    f"failed ({e}); retrying with STARTTLS.\n"
                )
        # Plain connection + optional STARTTLS
        s = smtplib.SMTP(acc.smtp_host, acc.smtp_port, timeout=60)
        s.ehlo()
        try:
            s.starttls(context=ctx)
            s.ehlo()
        except smtplib.SMTPNotSupportedError:
            pass  # Server doesn't support STARTTLS at all; continue plain.
        return s


# =============================================================================
# Push notifications: EventBus + per-account IDLE watchers
#
# IMAP IDLE (RFC 2177) lets the server tell the client when something changes
# without polling. We open one IDLE connection per account on the INBOX,
# translate untagged EXISTS / EXPUNGE / FETCH responses into events, and
# broadcast them on a bus that any number of connected browsers can subscribe
# to via Server-Sent Events. Heartbeats keep both ends alive; the IDLE has
# to be re-issued every ~29 minutes per the RFC.
# =============================================================================

import queue as _queue


class EventBus:
    """Thread-safe broadcast queue. Subscribers each get their own bounded
    queue; a slow consumer just gets dropped events (instead of blocking the
    publisher)."""

    def __init__(self):
        self._subs: List[_queue.Queue] = []
        self._lock = threading.Lock()

    def subscribe(self) -> "_queue.Queue":
        q: "_queue.Queue" = _queue.Queue(maxsize=64)
        with self._lock:
            self._subs.append(q)
        return q

    def unsubscribe(self, q: "_queue.Queue"):
        with self._lock:
            try: self._subs.remove(q)
            except ValueError: pass

    def emit(self, event: dict):
        with self._lock:
            for q in list(self._subs):
                try:
                    q.put_nowait(event)
                except _queue.Full:
                    # Don't block the IDLE thread on a stalled SSE reader.
                    pass


class IdleWatcher:
    """One thread per account: connects IMAP, SELECTs INBOX, runs IDLE, and
    fires `folder_change` events on the bus when the server signals activity.

    Lifecycle:
      start() — spin up the thread
      stop()  — flag for graceful exit; thread will close on next 5s tick

    Auto-reconnects with exponential backoff on errors (5s → 10s → ... → 120s)
    so a flaky connection won't kill push for the whole session."""

    def __init__(self, acc, bus: EventBus, folder: str = "INBOX"):
        self.acc = acc
        self.bus = bus
        self.folder = folder
        self.stop_evt = threading.Event()
        self.thread = threading.Thread(
            target=self._run, daemon=True,
            name=f"IDLE-{acc.email_addr}-{folder}"
        )

    def start(self): self.thread.start()
    def stop(self):  self.stop_evt.set()

    def _run(self):
        backoff = 5.0
        while not self.stop_evt.is_set():
            try:
                self._idle_session()
                # Clean exit (probably stop requested) — reset backoff.
                backoff = 5.0
            except Exception as e:
                sys.stderr.write(
                    f"[idle] {self.acc.email_addr}/{self.folder}: "
                    f"{_fmt_exc(e)}\n"
                )
            if self.stop_evt.wait(backoff):
                break
            backoff = min(backoff * 2, 120.0)

    def _idle_session(self):
        ctx = _ssl_context()
        if self.acc.imap_ssl:
            c = imaplib.IMAP4_SSL(self.acc.imap_host, self.acc.imap_port,
                                  ssl_context=ctx, timeout=30)
        else:
            c = imaplib.IMAP4(self.acc.imap_host, self.acc.imap_port, timeout=30)
            try: c.starttls(ssl_context=ctx)
            except Exception: pass
        try:
            c.login(self.acc.imap_user, self.acc.imap_pass)
            c.select(WebImap._quote(self.folder), readonly=True)

            # Outer loop: re-issue IDLE every <29 minutes per RFC 2177.
            while not self.stop_evt.is_set():
                tag = c._new_tag()
                tag_b = tag.encode("ascii") if isinstance(tag, str) else tag
                try:
                    c.send(tag_b + b" IDLE\r\n")
                except Exception:
                    return  # connection dropped; outer _run loop reconnects

                line = c.readline()
                if not line.startswith(b"+"):
                    return  # server didn't accept IDLE

                idle_started = time.monotonic()
                # Short readline timeout so we can periodically re-check
                # stop_evt and the 28-minute IDLE renewal cap.
                try: c.sock.settimeout(5.0)
                except Exception: pass

                while not self.stop_evt.is_set():
                    if time.monotonic() - idle_started > 28 * 60:
                        break
                    try:
                        resp = c.readline()
                    except (socket.timeout, OSError):
                        continue
                    if not resp:
                        raise RuntimeError("IDLE connection closed")
                    if (b"EXISTS" in resp or b"EXPUNGE" in resp or
                            b"FETCH" in resp or b"RECENT" in resp):
                        self.bus.emit({
                            "type": "folder_change",
                            "account": self.acc.email_addr,
                            "folder": self.folder,
                        })

                # Send DONE, drain its tagged response, then loop.
                try: c.sock.settimeout(30.0)
                except Exception: pass
                try:
                    c.send(b"DONE\r\n")
                except Exception:
                    return
                while True:
                    line = c.readline()
                    if not line:
                        return
                    if line.startswith(tag_b + b" "):
                        break
        finally:
            try: c.logout()
            except Exception:
                try: c.shutdown()
                except Exception: pass


# =============================================================================
# Process state
# =============================================================================

class _State:
    def __init__(self):
        self.accounts: List = []
        self.imap = WebImap()
        self.cache: Optional[Any] = None
        self.contacts: Optional[Any] = None
        self.bus = EventBus()
        self.idle_watchers: List[IdleWatcher] = []
        # In-memory cache for remote images fetched via /proxy.
        self.remote_cache: Dict[str, Tuple[str, bytes]] = {}
        self._remote_cache_lock = threading.Lock()
        self.REMOTE_CACHE_MAX = 500
        # Synchronous in-memory body store: (account, folder, uid) -> body_html.
        # Written immediately (not via the async SQLite queue) so that
        # allow_remote=1 requests can read the body_html the instant the user
        # clicks "Load remote content", without waiting for the SQLite writer
        # thread to commit.  Capped at 200 entries (LRU-by-insertion).
        self._body_store: "Dict[tuple, str]" = {}
        self._body_store_lock = threading.Lock()
        self.BODY_STORE_MAX = 200

    def boot(self):
        self.accounts = load_accounts()
        self.cache = MessageCache(CACHE_FILE)
        self.contacts = AddressBook(CACHE_FILE)
        self._start_idle()

    def _start_idle(self):
        for acc in self.accounts:
            if not acc.is_valid():
                continue
            w = IdleWatcher(acc, self.bus)
            w.start()
            self.idle_watchers.append(w)

    def stop_idle(self):
        for w in self.idle_watchers:
            w.stop()
        self.idle_watchers = []

    def restart_idle(self):
        """Called after accounts are added / edited / removed."""
        self.stop_idle()
        self._start_idle()


_state = _State()


# =============================================================================
# Embedded UI (HTML, CSS, JS) — single-file ethos.
# =============================================================================

INDEX_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#cc0000">
<title>Email of Death</title>
<link rel="stylesheet" href="/style.css">
<link rel="icon" type="image/png" href="/skull.png">
<link rel="icon" type="image/x-icon" href="/favicon.ico" sizes="16x16 32x32 48x48">
<link rel="shortcut icon" href="/favicon.ico">
<link rel="manifest" href="/manifest.json">
</head>
<body>

<header class="topbar">
  <div class="brand">
    <img src="/skull.png" class="brand-skull" alt="">
    <div class="brand-text">
      <div class="brand-title">Email of Death</div>
      <div class="brand-sub">Death's Head Software</div>
    </div>
  </div>
  <div class="toolbar">
    <button id="btn-compose" disabled>New</button>
    <button id="btn-reply" disabled>Reply</button>
    <button id="btn-reply-all" disabled title="Reply to all recipients">Reply All</button>
    <button id="btn-forward" disabled>Forward</button>
    <button id="btn-mark-unread" disabled title="Mark as unread">◎</button>
    <button id="btn-delete" disabled>Delete</button>
    <button id="btn-refresh">Refresh</button>
    <button id="btn-threaded" title="Toggle threaded view">≣</button>
    <button id="btn-settings" title="Manage accounts">⚙</button>
  </div>
  <div class="search">
    <input type="search" id="q" placeholder="Search this folder..." disabled>
  </div>
</header>

<main class="grid">
  <aside class="pane sidebar" id="sidebar">
    <div class="loading">Loading accounts...</div>
  </aside>

  <section class="pane msglist">
    <div class="msglist-head" id="msglist-head">No folder selected</div>
    <div class="msglist-rows" id="msglist-rows"></div>
    <div class="msglist-footer" id="msglist-footer" hidden>
      <button id="btn-load-more">Load more…</button>
      <span id="msglist-count-label"></span>
    </div>
  </section>

  <section class="pane viewer" id="viewer">
    <div class="empty" id="empty">
      <img src="/skull.png" class="empty-skull" alt="">
      <div class="empty-caption" id="empty-caption">Select a message</div>
    </div>
    <div class="msg" id="msg" hidden>
      <button class="msg-close" id="msg-close" title="Close (Esc)">×</button>
      <header class="msg-head">
        <h1 class="msg-subj" id="msg-subj"></h1>
        <div class="msg-meta">
          <div><span class="lbl">From:</span> <span id="msg-from"></span></div>
          <div><span class="lbl">To:</span> <span id="msg-to"></span></div>
          <div><span class="lbl">Date:</span> <span id="msg-date"></span></div>
        </div>
      </header>
      <div class="msg-remote-bar" id="remote-bar" hidden>
        <span>Remote content blocked.</span>
        <button id="btn-load-remote">Load remote content</button>
      </div>
      <iframe class="msg-body" id="msg-body"
              sandbox="allow-same-origin allow-popups allow-popups-to-escape-sandbox"></iframe>
      <div class="msg-attach" id="msg-attach" hidden></div>
    </div>
  </section>
</main>

<div class="statusbar">
  <span id="status">Ready.</span>
  <span id="count" class="count"></span>
</div>

<!-- Compose modal ------------------------------------------------------- -->
<div class="modal" id="compose-modal" hidden>
  <div class="modal-backdrop" id="compose-backdrop"></div>
  <div class="modal-box">
    <div class="modal-head">
      <span class="modal-title" id="compose-title">New Message</span>
      <button class="modal-close" id="compose-close" title="Close">×</button>
    </div>
    <div class="modal-body">
      <div class="cf-row">
        <label>From</label>
        <select id="cf-from"></select>
      </div>
      <div class="cf-row">
        <label>To</label>
        <div class="cf-inputwrap">
          <input type="text" id="cf-to" autocomplete="off"
                 placeholder="recipient@example.com, ...">
          <div class="autosuggest" id="suggest-to" hidden></div>
        </div>
      </div>
      <div class="cf-row">
        <label>Cc</label>
        <div class="cf-inputwrap">
          <input type="text" id="cf-cc" autocomplete="off">
          <div class="autosuggest" id="suggest-cc" hidden></div>
        </div>
      </div>
      <div class="cf-row">
        <label>Bcc</label>
        <div class="cf-inputwrap">
          <input type="text" id="cf-bcc" autocomplete="off">
          <div class="autosuggest" id="suggest-bcc" hidden></div>
        </div>
      </div>
      <div class="cf-row">
        <label>Subject</label>
        <input type="text" id="cf-subj">
      </div>
      <div class="cf-attach-list" id="cf-attach-list" hidden></div>
      <div class="cf-toolbar" id="cf-toolbar">
        <button type="button" data-cmd="bold" title="Bold (Ctrl+B)"><b>B</b></button>
        <button type="button" data-cmd="italic" title="Italic (Ctrl+I)"><i>I</i></button>
        <button type="button" data-cmd="underline" title="Underline (Ctrl+U)"><u>U</u></button>
        <button type="button" data-cmd="strikeThrough" title="Strikethrough"><s>S</s></button>
        <span class="cf-tb-sep"></span>
        <button type="button" data-cmd="insertUnorderedList" title="Bulleted list">•</button>
        <button type="button" data-cmd="insertOrderedList" title="Numbered list">1.</button>
        <span class="cf-tb-sep"></span>
        <button type="button" data-cmd="createLink" title="Insert link">🔗</button>
        <button type="button" data-cmd="removeFormat" title="Clear formatting">∅</button>
      </div>
      <div class="cf-body" id="cf-body" contenteditable="true"
           data-placeholder="Write your message..."></div>
    </div>
    <div class="modal-foot">
      <input type="file" id="cf-files" multiple hidden>
      <button type="button" id="cf-attach">Attach...</button>
      <span class="cf-attach-info" id="cf-attach-info"></span>
      <span class="spacer"></span>
      <button type="button" id="cf-save-draft">Save Draft</button>
      <button type="button" id="cf-cancel">Cancel</button>
      <button type="button" id="cf-send" class="primary">Send</button>
    </div>
  </div>
</div>

<!-- Settings modal (list of accounts, Add button) ---------------------- -->
<div class="modal" id="settings-modal" hidden>
  <div class="modal-backdrop" id="settings-backdrop"></div>
  <div class="modal-box settings-box">
    <div class="modal-head">
      <span class="modal-title">Accounts</span>
      <button class="modal-close" id="settings-close" title="Close">×</button>
    </div>
    <div class="modal-body">
      <div class="acct-rows" id="acct-rows"></div>
    </div>
    <div class="modal-foot">
      <span class="spacer"></span>
      <button type="button" id="btn-add-account" class="primary">+ Add Account</button>
    </div>
  </div>
</div>

<!-- Account form modal (new/edit) -------------------------------------- -->
<div class="modal modal-top" id="account-modal" hidden>
  <div class="modal-backdrop" id="account-backdrop"></div>
  <div class="modal-box account-box">
    <div class="modal-head">
      <span class="modal-title" id="account-title">Add Account</span>
      <button class="modal-close" id="account-close" title="Close">×</button>
    </div>
    <div class="modal-body">
      <div class="af-section">
        <div class="cf-row">
          <label>Email</label>
          <input type="email" id="af-email" autocomplete="off"
                 placeholder="you@example.com">
        </div>
        <div class="cf-row">
          <label>Name</label>
          <input type="text" id="af-name" autocomplete="off"
                 placeholder="Personal Gmail (label)">
        </div>
        <div class="cf-row">
          <label>Real name</label>
          <input type="text" id="af-real-name" autocomplete="off"
                 placeholder="Sin (shows on outgoing mail)">
        </div>
        <div class="cf-row">
          <label>Password</label>
          <input type="password" id="af-password" autocomplete="new-password"
                 placeholder="">
        </div>
      </div>

      <div class="af-hint" id="af-hint" hidden></div>

      <div class="af-advanced-toggle">
        <button type="button" id="af-toggle-advanced" class="link-btn">
          ▸ Advanced (server settings)
        </button>
      </div>

      <div class="af-advanced" id="af-advanced" hidden>
        <div class="af-cols">
          <fieldset class="af-col">
            <legend>IMAP (incoming)</legend>
            <div class="cf-row">
              <label>Host</label>
              <input type="text" id="af-imap-host">
            </div>
            <div class="cf-row">
              <label>Port</label>
              <input type="number" id="af-imap-port" min="1" max="65535">
            </div>
            <div class="cf-row">
              <label>User</label>
              <input type="text" id="af-imap-user" autocomplete="off">
            </div>
            <div class="cf-row">
              <label></label>
              <label class="cf-check">
                <input type="checkbox" id="af-imap-ssl" checked> SSL/TLS
              </label>
            </div>
          </fieldset>
          <fieldset class="af-col">
            <legend>SMTP (outgoing)</legend>
            <div class="cf-row">
              <label>Host</label>
              <input type="text" id="af-smtp-host">
            </div>
            <div class="cf-row">
              <label>Port</label>
              <input type="number" id="af-smtp-port" min="1" max="65535">
            </div>
            <div class="cf-row">
              <label>User</label>
              <input type="text" id="af-smtp-user" autocomplete="off">
            </div>
            <div class="cf-row">
              <label></label>
              <label class="cf-check">
                <input type="checkbox" id="af-smtp-ssl"> SSL/TLS
                <input type="checkbox" id="af-smtp-starttls"
                       style="margin-left: 12px;"> STARTTLS
              </label>
            </div>
            <div class="cf-row">
              <label>Password</label>
              <input type="password" id="af-smtp-pass" autocomplete="new-password"
                     placeholder="(uses main password)">
            </div>
          </fieldset>
        </div>

        <fieldset class="af-col af-folders">
          <legend>Folders (optional — auto-detected from server if blank)</legend>
          <div class="cf-row">
            <label>Trash</label>
            <input type="text" id="af-trash-folder"
                   placeholder="auto (Trash / Deleted Items / [Gmail]/Trash / Papierkorb / ...)">
          </div>
          <div class="cf-row">
            <label>Sent</label>
            <input type="text" id="af-sent-folder"
                   placeholder="auto">
          </div>
          <div class="cf-row">
            <label>Drafts</label>
            <input type="text" id="af-drafts-folder"
                   placeholder="auto">
          </div>
          <div class="af-folders-hint">
            Set these manually if Delete or Send-to-Sent isn't working —
            usually because your server doesn't advertise RFC 6154 SPECIAL-USE
            flags. The exact name must match what your server reports
            (e.g. <code>INBOX/Trash</code>, not just <code>Trash</code>).
          </div>
        </fieldset>
      </div>

      <div class="af-test-result" id="af-test-result" hidden></div>
    </div>
    <div class="modal-foot">
      <button type="button" id="af-test">Test connection</button>
      <button type="button" id="af-delete" class="danger" hidden>Delete</button>
      <span class="spacer"></span>
      <button type="button" id="af-cancel">Cancel</button>
      <button type="button" id="af-save" class="primary">Save</button>
    </div>
  </div>
</div>

<!-- Right-click context menu for message rows ----------------------------- -->
<!-- Right-click context menu for message rows ----------------------------- -->
<div id="ctx-menu" class="ctx-menu" hidden>
  <button id="ctx-open"        class="ctx-item">Open</button>
  <div class="ctx-sep"></div>
  <button id="ctx-reply"       class="ctx-item">↩ Reply</button>
  <button id="ctx-reply-all"   class="ctx-item">↩↩ Reply All</button>
  <button id="ctx-forward"     class="ctx-item">↪ Forward</button>
  <button id="ctx-edit-draft"  class="ctx-item">✎ Edit as Draft</button>
  <div class="ctx-sep"></div>
  <button id="ctx-flag"        class="ctx-item">☆ Star</button>
  <button id="ctx-mark-unread" class="ctx-item">◎ Mark as Unread</button>
  <button id="ctx-move"        class="ctx-item">→ Move to...</button>
  <div class="ctx-sep"></div>
  <button id="ctx-delete"      class="ctx-item danger">⌫ Delete</button>
</div>

<!-- Right-click context menu for sidebar folder rows --------------------- -->
<div id="folder-ctx-menu" class="ctx-menu" hidden>
  <button id="fctx-empty-trash" class="ctx-item danger">⌫ Empty Trash</button>
</div>

<!-- Move-to-folder picker dialog ------------------------------------------ -->
<div id="move-modal" class="modal" hidden>
  <div class="modal-card move-card">
    <div class="modal-head">
      <h2>Move to folder</h2>
      <button class="modal-x" id="move-x">×</button>
    </div>
    <div class="modal-body">
      <input type="search" id="move-filter"
             placeholder="Filter folders..." autocomplete="off">
      <div class="move-folder-list" id="move-folder-list"></div>
    </div>
    <div class="modal-foot">
      <span class="spacer"></span>
      <button type="button" id="move-cancel">Cancel</button>
    </div>
  </div>
</div>

<script src="/app.js"></script>
</body>
</html>
"""

STYLE_CSS = """
* { box-sizing: border-box; }
:root {
  --bg-0: #0d0d0d;
  --bg-1: #141414;
  --bg-2: #1a1a1a;
  --bg-3: #2a2a2a;
  --fg-0: #e0e0e0;
  --fg-1: #aaaaaa;
  --fg-2: #888888;
  --fg-3: #666666;
  --accent: #ff1a1a;
  --accent-dim: #cc0000;
  --accent-bg: #3a0606;
  --accent-glow: rgba(255, 26, 26, 0.35);
  --selection: #8a0000;
  --warn: #ff6060;
}

html, body {
  margin: 0; padding: 0; height: 100%;
  background: var(--bg-0); color: var(--fg-0);
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  font-size: 14px;
  overflow: hidden;
}
body { display: flex; flex-direction: column; }

/* The HTML `hidden` attribute applies `display: none` implicitly, but any
   explicit `display:` rule beats it. Force it for our hidden=true elements. */
[hidden] { display: none !important; }

/* topbar ------------------------------------------------------------ */
.topbar {
  display: flex; align-items: center; gap: 16px;
  padding: 6px 12px;
  background: var(--bg-1);
  border-bottom: 1px solid var(--bg-3);
  flex: 0 0 auto;
}
.brand { display: flex; align-items: center; gap: 10px; min-width: 220px; }
.brand-skull { width: 36px; height: 36px; filter: drop-shadow(0 0 4px var(--accent-glow)); }
.brand-title { color: var(--accent); font-weight: 700; font-size: 16px; letter-spacing: 0.5px; }
.brand-sub   { color: var(--fg-2);  font-size: 11px; }

.toolbar { display: flex; gap: 4px; flex: 1; }
.toolbar button {
  background: var(--bg-2);
  color: var(--fg-0);
  border: 1px solid var(--bg-3);
  padding: 6px 14px;
  font-family: inherit;
  font-size: 13px;
  cursor: pointer;
  border-radius: 2px;
  transition: background 0.08s, border-color 0.08s, color 0.08s;
}
.toolbar button:hover:not(:disabled) {
  background: var(--accent-bg); border-color: var(--accent-dim); color: var(--warn);
}
.toolbar button:disabled { opacity: 0.4; cursor: default; }
.toolbar button:active:not(:disabled) { background: var(--selection); }
.toolbar button.active {
  background: var(--accent-bg);
  border-color: var(--accent-dim);
  color: var(--warn);
}
/* Flag/star button glows gold when the message is flagged */
#btn-flag.flagged {
  color: #e0b030;
  border-color: #a07820;
  background: #2a1f00;
}

/* load-more footer */
.msglist-footer {
  flex: 0 0 auto;
  display: flex; align-items: center; gap: 10px;
  padding: 6px 12px;
  border-top: 1px solid var(--bg-3);
  background: var(--bg-1);
}
.msglist-footer button {
  background: var(--bg-2); color: var(--fg-1);
  border: 1px solid var(--bg-3);
  padding: 4px 14px; cursor: pointer;
  font-family: inherit; font-size: 12px;
  border-radius: 2px;
}
.msglist-footer button:hover {
  background: var(--accent-bg); color: var(--warn);
  border-color: var(--accent-dim);
}
#msglist-count-label { color: var(--fg-2); font-size: 11px; }

/* Thread children get a left rule indicating reply depth. The padding-left
   itself is set per-row in JS based on depth. */
.msglist-rows .row.threaded {
  border-left: 1px solid var(--bg-3);
}
.msglist-rows .row.threaded.selected { border-left-color: var(--accent); }

.search input {
  background: var(--bg-2); color: var(--fg-0);
  border: 1px solid var(--bg-3);
  padding: 6px 10px; min-width: 240px;
  font-family: inherit; font-size: 13px;
  border-radius: 2px;
}
.search input:focus { outline: none; border-color: var(--accent-dim); }

/* layout ----------------------------------------------------------- */
.grid {
  display: grid;
  grid-template-columns: 220px 380px 1fr;
  flex: 1;
  min-height: 0;
}
.pane {
  background: var(--bg-0);
  overflow: auto;
  min-width: 0;
}
.pane + .pane { border-left: 1px solid var(--bg-3); }

/* sidebar ---------------------------------------------------------- */
.sidebar { background: var(--bg-1); }
.sidebar .acct-block { border-bottom: 1px solid var(--bg-3); padding: 4px 0; }
.sidebar .acct-name {
  padding: 8px 12px; color: var(--accent);
  font-weight: 700; font-size: 12px; text-transform: uppercase;
  letter-spacing: 0.6px; cursor: default;
}
.sidebar .acct-name.offline::after { content: " [offline]"; color: var(--fg-3); }
.sidebar .folder {
  display: flex; align-items: center; justify-content: space-between;
  padding: 6px 14px 6px 22px;
  cursor: pointer; user-select: none;
  border-left: 3px solid transparent;
  font-size: 13px;
}
.sidebar .folder:hover { background: var(--bg-2); }
.sidebar .folder.selected {
  background: var(--accent-bg);
  border-left-color: var(--accent);
  color: var(--warn);
}
.sidebar .folder .badge {
  background: var(--accent); color: white; padding: 1px 6px;
  border-radius: 10px; font-size: 10px; font-weight: 700;
}
.sidebar .loading { padding: 16px; color: var(--fg-2); font-style: italic; }

/* message list ----------------------------------------------------- */
.msglist { background: var(--bg-0); display: flex; flex-direction: column; }
.msglist-head {
  flex: 0 0 auto;
  padding: 8px 12px;
  background: var(--bg-1);
  border-bottom: 1px solid var(--bg-3);
  font-weight: 700; color: var(--accent);
  font-size: 13px; letter-spacing: 0.4px;
}
.msglist-rows { flex: 1; overflow: auto; }
.msglist-rows .row {
  display: grid;
  grid-template-columns: 26px 1fr 60px;
  grid-template-rows: auto auto;
  padding: 7px 12px 7px 0;
  border-bottom: 1px solid var(--bg-2);
  cursor: pointer;
  user-select: none;
  -webkit-user-select: none;
}
.msglist-rows .row:hover { background: var(--bg-1); }
.msglist-rows .row.selected {
  background: #5a0a0a;
  border-left: 4px solid #ff3030;
  padding-left: 0;
  box-shadow: inset 0 0 0 1px rgba(255, 48, 48, 0.35);
}
.msglist-rows .row.selected:hover { background: #6a0c0c; }
/* Star column */
.row-star {
  grid-column: 1; grid-row: 1 / 3;
  display: flex; align-items: center; justify-content: center;
  font-size: 15px;
  color: var(--fg-3);
  cursor: pointer;
  padding: 0 2px;
  transition: color 0.1s;
  -webkit-user-select: none; user-select: none;
}
.row-star:hover   { color: #e0b030; }
.row-star.starred { color: #e0b030; }
/* from/date/subj now in columns 2-3 */
.msglist-rows .row .from {
  grid-column: 2; grid-row: 1;
  color: var(--fg-1); font-size: 12px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.msglist-rows .row .date {
  grid-column: 3; grid-row: 1;
  color: var(--fg-2); font-size: 11px; text-align: right;
}
.msglist-rows .row .subj {
  grid-column: 2 / span 2; grid-row: 2;
  color: var(--fg-0); font-size: 14px;
  margin-top: 2px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.msglist-rows .row.unread .subj { font-weight: 700; color: white; }
.msglist-rows .row.unread .from { color: var(--fg-0); font-weight: 600; }
.msglist-rows .empty {
  padding: 24px; color: var(--fg-2); text-align: center; font-style: italic;
}

/* viewer ----------------------------------------------------------- */
.viewer { background: var(--bg-0); position: relative; display: flex; flex-direction: column; }

.empty {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center;
  flex-direction: column; gap: 24px;
  pointer-events: none;
}
.empty-skull {
  width: 60%; max-width: 520px; max-height: 60%;
  opacity: 1;
  filter: drop-shadow(0 0 30px var(--accent-glow));
  user-select: none;
}
.empty-caption {
  color: var(--fg-3); font-size: 14px; letter-spacing: 1px;
  text-transform: uppercase;
}

.msg { display: flex; flex-direction: column; height: 100%; position: relative; }

.msg-close {
  position: absolute;
  top: 8px; right: 12px;
  width: 32px; height: 32px;
  background: transparent;
  color: var(--fg-2);
  border: 1px solid transparent;
  border-radius: 50%;
  font-size: 22px; line-height: 1;
  font-family: inherit;
  cursor: pointer;
  z-index: 5;
  transition: background 0.08s, color 0.08s, border-color 0.08s;
}
.msg-close:hover {
  background: var(--accent-bg);
  color: var(--warn);
  border-color: var(--accent-dim);
}
.msg-close:active { background: var(--selection); }

.msg-head {
  flex: 0 0 auto;
  padding: 14px 50px 12px 18px; /* extra right pad to clear close button */
  background: var(--bg-1);
  border-bottom: 1px solid var(--bg-3);
}
.msg-subj { margin: 0 0 8px; color: var(--accent); font-size: 18px; font-weight: 700; }
.msg-meta { color: var(--fg-2); font-size: 12px; line-height: 1.6; }
.msg-meta .lbl { color: var(--fg-3); margin-right: 4px; }

.msg-remote-bar {
  flex: 0 0 auto;
  background: var(--accent-bg);
  border-bottom: 1px solid var(--accent-dim);
  padding: 8px 14px;
  display: flex; justify-content: space-between; align-items: center;
}
.msg-remote-bar span { color: var(--warn); font-size: 13px; }
.msg-remote-bar button {
  background: var(--bg-1); color: var(--warn);
  border: 1px solid var(--accent-dim);
  padding: 4px 12px;
  font-family: inherit; font-size: 12px; cursor: pointer;
  border-radius: 2px;
}
.msg-remote-bar button:hover { background: var(--accent-dim); color: white; }

.msg-body {
  flex: 1; min-height: 0;
  border: 0;
  background: white; /* email html expects white bg as a default */
  width: 100%;
}

.msg-attach {
  flex: 0 0 auto;
  padding: 8px 14px;
  background: var(--bg-1);
  border-top: 1px solid var(--bg-3);
  display: flex; flex-wrap: wrap; gap: 8px;
}
.msg-attach .att {
  background: var(--bg-2); color: var(--accent);
  border: 1px solid var(--bg-3);
  padding: 4px 10px; cursor: pointer; font-size: 12px;
  border-radius: 2px;
}
.msg-attach .att:hover { background: var(--accent-bg); border-color: var(--accent-dim); }

/* status bar ------------------------------------------------------- */
.statusbar {
  flex: 0 0 auto;
  padding: 4px 12px;
  background: var(--bg-1);
  border-top: 1px solid var(--bg-3);
  font-size: 11px; color: var(--fg-2);
  display: flex; justify-content: space-between;
}
.statusbar .count { color: var(--fg-1); }

/* right-click context menu -------------------------------------------- */
.ctx-menu {
  position: fixed;
  z-index: 200;
  min-width: 180px;
  background: var(--bg-1);
  border: 1px solid var(--accent-dim);
  border-radius: 3px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.6), 0 0 0 1px var(--bg-3);
  padding: 4px 0;
  user-select: none;
}
.ctx-item {
  display: block; width: 100%;
  background: transparent; color: var(--fg-0);
  border: 0; text-align: left;
  padding: 8px 16px;
  font-family: inherit; font-size: 13px;
  cursor: pointer;
}
.ctx-item:hover { background: var(--accent-bg); color: var(--warn); }
.ctx-item:active { background: var(--selection); }
.ctx-item.danger { color: #ff6060; }
.ctx-item.danger:hover { background: var(--accent-bg); color: var(--warn); }
.ctx-item.ctx-flagged { color: #e0b030; }
.ctx-sep { height: 1px; background: var(--bg-3); margin: 4px 0; }

/* move-to-folder picker --------------------------------------------- */
.move-card { width: 420px; max-width: 90vw; max-height: 70vh; }
#move-filter {
  background: var(--bg-2); color: var(--fg-0);
  border: 1px solid var(--bg-3);
  padding: 8px 10px; font-family: inherit; font-size: 13px;
  border-radius: 2px;
  margin-bottom: 8px;
}
#move-filter:focus {
  outline: none; border-color: var(--accent-dim);
}
.move-folder-list {
  flex: 1 1 auto;
  overflow: auto;
  background: var(--bg-2);
  border: 1px solid var(--bg-3);
  border-radius: 2px;
  min-height: 200px;
  max-height: 50vh;
}
.move-folder-list .move-folder {
  padding: 8px 12px;
  cursor: pointer;
  border-bottom: 1px solid var(--bg-3);
  color: var(--fg-0); font-size: 13px;
  user-select: none;
}
.move-folder-list .move-folder:last-child { border-bottom: 0; }
.move-folder-list .move-folder:hover {
  background: var(--accent-bg);
  color: var(--warn);
}
.move-folder-list .move-folder.disabled {
  color: var(--fg-3);
  cursor: not-allowed;
  font-style: italic;
}
.move-folder-list .move-folder.disabled:hover {
  background: transparent;
  color: var(--fg-3);
}
.move-folder-list .move-folder-kind {
  color: var(--accent);
  font-size: 11px;
  margin-right: 6px;
  text-transform: uppercase;
}

/* scrollbars ------------------------------------------------------- */
::-webkit-scrollbar { width: 12px; height: 12px; }
::-webkit-scrollbar-track { background: var(--bg-0); }
::-webkit-scrollbar-thumb { background: var(--bg-3); }
::-webkit-scrollbar-thumb:hover { background: var(--accent-dim); }

/* modal (compose) ---------------------------------------------------- */
.modal {
  position: fixed; inset: 0;
  z-index: 100;
  display: flex; align-items: center; justify-content: center;
}
.modal-backdrop {
  position: absolute; inset: 0;
  background: rgba(0,0,0,0.7);
  backdrop-filter: blur(2px);
}
.modal-box {
  position: relative;
  width: 760px; max-width: 95vw;
  max-height: 90vh;
  background: var(--bg-1);
  border: 1px solid var(--accent-dim);
  border-radius: 4px;
  box-shadow: 0 0 40px var(--accent-glow);
  display: flex; flex-direction: column;
}
.modal-head {
  flex: 0 0 auto;
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 14px;
  background: var(--bg-2);
  border-bottom: 1px solid var(--bg-3);
  border-radius: 4px 4px 0 0;
}
.modal-title {
  color: var(--accent); font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.6px;
  font-size: 13px;
}
.modal-close {
  background: transparent;
  color: var(--fg-2);
  border: 1px solid transparent;
  width: 28px; height: 28px;
  border-radius: 50%;
  font-size: 20px; line-height: 1;
  cursor: pointer;
}
.modal-close:hover {
  background: var(--accent-bg);
  color: var(--warn);
  border-color: var(--accent-dim);
}
.modal-body {
  flex: 1 1 auto;
  overflow: auto;
  padding: 12px 14px;
  display: flex; flex-direction: column; gap: 8px;
  min-height: 0;
}
.modal-foot {
  flex: 0 0 auto;
  display: flex; align-items: center; gap: 8px;
  padding: 10px 14px;
  background: var(--bg-2);
  border-top: 1px solid var(--bg-3);
  border-radius: 0 0 4px 4px;
}
.modal-foot .spacer { flex: 1; }
.modal-foot button {
  background: var(--bg-1); color: var(--fg-0);
  border: 1px solid var(--bg-3);
  padding: 6px 16px; cursor: pointer;
  font-family: inherit; font-size: 13px;
  border-radius: 2px;
}
.modal-foot button:hover { background: var(--bg-2); border-color: var(--accent-dim); }
.modal-foot button:disabled { opacity: 0.5; cursor: default; }
.modal-foot button.primary {
  background: var(--accent-bg); color: var(--warn);
  border-color: var(--accent-dim);
  font-weight: 700;
}
.modal-foot button.primary:hover { background: var(--accent-dim); color: white; }
.cf-attach-info { color: var(--fg-2); font-size: 12px; }

.cf-row { display: flex; align-items: center; gap: 10px; }
.cf-row label {
  flex: 0 0 70px;
  text-align: right;
  color: var(--fg-2); font-size: 12px;
  text-transform: uppercase; letter-spacing: 0.4px;
}
.cf-inputwrap { flex: 1; position: relative; }
.cf-row input[type="text"],
.cf-row select {
  flex: 1;
  background: var(--bg-2); color: var(--fg-0);
  border: 1px solid var(--bg-3);
  padding: 6px 10px;
  font-family: inherit; font-size: 13px;
  border-radius: 2px;
  width: 100%;
}
.cf-row input:focus, .cf-row select:focus {
  outline: none; border-color: var(--accent-dim);
}

.cf-toolbar {
  display: flex; gap: 2px; align-items: center;
  padding: 2px 0;
}
.cf-toolbar button {
  background: var(--bg-2); color: var(--fg-0);
  border: 1px solid var(--bg-3);
  width: 30px; height: 28px;
  font-family: inherit; font-size: 13px;
  cursor: pointer;
  border-radius: 2px;
}
.cf-toolbar button:hover {
  background: var(--accent-bg); border-color: var(--accent-dim);
  color: var(--warn);
}
.cf-toolbar button:active,
.cf-toolbar button.active {
  background: var(--selection); color: white;
}
.cf-toolbar .cf-tb-sep {
  width: 1px; height: 18px;
  background: var(--bg-3);
  margin: 0 4px;
}

.cf-body {
  flex: 1; min-height: 240px; max-height: 380px;
  background: var(--bg-2); color: var(--fg-0);
  border: 1px solid var(--bg-3);
  padding: 10px;
  font-family: 'Segoe UI', system-ui, sans-serif;
  font-size: 14px;
  line-height: 1.45;
  border-radius: 2px;
  overflow: auto;
}
.cf-body:focus { outline: none; border-color: var(--accent-dim); }
/* Empty-state placeholder for contenteditable. */
.cf-body:empty::before {
  content: attr(data-placeholder);
  color: var(--fg-3);
  pointer-events: none;
}
.cf-body blockquote {
  margin: 8px 0 8px 4px;
  padding-left: 10px;
  border-left: 3px solid var(--bg-3);
  color: var(--fg-1);
}
.cf-body a { color: var(--warn); }

.cf-attach-list {
  display: flex; flex-wrap: wrap; gap: 6px;
  padding: 6px 0;
}
.cf-attach-list .att {
  background: var(--bg-2); color: var(--accent);
  border: 1px solid var(--bg-3);
  padding: 4px 10px;
  font-size: 12px;
  border-radius: 2px;
  display: flex; gap: 8px; align-items: center;
}
.cf-attach-list .att .x {
  cursor: pointer; color: var(--fg-3);
  font-size: 14px; line-height: 1;
}
.cf-attach-list .att .x:hover { color: var(--warn); }

/* address-book autosuggest dropdown */
.autosuggest {
  position: absolute;
  top: 100%; left: 0; right: 0;
  z-index: 10;
  background: var(--bg-1);
  border: 1px solid var(--accent-dim);
  border-top: 0;
  max-height: 240px;
  overflow: auto;
}
.autosuggest .item {
  padding: 6px 10px; cursor: pointer;
  font-size: 13px;
  display: flex; justify-content: space-between; gap: 12px;
  border-bottom: 1px solid var(--bg-3);
}
.autosuggest .item:last-child { border-bottom: 0; }
.autosuggest .item .name { color: var(--fg-0); }
.autosuggest .item .em   { color: var(--fg-2); font-size: 11px; }
.autosuggest .item.active,
.autosuggest .item:hover { background: var(--accent-bg); color: var(--warn); }

/* account management ------------------------------------------------- */
.modal-top { z-index: 110; }  /* account modal floats above settings modal */

.settings-box { width: 540px; max-width: 95vw; }
.account-box  { width: 720px; max-width: 95vw; }

/* Settings list of accounts */
.acct-rows { display: flex; flex-direction: column; gap: 4px; }
.acct-rows .acct-row {
  display: flex; align-items: center; gap: 12px;
  background: var(--bg-2);
  border: 1px solid var(--bg-3);
  border-radius: 2px;
  padding: 10px 12px;
}
.acct-rows .acct-row:hover { border-color: var(--accent-dim); }
.acct-rows .acct-row .info { flex: 1; min-width: 0; }
.acct-rows .acct-row .info .nm { color: var(--fg-0); font-weight: 600; }
.acct-rows .acct-row .info .em { color: var(--fg-2); font-size: 12px; }
.acct-rows .empty {
  padding: 24px; text-align: center; color: var(--fg-2); font-style: italic;
}
.acct-rows .acct-row .actions { display: flex; gap: 6px; }
.acct-rows .acct-row .actions button {
  background: var(--bg-1); color: var(--fg-1);
  border: 1px solid var(--bg-3);
  padding: 4px 12px; cursor: pointer;
  font-family: inherit; font-size: 12px;
  border-radius: 2px;
}
.acct-rows .acct-row .actions button:hover {
  background: var(--accent-bg); color: var(--warn);
  border-color: var(--accent-dim);
}

/* Account form */
.af-section { display: flex; flex-direction: column; gap: 8px; }

.af-hint {
  background: var(--accent-bg);
  border: 1px solid var(--accent-dim);
  border-left-width: 4px;
  padding: 8px 12px;
  color: var(--warn);
  font-size: 12px; line-height: 1.5;
  margin: 6px 0;
  border-radius: 2px;
}
.af-hint.error { color: var(--warn); }
.af-hint a { color: var(--warn); text-decoration: underline; }

.af-advanced-toggle { margin-top: 4px; }
.link-btn {
  background: transparent; border: 0; color: var(--fg-2);
  cursor: pointer; font-family: inherit; font-size: 12px;
  padding: 4px 0;
}
.link-btn:hover { color: var(--accent); }

.af-advanced { padding-top: 6px; }
.af-cols {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
.af-col {
  border: 1px solid var(--bg-3);
  border-radius: 2px;
  padding: 8px 10px;
  display: flex; flex-direction: column; gap: 6px;
  margin: 0;
}
.af-col legend {
  color: var(--accent); font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.4px;
  font-size: 11px;
  padding: 0 6px;
}
.af-col .cf-row label { flex: 0 0 50px; }
.af-folders { margin-top: 12px; }
.af-folders-hint {
  color: var(--fg-2);
  font-size: 11px;
  line-height: 1.5;
  padding-top: 6px;
}
.af-folders-hint code {
  background: var(--bg-3);
  color: var(--fg-1);
  padding: 1px 4px;
  border-radius: 2px;
  font-size: 10px;
}
.cf-check {
  display: flex; align-items: center; gap: 6px;
  color: var(--fg-1); font-size: 12px;
  text-transform: none !important;
  letter-spacing: 0 !important;
  text-align: left !important;
}
.cf-check input[type="checkbox"] { margin: 0; }

.af-test-result {
  display: flex; flex-direction: column; gap: 6px;
  margin-top: 8px;
  padding: 10px;
  background: var(--bg-2);
  border: 1px solid var(--bg-3);
  border-radius: 2px;
  font-size: 12px;
}
.af-test-result .line { display: flex; align-items: flex-start; gap: 8px; }
.af-test-result .badge {
  flex: 0 0 50px;
  font-weight: 700;
  padding: 2px 6px;
  font-size: 11px;
  border-radius: 2px;
  text-align: center;
  text-transform: uppercase;
}
.af-test-result .badge.ok   { background: #1f4f1f; color: #c0ffc0; }
.af-test-result .badge.bad  { background: var(--accent-bg); color: var(--warn); }
.af-test-result .badge.skip { background: var(--bg-3); color: var(--fg-2); }
.af-test-result .msg { flex: 1; color: var(--fg-1); word-break: break-word; }
.af-test-result .hints {
  margin: 4px 0 0; padding-left: 18px; color: var(--fg-2);
  font-size: 11px; line-height: 1.5;
  white-space: pre-wrap;
}

.modal-foot button.danger {
  background: var(--accent-bg); color: var(--warn);
  border-color: var(--accent-dim);
}
.modal-foot button.danger:hover { background: #aa0000; color: white; }
"""

APP_JS = r"""
// Email of Death — web edition frontend.
// Vanilla JS, no build step, no framework. Three panes + topbar + statusbar.

const $ = (id) => document.getElementById(id);

const State = {
  accounts: [],
  current: { account: null, folder: null, uid: null },
  headers: [],
  selectedRow: null,
  selectedUids: new Set(),  // current multi-selection (may be 0, 1, or N)
  anchorUid: null,          // last single-clicked or ctrl-clicked row; the
                            // pivot that shift-click ranges extend from
  currentMessage: null,
  threaded: false,
};

// -------- API ---------------------------------------------------------------

async function api(path, opts = {}) {
  const res = await fetch(path, opts);
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`${res.status} ${res.statusText}: ${text}`);
  }
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) return res.json();
  return res.text();
}

function status(text) { $("status").textContent = text; }
function count(text)  { $("count").textContent  = text; }

// -------- sidebar (accounts + folders) -------------------------------------

async function loadAccounts() {
  status("Loading accounts...");
  const accounts = await api("/api/accounts");
  State.accounts = accounts;
  renderSidebar();
  // Compose needs at least one account to send from.
  $("btn-compose").disabled = accounts.length === 0;
  status(`Ready. ${accounts.length} account(s) configured.`);

  // First-run friendliness: if no accounts are set up yet, pop the settings
  // modal automatically so the user can add one.
  if (accounts.length === 0) {
    setTimeout(openSettings, 300);
    return;
  }

  // Auto-load folders for each account in parallel.
  for (const acc of accounts) {
    loadFolders(acc.email).catch(err => {
      console.error("loadFolders", acc.email, err);
      status(`Connect failed for ${acc.email}: ${err.message}`);
    });
  }
}

function renderSidebar() {
  const root = $("sidebar");
  root.innerHTML = "";
  if (State.accounts.length === 0) {
    root.innerHTML = `
      <div class="loading" style="line-height: 1.5;">
        No accounts yet.<br>
        Click <strong>⚙</strong> above to add one.
      </div>`;
    return;
  }
  for (const acc of State.accounts) {
    const block = document.createElement("div");
    block.className = "acct-block";
    block.dataset.account = acc.email;

    const name = document.createElement("div");
    name.className = "acct-name";
    name.textContent = acc.name || acc.email;
    block.appendChild(name);

    const folderList = document.createElement("div");
    folderList.className = "folders";
    folderList.innerHTML = '<div class="loading" style="padding: 6px 14px; font-size: 11px;">Connecting...</div>';
    block.appendChild(folderList);

    root.appendChild(block);
  }
}

async function loadFolders(email) {
  const folders = await api(`/api/folders?account=${encodeURIComponent(email)}`);
  const block = document.querySelector(`.acct-block[data-account="${cssEscape(email)}"]`);
  if (!block) return;
  const list = block.querySelector(".folders");
  list.innerHTML = "";
  // Sort: inbox first, then drafts/sent/archive/junk/trash, then others alphabetically.
  const order = { inbox: 0, drafts: 1, sent: 2, archive: 3, junk: 4, trash: 5 };
  folders.sort((a, b) => {
    const ra = order[a.kind] ?? 9;
    const rb = order[b.kind] ?? 9;
    if (ra !== rb) return ra - rb;
    return a.name.localeCompare(b.name);
  });
  for (const f of folders) {
    const row = document.createElement("div");
    row.className = "folder";
    row.dataset.account = email;
    row.dataset.folder = f.name;
    row.dataset.kind = f.kind;
    const display = folderDisplay(f);
    row.innerHTML = `<span>${escapeHtml(display)}</span>`;
    row.addEventListener("click", () => selectFolder(email, f.name, row));
    row.addEventListener("contextmenu", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      openFolderCtxMenu(email, f.name, f.kind, ev.clientX, ev.clientY);
    });
    list.appendChild(row);
  }
  // Auto-select INBOX on first connect if nothing is selected yet. If we DO
  // have a current selection, re-apply the .selected highlight (renderSidebar
  // wipes the DOM each time loadAccounts runs).
  if (State.current.account === email && State.current.folder) {
    const sel = list.querySelector(
      `.folder[data-folder="${cssEscape(State.current.folder)}"]`);
    if (sel) sel.classList.add("selected");
  } else {
    const inbox = list.querySelector('.folder[data-kind="inbox"]');
    if (inbox && !State.current.account) inbox.click();
  }
}

function cssEscape(s) {
  // Minimal CSS attribute selector escape.
  return s.replace(/(["\\])/g, "\\$1");
}

// -------- message list -----------------------------------------------------

async function selectFolder(email, folder, rowEl) {
  // Highlight in sidebar.
  document.querySelectorAll(".sidebar .folder.selected").forEach(el => el.classList.remove("selected"));
  rowEl.classList.add("selected");

  State.current.account = email;
  State.current.folder = folder;
  State.current.uid = null;
  State.selectedUids.clear();
  State.anchorUid = null;
  State.currentLimit = 100;   // reset pagination on folder change
  $("msglist-head").textContent = folderDisplay(
    { kind: rowEl.dataset.kind, name: folder }
  );
  $("msglist-rows").innerHTML = '<div class="empty">Loading...</div>';
  $("msglist-footer").hidden = true;
  showEmptyViewer();
  status(`Loading ${folder}...`);

  try {
    const data = await api(
      `/api/messages?account=${encodeURIComponent(email)}` +
      `&folder=${encodeURIComponent(folder)}&limit=${State.currentLimit}`
    );
    State.headers = data.headers;
    State.folderTotal = data.total;
    renderMessages();
    updateLoadMore(data.headers.length, data.total);
    updateFolderBadge(email, folder, data.unseen);
    status(`${folder}: ${data.headers.length} message(s)`);
    count(`${data.total} total, ${data.unseen} unread`);
  } catch (err) {
    $("msglist-rows").innerHTML = `<div class="empty">Failed to load: ${escapeHtml(err.message)}</div>`;
    status(`Error loading ${folder}: ${err.message}`);
  }
}

function updateLoadMore(shown, total) {
  const footer = $("msglist-footer");
  if (shown < total) {
    $("msglist-count-label").textContent =
      `Showing ${shown} of ${total}`;
    footer.hidden = false;
  } else {
    footer.hidden = true;
  }
}

function updateFolderBadge(email, folder, unseen) {
  // Find the sidebar row for this folder and update its unread badge.
  const selector =
    `.acct-block[data-account="${cssEscape(email)}"] ` +
    `.folder[data-folder="${cssEscape(folder)}"]`;
  const row = document.querySelector(selector);
  if (!row) return;
  let badge = row.querySelector(".badge");
  if (unseen > 0) {
    if (!badge) {
      badge = document.createElement("span");
      badge.className = "badge";
      row.appendChild(badge);
    }
    badge.textContent = unseen > 99 ? "99+" : String(unseen);
  } else if (badge) {
    badge.remove();
  }
}

function renderMessages() {
  const root = $("msglist-rows");
  if (State.headers.length === 0) {
    root.innerHTML = '<div class="empty">(empty)</div>';
    return;
  }
  root.innerHTML = "";
  if (State.threaded) {
    renderThreadedRows(root);
  } else {
    for (const h of State.headers) {
      root.appendChild(makeRow(h, 0));
    }
  }
}

function makeRow(h, depth) {
  const row = document.createElement("div");
  row.className = "row" + (h.seen ? "" : " unread") + (depth > 0 ? " threaded" : "");
  row.dataset.uid = h.uid;
  if (depth > 0) {
    row.style.paddingLeft = (depth * 18) + "px";
  }
  const from = prettyAddr(h.from_addr);
  const date = formatDate(h.date_iso);
  const subj = h.subject || "(no subject)";
  const starred = !!h.flagged;
  row.innerHTML = `
    <span class="row-star${starred ? " starred" : ""}" title="${starred ? "Unstar" : "Star"}">${starred ? "★" : "☆"}</span>
    <div class="from">${escapeHtml(from)}</div>
    <div class="date">${escapeHtml(date)}</div>
    <div class="subj">${escapeHtml(subj)}</div>
  `;

  // Star click: toggle flag without opening the message.
  row.querySelector(".row-star").addEventListener("click", async (ev) => {
    ev.stopPropagation();
    ev.preventDefault();
    const starEl = ev.currentTarget;
    const nowFlagged = !starEl.classList.contains("starred");
    starEl.classList.toggle("starred", nowFlagged);
    starEl.textContent = nowFlagged ? "★" : "☆";
    starEl.title = nowFlagged ? "Unstar" : "Star";
    h.flagged = nowFlagged;
    if (State.currentMessage && State.current.uid === h.uid)
      State.currentMessage.flagged = nowFlagged;
    try {
      await api("/api/flag", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          account: State.current.account,
          folder:  State.current.folder,
          uid: h.uid, flagged: nowFlagged,
        }),
      });
      status(nowFlagged ? "Starred." : "Star removed.");
    } catch (err) {
      // Roll back.
      starEl.classList.toggle("starred", !nowFlagged);
      starEl.textContent = !nowFlagged ? "★" : "☆";
      h.flagged = !nowFlagged;
      if (State.currentMessage && State.current.uid === h.uid)
        State.currentMessage.flagged = !nowFlagged;
      status(`Star failed: ${err.message}`);
      alert(`Could not star message:\n\n${err.message}`);
    }
  });

  // Use 'click' rather than 'mousedown'. mousedown + preventDefault was
  // suppressing some browsers' modifier-key state tracking, causing
  // ctrl/shift+click to behave like a plain click and clobber the existing
  // selection instead of extending it. CSS user-select:none on .row
  // prevents the text-selection side effect we were trying to avoid.
  row.addEventListener("click", (ev) => {
    if (ev.button !== 0 && ev.button !== undefined) return;
    onRowClick(h.uid, row, ev);
  });
  row.addEventListener("contextmenu", (ev) => {
    ev.preventDefault();
    ev.stopPropagation();
    State.ctxUid     = h.uid;
    State.ctxAccount = State.current.account;
    State.ctxFolder  = State.current.folder;
    openCtxMenu(h.uid, ev.clientX, ev.clientY);
  });
  return row;
}

function renderThreadedRows(root) {
  const { roots, children } = computeThreads(State.headers);
  // Roots: newest thread on top. Children: oldest first (chronological reply
  // chain reads naturally that way).
  roots.sort((a, b) => (b.date_iso || "").localeCompare(a.date_iso || ""));

  function visit(h, depth, seen) {
    if (seen.has(h.msg_id)) return;  // cycle guard
    seen.add(h.msg_id);
    root.appendChild(makeRow(h, depth));
    const kids = (children.get(h.msg_id) || [])
      .slice()
      .sort((a, b) => (a.date_iso || "").localeCompare(b.date_iso || ""));
    for (const k of kids) visit(k, depth + 1, seen);
  }
  const seen = new Set();
  for (const r of roots) visit(r, 0, seen);
}

function computeThreads(headers) {
  // Build msg_id -> header index. Each message can either chain off
  // In-Reply-To (preferred) or the last reachable References entry.
  const byId = new Map();
  for (const h of headers) {
    if (h.msg_id) byId.set(h.msg_id, h);
  }
  const children = new Map();
  const placed = new Set();
  for (const h of headers) {
    if (!h.msg_id) continue;
    let parentId = null;
    if (h.in_reply_to && byId.has(h.in_reply_to) && h.in_reply_to !== h.msg_id) {
      parentId = h.in_reply_to;
    } else if (h.references) {
      const refs = h.references.match(/<[^>]+>/g) || [];
      for (let i = refs.length - 1; i >= 0; i--) {
        if (byId.has(refs[i]) && refs[i] !== h.msg_id) {
          parentId = refs[i];
          break;
        }
      }
    }
    if (parentId) {
      if (!children.has(parentId)) children.set(parentId, []);
      children.get(parentId).push(h);
      placed.add(h.msg_id);
    }
  }
  const roots = headers.filter(h => !h.msg_id || !placed.has(h.msg_id));
  return { roots, children };
}

// -------- message viewer ---------------------------------------------------

// Three-mode click handler. Mirrors OS file-manager conventions:
//   plain click   → single select (set anchor)
//   ctrl/cmd-click → toggle clicked row in/out (set anchor)
//   shift-click   → select range from anchor to clicked (anchor unchanged)
function onRowClick(uid, rowEl, ev) {
  const meta = ev.ctrlKey || ev.metaKey;
  const shift = ev.shiftKey;
  console.log(`[click] uid=${uid} ctrl=${meta} shift=${shift} button=${ev.button}`);

  if (shift && State.anchorUid != null) {
    selectRange(State.anchorUid, uid);
  } else if (meta) {
    toggleRowSelection(uid, rowEl);
    State.anchorUid = uid;
  } else {
    setSingleSelection(uid, rowEl);
    State.anchorUid = uid;
  }
  const selCount = document.querySelectorAll(".msglist-rows .row.selected").length;
  console.log(`[click] selected count: ${selCount}`);
  status(`${selCount} selected`);
  reflectSelectionInUI();
}

function setSingleSelection(uid, rowEl) {
  clearAllSelectionClasses();
  State.selectedUids.clear();
  State.selectedUids.add(uid);
  rowEl.classList.add("selected");
  State.selectedRow = rowEl;
}

function toggleRowSelection(uid, rowEl) {
  if (State.selectedUids.has(uid)) {
    State.selectedUids.delete(uid);
    rowEl.classList.remove("selected");
    if (State.selectedRow === rowEl) State.selectedRow = null;
  } else {
    State.selectedUids.add(uid);
    rowEl.classList.add("selected");
    State.selectedRow = rowEl;
  }
}

function selectRange(fromUid, toUid) {
  // Pull the rendered order; threading + flat both produce a flat NodeList.
  const rows = Array.from(
    document.querySelectorAll(".msglist-rows .row[data-uid]"));
  const fromIdx = rows.findIndex(r => parseInt(r.dataset.uid, 10) === fromUid);
  const toIdx   = rows.findIndex(r => parseInt(r.dataset.uid, 10) === toUid);
  if (fromIdx < 0 || toIdx < 0) {
    // Fall through to single-select if we lost track of either endpoint.
    const last = document.querySelector(`.msglist-rows .row[data-uid="${toUid}"]`);
    if (last) setSingleSelection(toUid, last);
    return;
  }
  const [start, end] = fromIdx <= toIdx ? [fromIdx, toIdx] : [toIdx, fromIdx];
  clearAllSelectionClasses();
  State.selectedUids.clear();
  for (let i = start; i <= end; i++) {
    const r = rows[i];
    r.classList.add("selected");
    State.selectedUids.add(parseInt(r.dataset.uid, 10));
  }
  State.selectedRow = rows[toIdx];
}

function clearAllSelectionClasses() {
  document.querySelectorAll(".msglist-rows .row.selected")
    .forEach(el => el.classList.remove("selected"));
}

// React to whatever's currently selected: empty → skull, exactly 1 → load and
// show the message, 2+ → multi-select panel with delete affordance.
function reflectSelectionInUI() {
  const n = State.selectedUids.size;
  if (n === 0) {
    State.current.uid = null;
    State.currentMessage = null;
    showEmptyViewer();
    enableMessageActions(false);
    enableMultiActions(false);
    return;
  }
  if (n === 1) {
    const uid = [...State.selectedUids][0];
    State.current.uid = uid;
    enableMultiActions(false);
    loadAndShowMessage(uid);
    return;
  }
  // 2+ selected: keep skull visible, swap caption to count.
  State.current.uid = null;
  State.currentMessage = null;
  showMultiSelectViewer(n);
  enableMessageActions(false);  // can't reply/forward to many at once
  enableMultiActions(true);
}

function showMultiSelectViewer(n) {
  $("msg").hidden = true;
  $("empty").hidden = false;
  $("empty-caption").textContent = `${n} messages selected`;
  // Clear the iframe (defensive — see showEmptyViewer).
  try {
    const ifr = $("msg-body");
    if (ifr.contentDocument) {
      ifr.contentDocument.open();
      ifr.contentDocument.write("");
      ifr.contentDocument.close();
    }
  } catch (e) { /* ignore */ }
}

function enableMultiActions(enabled) {
  $("btn-delete").disabled = !enabled && State.selectedUids.size === 0;
  // Update the Delete button label to show how many are selected so the
  // user can verify the multi-select actually worked before clicking.
  const btn = $("btn-delete");
  const n = document.querySelectorAll(".msglist-rows .row.selected").length;
  btn.textContent = n > 1 ? `Delete (${n})` : "Delete";
}

async function loadAndShowMessage(uid) {
  status("Loading message...");
  try {
    const msg = await api(
      `/api/message?account=${encodeURIComponent(State.current.account)}` +
      `&folder=${encodeURIComponent(State.current.folder)}&uid=${uid}`
    );
    renderMessage(msg);
    State.currentMessage = msg;
    // Mark seen visually + on server.
    const rowEl = document.querySelector(
      `.msglist-rows .row[data-uid="${uid}"]`);
    if (rowEl && rowEl.classList.contains("unread")) {
      rowEl.classList.remove("unread");
      api("/api/mark_seen", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          account: State.current.account, folder: State.current.folder,
          uid: uid, seen: true,
        }),
      }).catch(() => {});
    }
    status("Ready.");
    enableMessageActions(true);
  } catch (err) {
    status(`Failed to load message: ${err.message}`);
  }
}

function renderMessage(msg) {
  $("empty").hidden = true;
  $("msg").hidden = false;
  $("msg-subj").textContent = msg.subject || "(no subject)";
  $("msg-from").textContent = msg.from_addr || "";
  $("msg-to").textContent = msg.to_addrs || "";
  $("msg-date").textContent = msg.date_iso || "";

  // Render the body HTML inside an iframe for isolation.
  const iframe = $("msg-body");
  const bodyHtml = msg.body_html_safe ||
    `<pre style="font-family: monospace; white-space: pre-wrap; padding: 16px;">${escapeHtml(msg.body_text || "")}</pre>`;
  // The iframe content is written via contentDocument.write(), which gives the
  // document an opaque origin (about:blank). Relative URLs in the HTML — like
  // the /proxy?url=... rewritten by the server — would resolve against
  // about:blank and fetch nothing. The <base> tag overrides that so every
  // relative URL resolves against our local server.
  const baseTag = `<base href="${window.location.origin}/">`;
  const html = bodyHtml.includes("<head")
    ? bodyHtml.replace(/(<head[^>]*>)/i, `$1${baseTag}`)
    : baseTag + bodyHtml;
  iframe.removeAttribute("srcdoc");
  iframe.contentDocument.open();
  iframe.contentDocument.write(html);
  iframe.contentDocument.close();

  $("remote-bar").hidden = !msg.has_remote_blocked;
  // Re-enable the button on every new message render. Without this, after
  // any successful "Load remote content" click the button stays disabled,
  // so the next email with remote content shows the bar with a dead button —
  // looks exactly like load remote broke.
  $("btn-load-remote").disabled = false;

  const attachBar = $("msg-attach");
  if (msg.attachments && msg.attachments.length > 0) {
    attachBar.hidden = false;
    attachBar.innerHTML = "";
    for (const a of msg.attachments) {
      const btn = document.createElement("a");
      btn.className = "att";
      btn.textContent = `${a.filename} (${Math.round(a.size / 1024)} KB)`;
      btn.href = `/api/attachment?account=${encodeURIComponent(State.current.account)}` +
                 `&folder=${encodeURIComponent(State.current.folder)}` +
                 `&uid=${State.current.uid}&index=${a.index}`;
      btn.download = a.filename;
      attachBar.appendChild(btn);
    }
  } else {
    attachBar.hidden = true;
    attachBar.innerHTML = "";
  }
}

function showEmptyViewer() {
  $("msg").hidden = true;
  $("empty").hidden = false;
  $("empty-caption").textContent = "Select a message";
  enableMessageActions(false);
  State.currentMessage = null;
  // Clear the iframe so the previous message's HTML doesn't sit in memory and
  // can't briefly flash if the panel is shown again.
  try {
    const ifr = $("msg-body");
    if (ifr.contentDocument) {
      ifr.contentDocument.open();
      ifr.contentDocument.write("");
      ifr.contentDocument.close();
    }
  } catch (e) { /* ignore */ }
}

function enableMessageActions(enabled) {
  $("btn-reply").disabled       = !enabled;
  $("btn-reply-all").disabled   = !enabled;
  $("btn-forward").disabled     = !enabled;
  $("btn-delete").disabled      = !enabled && State.selectedUids.size === 0;
  $("btn-mark-unread").disabled = !enabled;
}

// -------- load remote content ---------------------------------------------

$("btn-load-remote").addEventListener("click", async () => {
  if (!State.current.uid) return;
  $("btn-load-remote").disabled = true;
  status("Loading remote content...");
  try {
    // Returns instantly now -- just rewrites src to /proxy?url=...
    // The browser fetches images in parallel so they appear progressively.
    const msg = await api(
      `/api/message?account=${encodeURIComponent(State.current.account)}` +
      `&folder=${encodeURIComponent(State.current.folder)}` +
      `&uid=${State.current.uid}&allow_remote=1`
    );
    renderMessage(msg);
    $("remote-bar").hidden = true;
    status("Remote content loading...");
  } catch (err) {
    status(`Failed: ${err.message}`);
    $("btn-load-remote").disabled = false;
  }
});

// -------- toolbar wiring --------------------------------------------------

$("btn-refresh").addEventListener("click", () => {
  if (State.current.account && State.current.folder) {
    const rowEl = document.querySelector(".sidebar .folder.selected");
    if (rowEl) selectFolder(State.current.account, State.current.folder, rowEl);
  }
});

$("btn-threaded").addEventListener("click", () => {
  State.threaded = !State.threaded;
  $("btn-threaded").classList.toggle("active", State.threaded);
  if (State.headers.length > 0) renderMessages();
});

// ---- Load more (pagination) -----------------------------------------------

State.currentLimit = 100;
State.folderTotal  = 0;

$("btn-load-more").addEventListener("click", async () => {
  if (!State.current.account || !State.current.folder) return;
  State.currentLimit += 100;
  status("Loading more...");
  try {
    const data = await api(
      `/api/messages?account=${encodeURIComponent(State.current.account)}` +
      `&folder=${encodeURIComponent(State.current.folder)}` +
      `&limit=${State.currentLimit}`
    );
    State.headers = data.headers;
    State.folderTotal = data.total;
    renderMessages();
    updateLoadMore(data.headers.length, data.total);
    status(`${State.current.folder}: ${data.headers.length} message(s)`);
  } catch (err) {
    status(`Load more failed: ${err.message}`);
  }
});

// ---- Mark as unread -------------------------------------------------------

$("btn-mark-unread").addEventListener("click", async () => {
  const uid = State.current.uid;
  if (!uid) return;
  try {
    await api("/api/mark_seen", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        account: State.current.account,
        folder:  State.current.folder,
        uid:     uid,
        seen:    false,
      }),
    });
    // Re-bold the row in the list.
    const row = document.querySelector(`.msglist-rows .row[data-uid="${uid}"]`);
    if (row) row.classList.add("unread");
    status("Marked as unread.");
  } catch (err) {
    status(`Mark unread failed: ${err.message}`);
  }
});

// ---- Reply All ------------------------------------------------------------

$("btn-reply-all").addEventListener("click", () => {
  const msg = State.currentMessage;
  if (!msg) return;
  let subj = msg.subject || "";
  if (!/^re:/i.test(subj)) subj = "Re: " + subj;

  // Build recipient list: original From + all To + Cc minus our own address.
  const myEmail = State.current.account || "";
  const allTo = [msg.from_addr, msg.to_addrs, msg.cc_addrs]
    .filter(Boolean)
    .join(", ")
    .split(/[,;]/)
    .map(s => s.trim())
    .filter(s => s && !s.toLowerCase().includes(myEmail.toLowerCase()));
  const toStr = [...new Set(allTo)].join(", ");

  const refs = [];
  if (msg.references) refs.push(msg.references);
  if (msg.msg_id)     refs.push(msg.msg_id);

  openCompose({
    title: "Reply All",
    to:    toStr,
    subject: subj,
    body:  buildQuote(msg),
    in_reply_to: msg.msg_id || "",
    references:  refs.join(" "),
  });
});

// ---- Keyboard shortcuts ---------------------------------------------------
// j/k  = next/previous message
// r    = reply,  a = reply all,  f = forward
// d    = delete,  u = mark unread,  s = flag/star
// n    = compose new,  /  = focus search,  Esc = close viewer

document.addEventListener("keydown", (ev) => {
  // Don't intercept when user is typing in an input/textarea/contenteditable.
  const tag = document.activeElement.tagName;
  const isEditing = (
    tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" ||
    document.activeElement.getAttribute("contenteditable") === "true" ||
    !$("compose-modal").hidden || !$("settings-modal").hidden ||
    !$("account-modal").hidden
  );
  if (isEditing) return;

  switch (ev.key) {
    case "j": nextMessage(+1); ev.preventDefault(); break;
    case "k": nextMessage(-1); ev.preventDefault(); break;
    case "r": if (!$("btn-reply").disabled)     $("btn-reply").click();     break;
    case "a": if (!$("btn-reply-all").disabled) $("btn-reply-all").click(); break;
    case "f": if (!$("btn-forward").disabled)   $("btn-forward").click();   break;
    case "d": if (!$("btn-delete").disabled)    $("btn-delete").click();    break;
    case "u": if (!$("btn-mark-unread").disabled) $("btn-mark-unread").click(); break;
    case "n": if (!$("btn-compose").disabled)   $("btn-compose").click();   break;
    case "/": $("q").focus(); ev.preventDefault(); break;
    case "Escape":
      if (!$("msg").hidden) closeViewer();
      break;
  }
});

function nextMessage(dir) {
  const rows = Array.from(document.querySelectorAll(".msglist-rows .row[data-uid]"));
  if (rows.length === 0) return;
  const curIdx = rows.findIndex(r => parseInt(r.dataset.uid, 10) === State.current.uid);
  const nextIdx = (curIdx === -1)
    ? (dir > 0 ? 0 : rows.length - 1)
    : Math.max(0, Math.min(rows.length - 1, curIdx + dir));
  const nextRow = rows[nextIdx];
  if (nextRow && nextIdx !== curIdx) {
    const uid = parseInt(nextRow.dataset.uid, 10);
    setSingleSelection(uid, nextRow);
    State.anchorUid = uid;
    reflectSelectionInUI();
    nextRow.scrollIntoView({ block: "nearest" });
  }
}
function closeViewer() {
  // Drop selection from list so re-clicking the same row reopens it.
  clearAllSelectionClasses();
  State.selectedUids.clear();
  State.selectedRow = null;
  State.anchorUid = null;
  State.current.uid = null;
  showEmptyViewer();
}

$("msg-close").addEventListener("click", closeViewer);

$("btn-delete").addEventListener("click", async () => {
  // Read selection from the DOM — what the user visually sees as selected
  // is the source of truth. State.selectedUids can drift out of sync if
  // anything else (a message viewer load, an SSE refresh, a stray click)
  // touched it between the user's last selection action and now.
  const selectedRows = document.querySelectorAll(".msglist-rows .row.selected");
  const uids = Array.from(selectedRows).map(r => parseInt(r.dataset.uid, 10))
                                       .filter(u => !isNaN(u));
  if (uids.length === 0) {
    // Fall back to State.selectedUids if nothing visually selected (e.g.
    // 'd' keyboard shortcut on a single open message).
    uids.push(...State.selectedUids);
  }
  if (uids.length === 0) return;
  const confirmMsg = uids.length === 1
    ? `Move this message to ${State.current.account}'s trash?`
    : `Move ${uids.length} messages to ${State.current.account}'s trash?`;
  if (!confirm(confirmMsg)) return;
  status(uids.length === 1 ? "Deleting..." : `Deleting ${uids.length}...`);
  try {
    const res = await api("/api/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        account: State.current.account, folder: State.current.folder,
        uids: uids,
      }),
    });
    // Remove the rows that successfully deleted from the visible list.
    const ok = new Set(res.deleted || []);
    for (const uid of ok) {
      const row = document.querySelector(
        `.msglist-rows .row[data-uid="${uid}"]`);
      if (row) row.remove();
      State.selectedUids.delete(uid);
    }
    State.anchorUid = null;
    showEmptyViewer();
    enableMultiActions(false);
    if ((res.failed || []).length > 0) {
      status(`Deleted ${ok.size}, ${res.failed.length} failed.`);
    } else {
      status(uids.length === 1 ? "Deleted." : `Deleted ${ok.size} messages.`);
    }
    // Re-fetch headers shortly to reflect server state.
    setTimeout(() => $("btn-refresh").click(), 800);
  } catch (err) {
    status(`Delete failed: ${err.message}`);
  }
});

// -------- helpers ---------------------------------------------------------

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, c =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// Map folder kind (from server-side SPECIAL-USE flag detection) to a friendly
// display name. The IMAP folder name like "[Gmail]/Sent Mail" is correct on
// the wire but ugly in the sidebar.
function folderDisplay(f) {
  const map = {
    inbox: "Inbox",
    sent: "Sent",
    drafts: "Drafts",
    trash: "Trash",
    archive: "Archive",
    junk: "Spam",
    important: "Important",
    starred: "Starred",
    all: "All Mail",
    flagged: "Flagged",
  };
  return map[f.kind] || f.name;
}

function prettyAddr(addr) {
  if (!addr) return "";
  const m = addr.match(/^\s*"?([^"<]+?)"?\s*<.*>\s*$/);
  if (m) return m[1].trim();
  return addr;
}

function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d)) return iso;
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  if (sameDay) {
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  const sameYear = d.getFullYear() === today.getFullYear();
  if (sameYear) {
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  }
  return d.toLocaleDateString();
}

// -------- boot ------------------------------------------------------------

window.addEventListener("DOMContentLoaded", () => {
  loadAccounts().catch(err => {
    status(`Boot failed: ${err.message}`);
    console.error(err);
  });
});

// =====================================================================
// Compose / Reply / Forward
// =====================================================================

State.compose = { attachments: [], in_reply_to: "", references: "" };

function openCompose(opts = {}) {
  const m = $("compose-modal");
  m.hidden = false;

  const from = $("cf-from");
  from.innerHTML = "";
  for (const acc of State.accounts) {
    const o = document.createElement("option");
    o.value = acc.email;
    o.textContent = acc.real_name ? `${acc.real_name} <${acc.email}>` : acc.email;
    from.appendChild(o);
  }
  if (opts.from) from.value = opts.from;
  else if (State.current.account) from.value = State.current.account;

  $("cf-to").value   = opts.to || "";
  $("cf-cc").value   = opts.cc || "";
  $("cf-bcc").value  = opts.bcc || "";
  $("cf-subj").value = opts.subject || "";
  // Body is contenteditable now — write HTML into innerHTML. opts.body is
  // produced by buildQuote/buildForward as HTML, and is empty for new mail.
  $("cf-body").innerHTML = opts.body || "";

  State.compose.attachments  = opts.attachments || [];
  State.compose.in_reply_to  = opts.in_reply_to || "";
  State.compose.references   = opts.references  || "";

  $("compose-title").textContent = opts.title || "New Message";

  refreshAttachList();
  // Focus the first empty field, To if blank, otherwise body. For replies,
  // place the cursor at the very top of the body (before the quote).
  setTimeout(() => {
    if (!$("cf-to").value) {
      $("cf-to").focus();
    } else {
      const body = $("cf-body");
      body.focus();
      // Move caret to start so the user types above the quote.
      try {
        const sel = window.getSelection();
        const range = document.createRange();
        range.setStart(body, 0);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
      } catch (e) { /* ignore */ }
    }
  }, 50);
}

function closeCompose() {
  $("compose-modal").hidden = true;
  // Clear out heavy attachment data so the browser tab doesn't grow forever.
  State.compose.attachments = [];
}

$("compose-close").addEventListener("click", closeCompose);
$("compose-backdrop").addEventListener("click", closeCompose);
$("cf-cancel").addEventListener("click", closeCompose);

// ---- Save Draft -------------------------------------------------------------

$("cf-save-draft").addEventListener("click", async () => {
  const from = $("cf-from").value;
  if (!from) { status("Select a From account first."); return; }

  $("cf-save-draft").disabled = true;
  $("cf-save-draft").textContent = "Saving…";
  status("Saving draft...");

  try {
    const payload = collectComposePayload(from);
    const res = await api("/api/save_draft", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    status(`Draft saved to ${res.saved_to}.`);
    closeCompose();
  } catch (err) {
    status(`Save draft failed: ${err.message}`);
  } finally {
    $("cf-save-draft").disabled = false;
    $("cf-save-draft").textContent = "Save Draft";
  }
});

// Attachment handling -------------------------------------------------

function refreshAttachList() {
  const list = $("cf-attach-list");
  const info = $("cf-attach-info");
  const atts = State.compose.attachments;
  if (atts.length === 0) {
    list.hidden = true;
    list.innerHTML = "";
    info.textContent = "";
    return;
  }
  list.hidden = false;
  list.innerHTML = "";
  let total = 0;
  for (let i = 0; i < atts.length; i++) {
    const a = atts[i];
    total += approxBytesFromB64(a.data_b64);
    const tag = document.createElement("span");
    tag.className = "att";
    tag.innerHTML = `<span>${escapeHtml(a.filename)}</span><span class="x" title="Remove">×</span>`;
    tag.querySelector(".x").addEventListener("click", () => {
      State.compose.attachments.splice(i, 1);
      refreshAttachList();
    });
    list.appendChild(tag);
  }
  info.textContent = `${atts.length} attachment(s), ~${Math.round(total/1024)} KB`;
}

function approxBytesFromB64(b64) {
  if (!b64) return 0;
  // base64 size = 4*ceil(n/3); decoded ~= b64.length * 3/4 minus 0–2 padding
  return Math.floor(b64.length * 3 / 4);
}

$("cf-attach").addEventListener("click", () => $("cf-files").click());
$("cf-files").addEventListener("change", async (ev) => {
  const files = Array.from(ev.target.files || []);
  for (const f of files) {
    const att = await readFileAsBase64(f);
    State.compose.attachments.push(att);
  }
  ev.target.value = "";  // allow re-selecting the same file later
  refreshAttachList();
});

function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const result = String(r.result || "");
      const idx = result.indexOf(",");
      resolve({
        filename: file.name,
        content_type: file.type || "application/octet-stream",
        data_b64: idx >= 0 ? result.slice(idx + 1) : "",
      });
    };
    r.onerror = () => reject(new Error("Failed to read " + file.name));
    r.readAsDataURL(file);
  });
}

// Send ---------------------------------------------------------------

function collectComposePayload(account) {
  const bodyEl  = $("cf-body");
  return {
    account:     account || $("cf-from").value,
    to:          $("cf-to").value,
    cc:          $("cf-cc").value,
    bcc:         $("cf-bcc").value,
    subject:     $("cf-subj").value,
    body_text:   bodyEl.innerText || "",
    body_html:   bodyEl.innerHTML || "",
    attachments: State.compose.attachments,
    in_reply_to: State.compose.in_reply_to,
    references:  State.compose.references,
  };
}

$("cf-send").addEventListener("click", async () => {
  const from = $("cf-from").value;
  const payload = collectComposePayload(from);
  if (!payload.to.trim() && !payload.cc.trim() && !payload.bcc.trim()) {
    alert("Add at least one recipient.");
    return;
  }
  const btn = $("cf-send");
  btn.disabled = true;
  btn.textContent = "Sending...";
  status("Sending in background...");

  // Close compose immediately — the send is in a background thread.
  // The SSE send_result event will report success or failure.
  closeCompose();

  try {
    const res = await api("/api/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.queued) {
      // Background send started — result comes via SSE send_result event.
      // Job ID is stored so handlePushEvent can match it.
      State._pendingSendJobs = State._pendingSendJobs || {};
      State._pendingSendJobs[res.job_id] = true;
      status("Sending... (you'll be notified when complete)");
    } else if (res.saved_to_sent) {
      status(`Sent. Saved to ${res.saved_to_sent}.`);
    } else {
      status("Sent.");
    }
  } catch (err) {
    status(`Send failed: ${err.message}`);
    alert(`Send failed:\n\n${err.message}`);
  } finally {
    btn.disabled = false;
    btn.textContent = "Send";
  }
});

// Toolbar wiring (B/I/U/lists/link/clear formatting) ------------------

document.querySelectorAll("#cf-toolbar button[data-cmd]").forEach((btn) => {
  btn.addEventListener("click", (ev) => {
    ev.preventDefault();  // don't steal focus from the editor
    const cmd = btn.dataset.cmd;
    if (cmd === "createLink") {
      const url = prompt("Link URL:", "https://");
      if (url) document.execCommand("createLink", false, url);
    } else {
      document.execCommand(cmd, false, null);
    }
    $("cf-body").focus();
    updateToolbarState();
  });
  // Keep button mousedown from moving focus, which kills the selection.
  btn.addEventListener("mousedown", (ev) => ev.preventDefault());
});

function updateToolbarState() {
  // Reflect current cursor's formatting state on the toolbar buttons.
  document.querySelectorAll("#cf-toolbar button[data-cmd]").forEach((btn) => {
    const cmd = btn.dataset.cmd;
    let active = false;
    try { active = document.queryCommandState(cmd); } catch (e) {}
    btn.classList.toggle("active", active);
  });
}
$("cf-body").addEventListener("keyup", updateToolbarState);
$("cf-body").addEventListener("mouseup", updateToolbarState);

// Compose toolbar buttons -------------------------------------------

$("btn-compose").addEventListener("click", () => openCompose({}));

$("btn-reply").addEventListener("click", () => {
  const msg = State.currentMessage;
  if (!msg) return;
  let subj = msg.subject || "";
  if (!/^re:/i.test(subj)) subj = "Re: " + subj;
  // RFC 5322: References = old References + this message's Message-ID.
  const refs = [];
  if (msg.references) refs.push(msg.references);
  if (msg.msg_id)     refs.push(msg.msg_id);
  openCompose({
    title: "Reply",
    to: msg.from_addr,
    subject: subj,
    body: buildQuote(msg),
    in_reply_to: msg.msg_id || "",
    references:  refs.join(" "),
  });
});

$("btn-forward").addEventListener("click", () => {
  const msg = State.currentMessage;
  if (!msg) return;
  let subj = msg.subject || "";
  if (!/^fwd:/i.test(subj)) subj = "Fwd: " + subj;
  openCompose({
    title: "Forward",
    subject: subj,
    body: buildForward(msg),
  });
});

function buildQuote(msg) {
  // Produce an HTML quote with a <blockquote> for proper visual indent in the
  // contenteditable body. The opening blank lines push the user's cursor and
  // the original above the quote, matching every email client's convention.
  const date = msg.date_iso || "";
  const sender = msg.from_addr || "";
  const text = msg.body_text || htmlToText(msg.body_html_safe || "");
  const escapedText = escapeHtml(text).replace(/\n/g, "<br>");
  return (
    `<p></p><p></p>` +
    `<p>On ${escapeHtml(date)}, ${escapeHtml(sender)} wrote:</p>` +
    `<blockquote>${escapedText}</blockquote>`
  );
}

function buildForward(msg) {
  const text = msg.body_text || htmlToText(msg.body_html_safe || "");
  const escapedText = escapeHtml(text).replace(/\n/g, "<br>");
  return (
    `<p></p><p></p>` +
    `<p>---------- Forwarded message ----------</p>` +
    `<p>` +
    `<b>From:</b> ${escapeHtml(msg.from_addr || "")}<br>` +
    `<b>Date:</b> ${escapeHtml(msg.date_iso || "")}<br>` +
    `<b>Subject:</b> ${escapeHtml(msg.subject || "")}<br>` +
    `<b>To:</b> ${escapeHtml(msg.to_addrs || "")}` +
    `</p>` +
    `<div>${escapedText}</div>`
  );
}

function htmlToText(html) {
  if (!html) return "";
  const div = document.createElement("div");
  div.innerHTML = html;
  return (div.textContent || div.innerText || "").trim();
}

// =====================================================================
// Search
// =====================================================================

let _searchDebounce = null;

const searchEl = $("q");
searchEl.disabled = false;
searchEl.placeholder = "Search this folder (text or address)...";

searchEl.addEventListener("input", () => {
  if (_searchDebounce) clearTimeout(_searchDebounce);
  _searchDebounce = setTimeout(runSearch, 500);
});
searchEl.addEventListener("keydown", (ev) => {
  if (ev.key === "Enter") {
    if (_searchDebounce) clearTimeout(_searchDebounce);
    runSearch();
  } else if (ev.key === "Escape") {
    searchEl.value = "";
    runSearch();
  }
});

async function runSearch() {
  const q = searchEl.value.trim();
  if (!State.current.account || !State.current.folder) return;
  if (!q) {
    // Reset to fresh folder fetch.
    const rowEl = document.querySelector(".sidebar .folder.selected");
    if (rowEl) selectFolder(State.current.account, State.current.folder, rowEl);
    return;
  }
  status(`Searching for "${q}"...`);
  $("msglist-rows").innerHTML = '<div class="empty">Searching...</div>';
  try {
    const data = await api(
      `/api/search?account=${encodeURIComponent(State.current.account)}` +
      `&folder=${encodeURIComponent(State.current.folder)}` +
      `&q=${encodeURIComponent(q)}`
    );
    State.headers = data.headers;
    State.searchActive = true;
    renderMessages();
    status(`Search: ${data.headers.length} result(s) for "${q}"`);
  } catch (err) {
    status(`Search failed: ${err.message}`);
  }
}

// =====================================================================
// Address-book autocomplete (To/Cc/Bcc)
// =====================================================================

function attachAutocomplete(inputEl, popupEl) {
  let active = -1;
  let items = [];

  inputEl.addEventListener("input", async () => {
    const text = inputEl.value;
    const last = text.split(/[,;]/).pop().trim();
    if (last.length < 1) {
      hide(); return;
    }
    try {
      items = await api(`/api/contacts?q=${encodeURIComponent(last)}`);
      if (!items.length) { hide(); return; }
      render();
    } catch (e) { hide(); }
  });

  inputEl.addEventListener("keydown", (ev) => {
    if (popupEl.hidden) return;
    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      active = Math.min(active + 1, items.length - 1);
      paint();
    } else if (ev.key === "ArrowUp") {
      ev.preventDefault();
      active = Math.max(active - 1, 0);
      paint();
    } else if (ev.key === "Enter" && active >= 0) {
      ev.preventDefault();
      pick(items[active]);
    } else if (ev.key === "Escape") {
      hide();
    } else if (ev.key === "Tab" && active >= 0) {
      ev.preventDefault();
      pick(items[active]);
    }
  });

  inputEl.addEventListener("blur", () => {
    // Slight delay so click on item registers first
    setTimeout(hide, 120);
  });

  function render() {
    popupEl.innerHTML = "";
    items.forEach((c, i) => {
      const el = document.createElement("div");
      el.className = "item" + (i === active ? " active" : "");
      el.innerHTML = `<span class="name">${escapeHtml(c.name || c.email)}</span>` +
                     `<span class="em">${escapeHtml(c.email)}</span>`;
      el.addEventListener("mousedown", (ev) => { ev.preventDefault(); pick(c); });
      popupEl.appendChild(el);
    });
    active = 0;
    paint();
    popupEl.hidden = false;
  }

  function paint() {
    const els = popupEl.querySelectorAll(".item");
    els.forEach((el, i) => el.classList.toggle("active", i === active));
  }

  function pick(c) {
    const text = inputEl.value;
    const parts = text.split(/[,;]/);
    parts[parts.length - 1] = ` ${c.name ? `"${c.name}" <${c.email}>` : c.email}`;
    inputEl.value = parts.join(",").replace(/^\s+/, "") + ", ";
    hide();
    inputEl.focus();
  }

  function hide() {
    popupEl.hidden = true;
    active = -1;
    items = [];
  }
}

attachAutocomplete($("cf-to"),  $("suggest-to"));
attachAutocomplete($("cf-cc"),  $("suggest-cc"));
attachAutocomplete($("cf-bcc"), $("suggest-bcc"));

// =====================================================================
// Account management (settings modal + add/edit form)
// =====================================================================

State.editingEmail = null;          // null = new account; otherwise the email
                                    // being edited (primary key)
State.userTouched = new Set();      // form fields the user manually edited;
                                    // we won't overwrite these from provider
                                    // hints

// ---- Settings modal -----------------------------------------------

$("btn-settings").addEventListener("click", openSettings);
$("settings-close").addEventListener("click", closeSettings);
$("settings-backdrop").addEventListener("click", closeSettings);

function openSettings() {
  $("settings-modal").hidden = false;
  renderAccountsList();
}
function closeSettings() {
  $("settings-modal").hidden = true;
}

function renderAccountsList() {
  const root = $("acct-rows");
  root.innerHTML = "";
  if (State.accounts.length === 0) {
    root.innerHTML =
      '<div class="empty">No accounts yet. Click "+ Add Account" to begin.</div>';
    return;
  }
  for (const acc of State.accounts) {
    const row = document.createElement("div");
    row.className = "acct-row";
    row.innerHTML = `
      <div class="info">
        <div class="nm">${escapeHtml(acc.name || acc.email)}</div>
        <div class="em">${escapeHtml(acc.email)}</div>
      </div>
      <div class="actions">
        <button data-act="edit">Edit</button>
        <button data-act="delete">Delete</button>
      </div>
    `;
    row.querySelector('[data-act="edit"]').addEventListener("click",
      () => openAccountForm(acc.email));
    row.querySelector('[data-act="delete"]').addEventListener("click",
      () => deleteAccount(acc));
    root.appendChild(row);
  }
}

$("btn-add-account").addEventListener("click", () => openAccountForm(null));

async function deleteAccount(acc) {
  if (!confirm(`Delete account ${acc.email}?\n\nThis only removes it from this client. ` +
               `Your mail on the server is unaffected.`)) return;
  try {
    await api("/api/account/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email_addr: acc.email }),
    });
    // Refresh accounts list, sidebar, and the settings modal.
    await loadAccounts();
    renderAccountsList();
    // If the deleted account's folder was selected, reset.
    if (State.current.account === acc.email) {
      State.current.account = null;
      State.current.folder = null;
      $("msglist-rows").innerHTML = "";
      $("msglist-head").textContent = "No folder selected";
      showEmptyViewer();
    }
    status(`Removed ${acc.email}.`);
  } catch (err) {
    alert(`Delete failed:\n\n${err.message}`);
  }
}

// ---- Account form (new / edit) -------------------------------------

$("account-close").addEventListener("click",  closeAccountForm);
$("account-backdrop").addEventListener("click", closeAccountForm);
$("af-cancel").addEventListener("click",      closeAccountForm);

async function openAccountForm(email) {
  $("account-modal").hidden = false;
  State.editingEmail = email;
  State.userTouched = new Set();
  $("af-test-result").hidden = true;
  $("af-test-result").innerHTML = "";
  $("af-hint").hidden = true;
  $("af-hint").innerHTML = "";
  $("af-advanced").hidden = true;
  $("af-toggle-advanced").textContent = "▸ Advanced (server settings)";

  if (email) {
    // Edit mode: load existing account data, prefill the form.
    $("account-title").textContent = `Edit ${email}`;
    $("af-delete").hidden = false;
    try {
      const a = await api(`/api/account?email=${encodeURIComponent(email)}`);
      $("af-email").value     = a.email_addr;
      $("af-email").disabled  = true;  // can't change the primary key
      $("af-name").value      = a.name || "";
      $("af-real-name").value = a.real_name || "";
      $("af-password").value  = "";
      $("af-password").placeholder = a.imap_pass_set ? "(leave blank to keep saved)" : "";

      $("af-imap-host").value = a.imap_host;
      $("af-imap-port").value = a.imap_port;
      $("af-imap-user").value = a.imap_user;
      $("af-imap-ssl").checked = !!a.imap_ssl;

      $("af-smtp-host").value = a.smtp_host;
      $("af-smtp-port").value = a.smtp_port;
      $("af-smtp-user").value = a.smtp_user;
      $("af-smtp-ssl").checked = !!a.smtp_ssl;
      $("af-smtp-starttls").checked = !!a.smtp_starttls;
      $("af-smtp-pass").value = "";
      $("af-smtp-pass").placeholder = a.smtp_pass_set
        ? "(leave blank to keep saved)" : "(uses main password)";

      // Folder overrides — show whatever's currently set so the user can
      // see what auto-detection picked or correct it.
      $("af-trash-folder").value  = a.trash_folder  || "";
      $("af-sent-folder").value   = a.sent_folder   || "";
      $("af-drafts-folder").value = a.drafts_folder || "";

      // For an edit, expand advanced so the user can see what's there.
      toggleAdvanced(true);
    } catch (err) {
      alert(`Could not load account:\n\n${err.message}`);
      closeAccountForm();
      return;
    }
  } else {
    // New mode: reset to blanks.
    $("account-title").textContent = "Add Account";
    $("af-delete").hidden = true;
    [
      "af-email", "af-name", "af-real-name", "af-password",
      "af-imap-host", "af-imap-user",
      "af-smtp-host", "af-smtp-user", "af-smtp-pass",
      "af-trash-folder", "af-sent-folder", "af-drafts-folder",
    ].forEach(id => { $(id).value = ""; $(id).disabled = false; });
    $("af-imap-port").value = 993;
    $("af-smtp-port").value = 465;
    $("af-imap-ssl").checked = true;
    $("af-smtp-ssl").checked = true;
    $("af-smtp-starttls").checked = false;
    $("af-password").placeholder = "";
    $("af-smtp-pass").placeholder = "(uses main password)";
  }
  setTimeout(() => $("af-email").focus(), 50);
}

function closeAccountForm() {
  $("account-modal").hidden = true;
  State.editingEmail = null;
  State.userTouched = new Set();
}

// Track which fields the user has manually edited so provider auto-fill
// doesn't clobber their typing.
["af-imap-host", "af-imap-port", "af-imap-user",
 "af-smtp-host", "af-smtp-port", "af-smtp-user"].forEach(id => {
  $(id).addEventListener("input", () => State.userTouched.add(id));
});

// On email change: fetch provider hints and auto-fill any field the user
// hasn't manually touched.
let _hintDebounce = null;
$("af-email").addEventListener("input", () => {
  if (_hintDebounce) clearTimeout(_hintDebounce);
  _hintDebounce = setTimeout(applyProviderHints, 250);
  // Default IMAP/SMTP usernames to the email address (override-able).
  if (!State.userTouched.has("af-imap-user")) {
    $("af-imap-user").value = $("af-email").value;
  }
  if (!State.userTouched.has("af-smtp-user")) {
    $("af-smtp-user").value = $("af-email").value;
  }
});

async function applyProviderHints() {
  const em = $("af-email").value.trim();
  if (!em.includes("@")) {
    $("af-hint").hidden = true;
    return;
  }
  try {
    const res = await api(`/api/provider_hints?email=${encodeURIComponent(em)}`);
    if (!res.hints) {
      $("af-hint").hidden = true;
      return;
    }
    const h = res.hints;
    if (!State.userTouched.has("af-imap-host") && h.imap_host !== undefined)
      $("af-imap-host").value = h.imap_host;
    if (!State.userTouched.has("af-imap-port") && h.imap_port !== undefined)
      $("af-imap-port").value = h.imap_port;
    if (h.imap_ssl !== undefined) $("af-imap-ssl").checked = !!h.imap_ssl;

    if (!State.userTouched.has("af-smtp-host") && h.smtp_host !== undefined)
      $("af-smtp-host").value = h.smtp_host;
    if (!State.userTouched.has("af-smtp-port") && h.smtp_port !== undefined)
      $("af-smtp-port").value = h.smtp_port;
    if (h.smtp_ssl      !== undefined) $("af-smtp-ssl").checked      = !!h.smtp_ssl;
    if (h.smtp_starttls !== undefined) $("af-smtp-starttls").checked = !!h.smtp_starttls;

    if (h.note) {
      $("af-hint").innerHTML = escapeHtml(h.note).replace(/\n/g, "<br>");
      $("af-hint").classList.toggle("error", !!h.unsupported);
      $("af-hint").hidden = false;
    } else {
      $("af-hint").hidden = true;
    }
  } catch (err) {
    /* hints are non-critical; ignore failures */
  }
}

// Advanced section toggle
$("af-toggle-advanced").addEventListener("click", () =>
  toggleAdvanced($("af-advanced").hidden));

function toggleAdvanced(open) {
  $("af-advanced").hidden = !open;
  $("af-toggle-advanced").textContent = open
    ? "▾ Advanced (server settings)"
    : "▸ Advanced (server settings)";
}

// IMAP SSL and STARTTLS for SMTP are mutually exclusive in practice — clicking
// one usually means turning the other off.
$("af-smtp-ssl").addEventListener("change", () => {
  if ($("af-smtp-ssl").checked) $("af-smtp-starttls").checked = false;
});
$("af-smtp-starttls").addEventListener("change", () => {
  if ($("af-smtp-starttls").checked) $("af-smtp-ssl").checked = false;
});

// ---- Test connection ----------------------------------------------

$("af-test").addEventListener("click", async () => {
  const payload = readAccountForm();
  if (!payload.email_addr || !payload.imap_pass) {
    alert("Email and password are required to test.");
    return;
  }
  const btn = $("af-test");
  btn.disabled = true;
  btn.textContent = "Testing...";
  $("af-test-result").hidden = true;
  try {
    const r = await api("/api/test_account", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    renderTestResult(r);
  } catch (err) {
    renderTestResult({
      imap: { ok: false, message: err.message },
      smtp: { ok: false, message: err.message },
    });
  } finally {
    btn.disabled = false;
    btn.textContent = "Test connection";
  }
});

function renderTestResult(r) {
  const root = $("af-test-result");
  root.innerHTML = "";
  for (const proto of ["imap", "smtp"]) {
    const res = r[proto] || { ok: false, message: "" };
    const line = document.createElement("div");
    line.className = "line";
    let badgeClass, badgeText;
    if (res.ok)            { badgeClass = "ok";   badgeText = "OK"; }
    else if (res.message)  { badgeClass = "bad";  badgeText = "FAIL"; }
    else                   { badgeClass = "skip"; badgeText = "SKIP"; }

    let html = `<span class="badge ${badgeClass}">${proto.toUpperCase()}</span>` +
               `<div class="msg">${escapeHtml(res.message || "(skipped)")}`;
    if (res.hints && res.hints.length) {
      const hintHtml = res.hints.map(h => "• " + escapeHtml(h)).join("\n");
      html += `<div class="hints">${hintHtml}</div>`;
    }
    html += "</div>";
    line.innerHTML = html;
    root.appendChild(line);
  }
  root.hidden = false;
}

// ---- Save / Delete ------------------------------------------------

$("af-save").addEventListener("click", async () => {
  const payload = readAccountForm();
  if (!payload.email_addr) {
    alert("Email address is required.");
    return;
  }
  const btn = $("af-save");
  btn.disabled = true;
  btn.textContent = "Saving...";
  try {
    const r = await api("/api/account", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    closeAccountForm();
    await loadAccounts();
    renderAccountsList();
    status(r.is_new ? `Added ${r.email}.` : `Updated ${r.email}.`);
  } catch (err) {
    alert(`Save failed:\n\n${err.message}`);
  } finally {
    btn.disabled = false;
    btn.textContent = "Save";
  }
});

$("af-delete").addEventListener("click", async () => {
  if (!State.editingEmail) return;
  const acc = State.accounts.find(a => a.email === State.editingEmail) ||
              { email: State.editingEmail };
  closeAccountForm();
  deleteAccount(acc);
});

function readAccountForm() {
  const out = {
    email_addr: $("af-email").value.trim(),
    name:       $("af-name").value.trim(),
    real_name:  $("af-real-name").value.trim(),
    imap_host:  $("af-imap-host").value.trim(),
    imap_port:  parseInt($("af-imap-port").value, 10) || 993,
    imap_user:  $("af-imap-user").value.trim(),
    imap_pass:  $("af-password").value,
    imap_ssl:   $("af-imap-ssl").checked,
    smtp_host:  $("af-smtp-host").value.trim(),
    smtp_port:  parseInt($("af-smtp-port").value, 10) || 465,
    smtp_user:  $("af-smtp-user").value.trim(),
    smtp_ssl:   $("af-smtp-ssl").checked,
    smtp_starttls: $("af-smtp-starttls").checked,
    smtp_pass:  $("af-smtp-pass").value,
    trash_folder:  $("af-trash-folder").value,
    sent_folder:   $("af-sent-folder").value,
    drafts_folder: $("af-drafts-folder").value,
  };
  // If the user only typed one password, mirror it to SMTP — the form's
  // single-password UX expects "Password" alone to mean both.
  if (out.imap_pass && !out.smtp_pass) {
    out.use_imap_pass_for_smtp = true;
  }
  return out;
}

// =====================================================================
// Push notifications via Server-Sent Events
//
// The server runs an IMAP IDLE thread per account. When the IMAP server
// signals activity (EXISTS/EXPUNGE/FETCH untagged response), the watcher
// emits a `folder_change` event on a bus, which the /events endpoint
// streams to every connected browser tab.
//
// The browser's EventSource auto-reconnects on errors, so we just wire up
// onmessage and let it be.
// =====================================================================

State.eventSource = null;
State._refreshDebounce = null;

function connectEvents() {
  if (typeof EventSource === "undefined") return;  // very old browser
  if (State.eventSource) {
    try { State.eventSource.close(); } catch (e) {}
  }
  const es = new EventSource("/events");
  State.eventSource = es;

  es.addEventListener("message", (ev) => {
    let event;
    try { event = JSON.parse(ev.data); }
    catch (e) { return; }
    handlePushEvent(event);
  });

  // EventSource auto-reconnects with a random delay (~3s default) on errors.
  // We don't have to do anything in onerror, but it's useful for status text.
  es.addEventListener("error", () => {
    // Gets fired on initial connect failure and any disconnect; suppress
    // the noisy reconnect chatter — just leave the existing status alone.
  });
}

function handlePushEvent(event) {
  if (event.type === "send_result") {
    const jobs = State._pendingSendJobs || {};
    if (!jobs[event.job_id]) return;
    delete jobs[event.job_id];
    if (!event.ok) {
      status(`Send failed: ${event.error}`);
      alert(`Your message could not be sent:\n\n${event.error}`);
      return;
    }
    if (event.saved_to_sent) {
      status(`Sent. Saved to ${event.saved_to_sent}.`);
    } else if (event.sent_error) {
      status("Sent. (Could not save to Sent folder.)");
      alert(
        "Your message was sent, but could not be saved to your Sent folder.\n\n" +
        "Error: " + event.sent_error + "\n\n" +
        "Check the Sent folder name in account settings."
      );
    } else {
      status("Sent.");
    }
    // Refresh Sent folder if currently viewing it.
    if (State.current.account === event.account) {
      const selFolder = document.querySelector(".sidebar .folder.selected");
      if (selFolder && selFolder.dataset.kind === "sent") {
        selectFolder(event.account, selFolder.dataset.folder, selFolder);
      }
    }
    return;
  }

  if (event.type !== "folder_change") return;
  if (event.account === State.current.account &&
      event.folder  === State.current.folder) {
    // Debounce — Gmail can push several EXISTS in a row during a sync.
    if (State._refreshDebounce) clearTimeout(State._refreshDebounce);
    State._refreshDebounce = setTimeout(backgroundRefreshFolder, 1500);
  } else {
    const folderName = event.folder === "INBOX" ? "Inbox" : event.folder;
    status(`New activity: ${event.account} (${folderName})`);
  }
}

// Background folder refresh — updates the message list WITHOUT touching the
// viewer or State.currentMessage. This is the fix for the star bug: the
// original handlePushEvent called selectFolder(), which calls showEmptyViewer(),
// which sets State.currentMessage = null, so clicking the star button after
// any IDLE push silently did nothing (the null guard fires and returns early).
async function backgroundRefreshFolder() {
  if (!State.current.account || !State.current.folder) return;
  try {
    const data = await api(
      `/api/messages?account=${encodeURIComponent(State.current.account)}` +
      `&folder=${encodeURIComponent(State.current.folder)}` +
      `&limit=${State.currentLimit}`
    );
    State.headers = data.headers;
    State.folderTotal = data.total;
    // Preserve the currently-selected row's highlight after re-render.
    const prevUid = State.current.uid;
    renderMessages();
    updateLoadMore(data.headers.length, data.total);
    updateFolderBadge(State.current.account, State.current.folder, data.unseen);
    // Re-apply selection highlight without triggering a message reload.
    if (prevUid) {
      const row = document.querySelector(`.msglist-rows .row[data-uid="${prevUid}"]`);
      if (row) row.classList.add("selected");
    }
    count(`${data.total} total, ${data.unseen} unread`);
  } catch (err) {
    // Non-critical; don't bother the user with a background refresh failure.
    console.warn("Background refresh failed:", err.message);
  }
}

// Boot the SSE client once accounts are loaded.
window.addEventListener("DOMContentLoaded", () => {
  connectEvents();
});

// =====================================================================
// Right-click context menu

const ctxMenu = $("ctx-menu");
State.ctxUid     = null;
State.ctxAccount = null;
State.ctxFolder  = null;

function openCtxMenu(uid, x, y) {
  // Reflect current flag state if we know it.
  const isCurrentMsg = State.currentMessage && State.currentMessage.uid === uid;
  const isFlagged = isCurrentMsg ? !!State.currentMessage.flagged : false;
  $("ctx-flag").textContent = isFlagged ? "★ Unstar" : "☆ Star";
  $("ctx-flag").classList.toggle("ctx-flagged", isFlagged);

  ctxMenu.hidden = false;
  const mw = ctxMenu.offsetWidth  || 190;
  const mh = ctxMenu.offsetHeight || 240;
  ctxMenu.style.left = Math.min(x, window.innerWidth  - mw - 8) + "px";
  ctxMenu.style.top  = Math.min(y, window.innerHeight - mh - 8) + "px";
}

function closeCtxMenu() { ctxMenu.hidden = true; }

document.addEventListener("click", closeCtxMenu);
document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape") { closeCtxMenu(); }
});
// Stop the menu's own clicks from bubbling to the document closer.
ctxMenu.addEventListener("click", (ev) => ev.stopPropagation());

// ---- Context menu actions --------------------------------------------------

// If the clicked row is the currently-loaded message, use State.currentMessage.
// If it's a different row, we need to load it first — ensureMessageLoaded does
// that lazily and calls back with the message object.
async function ensureMessageLoaded(uid, account, folder) {
  if (State.currentMessage && State.currentMessage.uid === uid) {
    return State.currentMessage;
  }
  const msg = await api(
    `/api/message?account=${encodeURIComponent(account)}` +
    `&folder=${encodeURIComponent(folder)}&uid=${uid}`
  );
  return msg;
}

$("ctx-open").addEventListener("click", () => {
  const uid = State.ctxUid;
  if (!uid) return;
  const row = document.querySelector(`.msglist-rows .row[data-uid="${uid}"]`);
  if (row) { setSingleSelection(uid, row); State.anchorUid = uid; reflectSelectionInUI(); }
});

$("ctx-reply").addEventListener("click", async () => {
  const { uid, account, folder } = { uid: State.ctxUid, account: State.ctxAccount, folder: State.ctxFolder };
  if (!uid) return;
  try {
    const msg = await ensureMessageLoaded(uid, account, folder);
    let subj = msg.subject || "";
    if (!/^re:/i.test(subj)) subj = "Re: " + subj;
    const refs = [msg.references, msg.msg_id].filter(Boolean).join(" ");
    openCompose({ title: "Reply", from: account, to: msg.from_addr,
                  subject: subj, body: buildQuote(msg),
                  in_reply_to: msg.msg_id || "", references: refs });
  } catch (e) { status("Reply failed: " + e.message); }
});

$("ctx-reply-all").addEventListener("click", async () => {
  const { uid, account, folder } = { uid: State.ctxUid, account: State.ctxAccount, folder: State.ctxFolder };
  if (!uid) return;
  try {
    const msg = await ensureMessageLoaded(uid, account, folder);
    let subj = msg.subject || "";
    if (!/^re:/i.test(subj)) subj = "Re: " + subj;
    const allTo = [msg.from_addr, msg.to_addrs, msg.cc_addrs]
      .filter(Boolean).join(", ").split(/[,;]/).map(s => s.trim())
      .filter(s => s && !s.toLowerCase().includes(account.toLowerCase()));
    const refs = [msg.references, msg.msg_id].filter(Boolean).join(" ");
    openCompose({ title: "Reply All", from: account,
                  to: [...new Set(allTo)].join(", "),
                  subject: subj, body: buildQuote(msg),
                  in_reply_to: msg.msg_id || "", references: refs });
  } catch (e) { status("Reply All failed: " + e.message); }
});

$("ctx-forward").addEventListener("click", async () => {
  const { uid, account, folder } = { uid: State.ctxUid, account: State.ctxAccount, folder: State.ctxFolder };
  if (!uid) return;
  try {
    const msg = await ensureMessageLoaded(uid, account, folder);
    let subj = msg.subject || "";
    if (!/^fwd:/i.test(subj)) subj = "Fwd: " + subj;
    // Fetch attachment bytes so they're forwarded with the message.
    const atts = await fetchAttachmentsForForward(msg, account, folder, uid);
    openCompose({
      title: "Forward", from: account, subject: subj,
      body: buildForward(msg), attachments: atts,
    });
  } catch (e) { status("Forward failed: " + e.message); }
});

// Fetch all attachments for a message in one API call for forwarding.
// Returns array of {filename, content_type, data_b64} ready for compose.
async function fetchAttachmentsForForward(msg, account, folder, uid) {
  console.log(`[fwd] fetchAttachmentsForForward uid=${uid}, msg.attachments=${JSON.stringify(msg.attachments)}`);
  if (!msg.attachments || msg.attachments.length === 0) {
    console.log("[fwd] no attachments on source message");
    return [];
  }
  try {
    const res = await api(
      `/api/attachments_bulk?account=${encodeURIComponent(account)}` +
      `&folder=${encodeURIComponent(folder)}&uid=${uid}`
    );
    console.log(`[fwd] bulk returned ${(res.attachments || []).length} attachment(s)`);
    return res.attachments || [];
  } catch (e) {
    console.error("[fwd] bulk fetch failed:", e);
    status(`Warning: could not fetch attachments for forward: ${e.message}`);
    return [];
  }
}

$("ctx-edit-draft").addEventListener("click", async () => {
  // Open a saved draft back into the compose window so the user can continue
  // editing it. Pre-fills To/Cc/Subject/body from the draft's headers.
  const { uid, account, folder } = { uid: State.ctxUid, account: State.ctxAccount, folder: State.ctxFolder };
  if (!uid) return;
  try {
    const msg = await ensureMessageLoaded(uid, account, folder);
    openCompose({
      title: "Edit Draft",
      from:    account,
      to:      msg.to_addrs   || "",
      cc:      msg.cc_addrs   || "",
      subject: msg.subject    || "",
      body:    msg.body_html  || msg.body_text || "",
      in_reply_to: msg.in_reply_to || "",
      references:  msg.references  || "",
    });
  } catch (e) { status("Could not open draft: " + e.message); }
});

$("ctx-flag").addEventListener("click", async () => {
  const { uid, account, folder } = { uid: State.ctxUid, account: State.ctxAccount, folder: State.ctxFolder };
  if (!uid) return;
  const msg = (State.currentMessage && State.currentMessage.uid === uid)
              ? State.currentMessage : null;
  const wasFlagged = msg ? !!msg.flagged : false;
  const nowFlagged = !wasFlagged;
  if (msg) msg.flagged = nowFlagged;
  // Sync the row star in the list.
  const rowStar = document.querySelector(`.msglist-rows .row[data-uid="${uid}"] .row-star`);
  if (rowStar) {
    rowStar.classList.toggle("starred", nowFlagged);
    rowStar.textContent = nowFlagged ? "★" : "☆";
  }
  try {
    await api("/api/flag", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ account, folder, uid, flagged: nowFlagged }),
    });
    status(nowFlagged ? "Starred." : "Star removed.");
  } catch (err) {
    if (msg) msg.flagged = wasFlagged;
    if (rowStar) {
      rowStar.classList.toggle("starred", wasFlagged);
      rowStar.textContent = wasFlagged ? "★" : "☆";
    }
    alert(`Could not flag message:\n\n${err.message}`);
  }
});

$("ctx-mark-unread").addEventListener("click", async () => {
  const { uid, account, folder } = { uid: State.ctxUid, account: State.ctxAccount, folder: State.ctxFolder };
  if (!uid) return;
  try {
    await api("/api/mark_seen", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ account, folder, uid, seen: false }),
    });
    const row = document.querySelector(`.msglist-rows .row[data-uid="${uid}"]`);
    if (row) row.classList.add("unread");
    status("Marked as unread.");
  } catch (err) { status("Mark unread failed: " + err.message); }
});

// ---- Move to folder --------------------------------------------------------

$("ctx-move").addEventListener("click", () => {
  const account = State.ctxAccount;
  const src = State.ctxFolder;
  if (!State.ctxUid || !account || !src) return;
  // If the right-clicked row is part of a multi-selection, move the whole
  // selection. Otherwise just the one row.
  let uids;
  if (State.selectedUids.size > 1 && State.selectedUids.has(State.ctxUid)) {
    uids = [...State.selectedUids];
  } else {
    uids = [State.ctxUid];
  }
  // Pull the folder list for this account from the rendered sidebar — that's
  // the canonical list for this session; no need to re-hit /api/folders.
  const folderRows = document.querySelectorAll(
    `.acct-block[data-account="${cssEscape(account)}"] .folder`);
  const folders = [];
  folderRows.forEach(r => {
    folders.push({
      name: r.dataset.folder,
      kind: r.dataset.kind || "folder",
    });
  });
  openMoveModal({ uids, account, src, folders });
});

const moveModal = $("move-modal");

function openMoveModal({ uids, account, src, folders }) {
  // uids is an array (1 or more). Title reflects count so the user knows
  // they're about to move a batch and not just the right-clicked row.
  const titleEl = moveModal.querySelector(".modal-head h2");
  if (titleEl) {
    titleEl.textContent = uids.length > 1
      ? `Move ${uids.length} messages to folder`
      : "Move to folder";
  }
  // Build the list. Sort: inbox first, then alphabetical, with the source
  // folder shown but disabled (you can't move a message to where it already
  // is). Special folders get a small kind label (INBOX / SENT / TRASH).
  const list = $("move-folder-list");
  list.innerHTML = "";
  const ranked = [...folders].sort((a, b) => {
    const order = { inbox: 0, sent: 2, drafts: 3, trash: 9, junk: 8 };
    const ao = order[a.kind] ?? 4, bo = order[b.kind] ?? 4;
    if (ao !== bo) return ao - bo;
    return a.name.localeCompare(b.name);
  });
  for (const f of ranked) {
    const row = document.createElement("div");
    row.className = "move-folder" + (f.name === src ? " disabled" : "");
    row.dataset.folder = f.name;
    const kindLabel = (f.kind && f.kind !== "folder")
      ? `<span class="move-folder-kind">${escapeHtml(f.kind)}</span>` : "";
    row.innerHTML = kindLabel + escapeHtml(folderDisplay(f));
    if (f.name !== src) {
      row.addEventListener("click", () => {
        closeMoveModal();
        doMove(account, src, uids, f.name);
      });
    } else {
      row.title = "Source folder";
    }
    list.appendChild(row);
  }
  // Filter input
  const filter = $("move-filter");
  filter.value = "";
  filter.oninput = () => {
    const q = filter.value.toLowerCase();
    list.querySelectorAll(".move-folder").forEach(el => {
      const match = el.dataset.folder.toLowerCase().includes(q);
      el.style.display = match ? "" : "none";
    });
  };
  moveModal.hidden = false;
  setTimeout(() => filter.focus(), 50);
}

function closeMoveModal() { moveModal.hidden = true; }
$("move-x").addEventListener("click", closeMoveModal);
$("move-cancel").addEventListener("click", closeMoveModal);
moveModal.addEventListener("click", (ev) => {
  // Click on the dim backdrop (not the card) closes.
  if (ev.target === moveModal) closeMoveModal();
});

async function doMove(account, src, uids, dst) {
  status(`Moving to ${dst}...`);
  try {
    const res = await api("/api/move", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ account, folder: src, dst_folder: dst, uids }),
    });
    const ok = new Set(res.moved || []);
    for (const uid of ok) {
      const row = document.querySelector(`.msglist-rows .row[data-uid="${uid}"]`);
      if (row) row.remove();
      State.selectedUids.delete(uid);
      if (State.current.uid === uid) showEmptyViewer();
    }
    if ((res.failed || []).length > 0) {
      const errs = res.failed.map(f => `uid ${f.uid}: ${f.error}`).join("\n");
      status(`Moved ${ok.size}, ${res.failed.length} failed.`);
      alert(`Some messages could not be moved:\n\n${errs}`);
    } else {
      status(`Moved ${ok.size} message(s) to ${dst}.`);
    }
  } catch (err) {
    status("Move failed: " + err.message);
    alert(`Could not move messages:\n\n${err.message}`);
  }
}

$("ctx-delete").addEventListener("click", async () => {
  const { uid, account, folder } = { uid: State.ctxUid, account: State.ctxAccount, folder: State.ctxFolder };
  if (!uid) return;
  if (!confirm("Move this message to trash?")) return;
  status("Deleting...");
  try {
    const res = await api("/api/delete", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ account, folder, uids: [uid] }),
    });
    const row = document.querySelector(`.msglist-rows .row[data-uid="${uid}"]`);
    if (row) row.remove();
    State.selectedUids.delete(uid);
    if (State.current.uid === uid) showEmptyViewer();
    status("Deleted.");
    setTimeout(() => $("btn-refresh").click(), 800);
  } catch (err) { status("Delete failed: " + err.message); }
});

// =====================================================================
// Sidebar folder right-click context menu
//
// Currently only used for "Empty Trash" but lays the groundwork for any
// other folder-level operations (rename, mark-all-read, etc.). The menu is
// only shown when the right-clicked folder is actually a trash folder
// (kind === 'trash') so users can't accidentally empty their inbox.
// =====================================================================

const folderCtxMenu = $("folder-ctx-menu");
State.fctxAccount = null;
State.fctxFolder  = null;

function openFolderCtxMenu(account, folder, kind, x, y) {
  // Only Trash folders get a context menu right now. Returning silently
  // for non-trash folders means the browser's native context menu still
  // appears, which is fine.
  if (kind !== "trash") return;

  State.fctxAccount = account;
  State.fctxFolder  = folder;
  folderCtxMenu.hidden = false;
  const mw = folderCtxMenu.offsetWidth  || 200;
  const mh = folderCtxMenu.offsetHeight || 60;
  folderCtxMenu.style.left = Math.min(x, window.innerWidth  - mw - 8) + "px";
  folderCtxMenu.style.top  = Math.min(y, window.innerHeight - mh - 8) + "px";
}

function closeFolderCtxMenu() { folderCtxMenu.hidden = true; }

document.addEventListener("click", closeFolderCtxMenu);
document.addEventListener("keydown", (ev) => {
  if (ev.key === "Escape") closeFolderCtxMenu();
});
folderCtxMenu.addEventListener("click", (ev) => ev.stopPropagation());

$("fctx-empty-trash").addEventListener("click", async () => {
  const account = State.fctxAccount, folder = State.fctxFolder;
  if (!account || !folder) return;
  closeFolderCtxMenu();
  // Two-step confirmation because this is irreversible.
  if (!confirm(
    `PERMANENTLY delete every message in "${folder}" for ${account}?\n\n` +
    `This cannot be undone.`
  )) return;
  status("Emptying trash...");
  try {
    const res = await api("/api/empty_folder", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ account, folder }),
    });
    status(`Emptied ${folder}: ${res.deleted_count} message(s) deleted.`);
    // Refresh the folder list view if we're currently looking at this folder.
    if (State.current.account === account && State.current.folder === folder) {
      const rowEl = document.querySelector(".sidebar .folder.selected");
      if (rowEl) selectFolder(account, folder, rowEl);
    }
  } catch (err) {
    status(`Empty trash failed: ${err.message}`);
    alert(`Could not empty trash:\n\n${err.message}`);
  }
});
"""


# =============================================================================
# Server-side message processing — sanitize HTML, surface inline image refs,
# strip attachments out into a manifest, optionally inline-embed remote URLs.
# =============================================================================

def _strip_remote(html: str) -> Tuple[str, bool]:
    """Neuter remote img/url(...) references for the no-remote-content view.
    Returns (sanitized_html, had_remote)."""
    had_remote = bool(
        re.search(r'<img\b[^>]*?\bsrc=["\']https?://', html, re.IGNORECASE) or
        re.search(r'url\(\s*["\']?https?://', html, re.IGNORECASE)
    )
    out = re.sub(
        r'(<img\b[^>]*?\bsrc=["\'])https?://[^"\']*(["\'])',
        r'\1about:blank\2', html, flags=re.IGNORECASE
    )
    out = re.sub(r'url\(\s*["\']?https?://[^)]+\)', "url(about:blank)",
                 out, flags=re.IGNORECASE)
    return out, had_remote


def _sniff_image_mime(url: str, data: bytes) -> str:
    if not data:
        return "image/png"
    if data[:8] == b"\x89PNG\r\n\x1a\n": return "image/png"
    if data[:3] == b"\xff\xd8\xff":      return "image/jpeg"
    if data[:6] in (b"GIF87a", b"GIF89a"): return "image/gif"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data[:4] == b"<svg" or data[:5] == b"<?xml": return "image/svg+xml"
    g = mimetypes.guess_type(url)[0]
    return g if g and g.startswith("image/") else "image/png"


def _force_link_target(html: str) -> str:
    """Rewrite every <a> tag to force target="_blank" rel="noopener noreferrer"."""
    def fix(m):
        tag = m.group(0)
        cleaned = re.sub(r'\s+target\s*=\s*"[^"]*"', '', tag, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s+target\s*=\s*'[^']*'", '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'\s+target\s*=\s*[^\s>]+', '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'\s+rel\s*=\s*"[^"]*"', '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s+rel\s*=\s*'[^']*'", '', cleaned, flags=re.IGNORECASE)
        return re.sub(r'^<\s*a\b',
            '<a target="_blank" rel="noopener noreferrer"',
            cleaned, count=1, flags=re.IGNORECASE)
    return re.sub(r'<a\b[^>]*>', fix, html, flags=re.IGNORECASE)


def _proxy_rewrite_remote(html: str) -> Tuple[str, bool]:
    """Rewrite remote image URLs to /proxy?url=... for parallel browser fetch.

    Returns (rewritten_html, had_any_remote). The browser fetches each proxied
    image in parallel using its own connection pool and images appear
    progressively. No serial server-side pre-fetching, no base64 overhead.
    """
    had_remote = bool(
        re.search(r'<img\b[^>]*?\bsrc=["\'\']https?://', html, re.IGNORECASE) or
        re.search(r'url\(\s*["\'\']?https?://', html, re.IGNORECASE)
    )
    if not had_remote:
        return html, False

    def proxy_url(raw: str) -> str:
        return f"/proxy?url={urlquote(html_unescape(raw), safe='')}"

    def replace_img(m):
        full, src = m.group(0), m.group(1)
        if src.lower().startswith(("http://", "https://")):
            return full.replace(src, proxy_url(src), 1)
        return full

    out = re.sub(r"""<img\b[^>]*?\bsrc=["']([^"']+)["']""",
                 replace_img, html, flags=re.IGNORECASE)

    def replace_css(m):
        full, url = m.group(0), m.group(1)
        return full.replace(url, proxy_url(url), 1)

    out = re.sub(r"""url\(\s*["']?(https?://[^)"']+)""",
                 replace_css, out, flags=re.IGNORECASE)
    return out, True


def _sanitize_for_iframe(html: str, allow_remote: bool) -> Tuple[str, bool, int, int]:
    """Strip dangerous tags; optionally proxy-rewrite remote image refs.
    Returns (html, had_remote_blocked, remote_loaded_count, remote_failed_count).
    """
    h = re.sub(
        r"<\s*(script|iframe|object|embed|link|meta|base)[^>]*>.*?<\s*/\s*\1\s*>",
        "", html, flags=re.IGNORECASE | re.DOTALL
    )
    h = re.sub(r"<\s*(script|iframe|object|embed|link|meta|base)[^>]*/?>", "",
               h, flags=re.IGNORECASE)
    h = re.sub(r'\son\w+\s*=\s*"[^"]*"', "", h, flags=re.IGNORECASE)
    h = re.sub(r"\son\w+\s*=\s*'[^']*'", "", h, flags=re.IGNORECASE)
    h = re.sub(r"\son\w+\s*=\s*[^\s>]+", "", h, flags=re.IGNORECASE)
    h = re.sub(r"javascript\s*:", "blocked:", h, flags=re.IGNORECASE)
    h = _force_link_target(h)
    if allow_remote:
        h, _ = _proxy_rewrite_remote(h)
        return h, False, 0, 0
    h, had_remote = _strip_remote(h)
    return h, had_remote, 0, 0


# =============================================================================
# HTTP request handler
# =============================================================================

class _Handler(BaseHTTPRequestHandler):
    server_version = "EmailOfDeathWeb/1.0"
    # Use HTTP/1.1 so Chrome doesn't get confused about keep-alive semantics.
    # We explicitly send Connection: close on every non-SSE response (see
    # _send) so the browser doesn't try to reuse connections — Python's
    # BaseHTTPServer can't really handle pipelining anyway.
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # MUST NOT raise. PyInstaller --windowed builds on Windows have
        # sys.stderr = None — the default BaseHTTPRequestHandler log_message
        # would crash here, propagating an exception out of the request handler
        # mid-response and leaving the browser with an empty page.
        try:
            stderr = sys.stderr
            if stderr is not None:
                stderr.write(f"[web] {self.address_string()} {fmt % args}\n")
        except Exception:
            try:
                with open(_log_path(), "a", encoding="utf-8") as f:
                    f.write(f"[web] {self.address_string()} {fmt % args}\n")
            except Exception:
                pass

    def log_error(self, fmt, *args):
        self.log_message(fmt, *args)

    def handle_one_request(self):
        # Wrap the parent so any exception during request processing is caught
        # and logged rather than killing the worker thread (and the in-flight
        # response).
        try:
            super().handle_one_request()
        except Exception as e:
            try:
                with open(_log_path(), "a", encoding="utf-8") as f:
                    f.write(f"[web] handle_one_request crashed: {e!r}\n")
                    import traceback as _tb
                    f.write(_tb.format_exc())
            except Exception:
                pass

    # -- response helpers -----------------------------------------------------

    def _send(self, status, body, content_type="application/json",
              extra_headers=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        # Force connection close on every response. Python's
        # BaseHTTPRequestHandler doesn't do real keep-alive correctly under
        # HTTP/1.1, and Chrome will hang for ~5 seconds waiting for a
        # promised-but-never-arriving second response on a kept-alive
        # connection. Telling the browser the connection is one-shot
        # eliminates that hang and matches what the server can actually do.
        self.send_header("Connection", "close")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, data, status=200):
        self._send(status, data, "application/json")

    def _send_error(self, status, msg):
        self._send_json({"error": msg}, status=status)

    def _read_json(self) -> dict:
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return {}

    def _account(self, email: str):
        for a in _state.accounts:
            if a.email_addr == email:
                return a
        return None

    # -- routing --------------------------------------------------------------

    def do_GET(self):
        try:
            url = urlparse(self.path)
            path, q = url.path, parse_qs(url.query)
            if path == "/":
                return self._send(200, INDEX_HTML, "text/html; charset=utf-8")
            if path == "/style.css":
                return self._send(200, STYLE_CSS, "text/css; charset=utf-8")
            if path == "/app.js":
                return self._send(200, APP_JS,
                                  "application/javascript; charset=utf-8")
            if path == "/skull.png":
                if SKULL_FILE.exists():
                    return self._send(200, SKULL_FILE.read_bytes(), "image/png")
                return self._send_error(404, "skull.png not found")
            if path == "/favicon.ico":
                # Prefer icon.ico (a real multi-resolution .ico file is what
                # Windows wants for the taskbar). Fall back to skull.png if
                # icon.ico hasn't been bundled yet -- browser tab will still
                # show something rather than a broken-icon glyph.
                if ICON_FILE.exists():
                    return self._send(200, ICON_FILE.read_bytes(),
                                      "image/vnd.microsoft.icon")
                if SKULL_FILE.exists():
                    return self._send(200, SKULL_FILE.read_bytes(), "image/png")
                return self._send_error(404, "favicon not found")
            if path in ("/icon-512.png", "/icon-192.png"):
                # Serve the skull as the PWA icon at all sizes — the browser
                # will scale it. 1000x1000 source is plenty for all sizes.
                if SKULL_FILE.exists():
                    return self._send(200, SKULL_FILE.read_bytes(), "image/png")
                return self._send_error(404, "skull.png not found")
            if path == "/manifest.json":
                return self._send(200, json.dumps({
                    "name": "Email of Death",
                    "short_name": "EOD",
                    "description": "Death's Head Software locally-hosted email client.",
                    "start_url": "/",
                    "display": "standalone",
                    "background_color": "#0d0d0d",
                    "theme_color": "#cc0000",
                    "icons": [
                        {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
                        {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"},
                        {"src": "/skull.png",    "sizes": "1000x1000", "type": "image/png",
                         "purpose": "any maskable"},
                    ],
                }), "application/manifest+json; charset=utf-8")
            if path == "/api/accounts":
                return self._api_accounts()
            if path == "/api/folders":
                return self._api_folders(q)
            if path == "/api/messages":
                return self._api_messages(q)
            if path == "/api/message":
                return self._api_message(q)
            if path == "/api/attachment":
                return self._api_attachment(q)
            if path == "/api/attachments_bulk":
                return self._api_attachments_bulk(q)
            if path == "/api/search":
                return self._api_search(q)
            if path == "/api/contacts":
                return self._api_contacts(q)
            if path == "/api/provider_hints":
                return self._api_provider_hints(q)
            if path == "/api/account":
                return self._api_account_get(q)
            if path == "/events":
                return self._api_events()
            if path == "/proxy":
                return self._proxy(q)
            if path == "/proxy":
                return self._proxy(q)
            return self._send_error(404, "not found")
        except Exception as e:
            tb = traceback.format_exc()
            sys.stderr.write(tb)
            return self._send_error(500, f"{type(e).__name__}: {e}")

    def do_POST(self):
        try:
            url = urlparse(self.path)
            path = url.path
            if path == "/api/mark_seen":
                return self._api_mark_seen(self._read_json())
            if path == "/api/flag":
                return self._api_flag(self._read_json())
            if path == "/api/delete":
                return self._api_delete(self._read_json())
            if path == "/api/empty_folder":
                return self._api_empty_folder(self._read_json())
            if path == "/api/save_draft":
                return self._api_save_draft(self._read_json())
            if path == "/api/move":
                return self._api_move(self._read_json())
            if path == "/api/send":
                return self._api_send(self._read_json())
            if path == "/api/account":
                return self._api_account_save(self._read_json())
            if path == "/api/account/delete":
                return self._api_account_delete(self._read_json())
            if path == "/api/test_account":
                return self._api_test_account(self._read_json())
            return self._send_error(404, "not found")
        except Exception as e:
            tb = traceback.format_exc()
            sys.stderr.write(tb)
            return self._send_error(500, f"{type(e).__name__}: {e}")

    # -- API impls ------------------------------------------------------------

    def _api_accounts(self):
        out = []
        for a in _state.accounts:
            out.append({
                "name": a.name or a.email_addr,
                "email": a.email_addr,
                "real_name": a.real_name,
            })
        return self._send_json(out)

    def _api_folders(self, q):
        em = (q.get("account") or [""])[0]
        acc = self._account(em)
        if acc is None:
            return self._send_error(400, "unknown account")
        try:
            folders = _state.imap.list_folders(acc)
            return self._send_json(folders)
        except Exception as e:
            err = _fmt_exc(e)
            sys.stderr.write(f"[imap] list_folders {em}: {err}\n")
            return self._send_error(500, err)

    def _api_messages(self, q):
        em = (q.get("account") or [""])[0]
        folder = (q.get("folder") or [""])[0]
        try:
            limit = int((q.get("limit") or ["100"])[0])
        except ValueError:
            limit = 100
        acc = self._account(em)
        if acc is None or not folder:
            return self._send_error(400, "missing/invalid account or folder")
        try:
            headers, total, unseen = _state.imap.list_messages(
                acc, folder, limit=limit)
            # Auto-collect senders into the address book (queued/async).
            for h in headers:
                try: _state.contacts.see(h.get("from_addr", ""),
                                         prefer_existing_name=True)
                except Exception: pass
            return self._send_json({
                "headers": headers, "total": total, "unseen": unseen,
            })
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))

    def _api_message(self, q):
        em = (q.get("account") or [""])[0]
        folder = (q.get("folder") or [""])[0]
        try:
            uid = int((q.get("uid") or ["0"])[0])
        except ValueError:
            return self._send_error(400, "invalid uid")
        allow_remote = (q.get("allow_remote") or ["0"])[0] in ("1", "true", "yes")
        acc = self._account(em)
        if acc is None or not folder or uid <= 0:
            return self._send_error(400, "missing/invalid account, folder, or uid")

        key = (em, folder, uid)

        # When allow_remote=1, serve from the in-memory snapshot stored during
        # the initial open. This is synchronous (no async-queue timing issues)
        # and requires zero IMAP round-trips — essential for non-INBOX folders
        # where a prior mark_seen failure can leave the connection in AUTH state.
        if allow_remote:
            with _state._body_store_lock:
                snap = _state._body_store.get(key)
            if snap is not None:
                safe_html, _, _, _ = _sanitize_for_iframe(
                    snap["body_html"], allow_remote=True)
                return self._send_json({
                    "subject":   snap.get("subject", ""),
                    "from_addr": snap.get("from_addr", ""),
                    "to_addrs":  snap.get("to_addrs", ""),
                    "cc_addrs":  snap.get("cc_addrs", ""),
                    "date_iso":  snap.get("date_iso", ""),
                    "msg_id":    snap.get("msg_id", ""),
                    "in_reply_to": snap.get("in_reply_to", ""),
                    "references":  snap.get("references", ""),
                    "body_text":   snap.get("body_text", ""),
                    "body_html_safe": safe_html,
                    "has_remote_blocked": False,
                    "remote_loaded": 0, "remote_failed": 0,
                    "attachments": snap.get("attachments", []),
                    "seen":    snap.get("seen", True),
                    "flagged": snap.get("flagged", False),
                })
            # Body not in store yet (first open failed?) — fall through.
        try:
            msg = _state.imap.fetch_message(acc, folder, uid)
            if msg is None:
                return self._send_error(404, "message not found")
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))

        # Sanitize for iframe rendering.
        body_html = msg.get("body_html") or ""
        safe_html, had_remote, loaded, failed = _sanitize_for_iframe(
            body_html, allow_remote=allow_remote
        )
        # Build attachment manifest with stable indices.
        atts = []
        for i, (fname, ctype, data) in enumerate(msg.get("attachments") or []):
            atts.append({
                "index": i, "filename": fname,
                "content_type": ctype, "size": len(data),
            })
        # Write a full snapshot to the synchronous in-memory store so that a
        # subsequent allow_remote=1 request has everything it needs immediately,
        # without waiting for the async SQLite writer to commit.
        snap = {
            "body_html":   body_html,
            "body_text":   msg.get("body_text", ""),
            "subject":     msg.get("subject", ""),
            "from_addr":   msg.get("from_addr", ""),
            "to_addrs":    msg.get("to_addrs", ""),
            "cc_addrs":    msg.get("cc_addrs", ""),
            "date_iso":    msg.get("date_iso", ""),
            "msg_id":      msg.get("msg_id", ""),
            "in_reply_to": msg.get("in_reply_to", ""),
            "references":  msg.get("references", ""),
            "seen":        msg.get("seen", True),
            "flagged":     msg.get("flagged", False),
            "attachments": atts,
            # Raw bytes stored synchronously so _api_attachment can serve
            # downloads immediately without waiting for the async SQLite
            # writer to commit. Without this, clicking Download right after
            # opening a message hit the "unknown account" 400 because the
            # cache miss caused a live-IMAP fallback path that failed.
            "raw": msg.get("raw", b""),
        }
        with _state._body_store_lock:
            if len(_state._body_store) >= _state.BODY_STORE_MAX:
                items = list(_state._body_store.items())
                _state._body_store = dict(items[len(items)//2:])
            _state._body_store[key] = snap

        # Cache the body for later attachment download requests (async OK here).
        try:
            _state.cache.store_message(acc.email_addr, folder, uid, {
                "msg_id": msg.get("msg_id", ""),
                "from_addr": msg.get("from_addr", ""),
                "to_addrs": msg.get("to_addrs", ""),
                "cc_addrs": msg.get("cc_addrs", ""),
                "subject": msg.get("subject", ""),
                "date_iso": msg.get("date_iso", ""),
                "body_text": msg.get("body_text", ""),
                "body_html": body_html,
                "seen": msg.get("seen", True),
                "flagged": msg.get("flagged", False),
                "has_attachments": bool(atts),
                "raw": msg.get("raw", b""),
            })
        except Exception: pass
        # Auto-collect sender.
        try: _state.contacts.see(msg.get("from_addr", ""),
                                 prefer_existing_name=True)
        except Exception: pass

        return self._send_json({
            "subject": msg.get("subject", ""),
            "from_addr": msg.get("from_addr", ""),
            "to_addrs": msg.get("to_addrs", ""),
            "cc_addrs": msg.get("cc_addrs", ""),
            "date_iso": msg.get("date_iso", ""),
            "msg_id": msg.get("msg_id", ""),
            "in_reply_to": msg.get("in_reply_to", ""),
            "references": msg.get("references", ""),
            "body_text": msg.get("body_text", ""),
            "body_html_safe": safe_html,
            "has_remote_blocked": had_remote,
            "remote_loaded": loaded,
            "remote_failed": failed,
            "attachments": atts,
            "seen": msg.get("seen", True),
            "flagged": msg.get("flagged", False),
        })

    def _api_attachment(self, q):
        em     = (q.get("account") or [""])[0]
        folder = (q.get("folder")  or [""])[0]
        try:
            uid   = int((q.get("uid")   or ["0"])[0])
            index = int((q.get("index") or ["0"])[0])
        except ValueError:
            return self._send_error(400, "invalid uid/index")

        key = (em, folder, uid)

        # --- 1. Body store (synchronous, fastest, always populated when the
        #    user has opened the message in this session) -------------------
        with _state._body_store_lock:
            snap = _state._body_store.get(key)
        if snap and snap.get("raw"):
            try:
                parsed = _parse_message_bytes(bytes(snap["raw"]))
                atts = parsed.get("attachments", [])
                if 0 <= index < len(atts):
                    fname, ctype, data = atts[index]
                    return self._send_attachment(fname, ctype, data)
            except Exception:
                pass  # fall through

        # --- 2. SQLite cache (async write; may not have committed yet) ------
        cached = _state.cache.get_message(em, folder, uid) if _state.cache else None
        if cached and cached.get("raw"):
            try:
                parsed = _parse_message_bytes(bytes(cached["raw"]))
                atts = parsed.get("attachments", [])
                if 0 <= index < len(atts):
                    fname, ctype, data = atts[index]
                    return self._send_attachment(fname, ctype, data)
            except Exception:
                pass  # fall through

        # --- 3. Live IMAP re-fetch (last resort) ----------------------------
        acc = self._account(em)
        if acc is None:
            return self._send_error(404,
                f"Account {em!r} not found. "
                f"Open the message first so it can be cached.")
        try:
            msg = _state.imap.fetch_message(acc, folder, uid)
            atts = (msg or {}).get("attachments") or []
            if not (0 <= index < len(atts)):
                return self._send_error(404, "attachment not found")
            fname, ctype, data = atts[index]
            return self._send_attachment(fname, ctype, data)
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))

    def _send_attachment(self, fname: str, ctype: str, data: bytes):
        """Send attachment bytes with a safe Content-Disposition header.

        Python's BaseHTTPRequestHandler.send_header() encodes header values
        as latin-1 (strict). Non-latin-1 filenames (emoji, CJK, etc.) would
        raise UnicodeEncodeError mid-response, leaving the browser with a
        broken half-response that gets retried as a malformed request → 400.

        RFC 6266 / RFC 5987 encoding ('filename*=UTF-8''...') is used for
        any filename that can't be represented cleanly in ASCII so the header
        always survives the latin-1 encode step."""
        # Sanitize: strip path separators and control characters.
        safe_fname = re.sub(r'[\x00-\x1f\x7f/\\]', '_', fname or "attachment")

        # Build Content-Disposition. For ASCII-only filenames, the simple
        # filename="..." form is fine. For everything else use filename*=
        # so the header value is guaranteed to be latin-1-encodable.
        try:
            ascii_fname = safe_fname.encode("ascii").decode("ascii")
            # Escape quotes / backslashes so the quoted-string is valid.
            escaped = ascii_fname.replace("\\", "\\\\").replace('"', '\\"')
            cd = f'attachment; filename="{escaped}"'
        except (UnicodeEncodeError, UnicodeDecodeError):
            # RFC 5987 percent-encode the filename as UTF-8.
            from urllib.parse import quote as _pct
            pct = _pct(safe_fname.encode("utf-8"), safe="")
            # Also supply a plain ASCII fallback for old clients.
            ascii_fallback = safe_fname.encode("ascii", "replace").decode("ascii")
            cd = f'attachment; filename="{ascii_fallback}"; filename*=UTF-8\'\'{pct}'

        return self._send(
            200, data, ctype or "application/octet-stream",
            extra_headers={"Content-Disposition": cd},
        )

    def _api_mark_seen(self, body):
        em = body.get("account", "")
        folder = body.get("folder", "")
        uid = int(body.get("uid", 0))
        seen = bool(body.get("seen", True))
        acc = self._account(em)
        if acc is None or not folder or uid <= 0:
            return self._send_error(400, "missing/invalid args")
        try:
            _state.imap.mark_seen(acc, folder, uid, seen)
            try: _state.cache.update_seen(em, folder, uid, seen)
            except Exception: pass
            return self._send_json({"ok": True})
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))

    def _api_attachments_bulk(self, q):
        """Return ALL attachments for a message as a JSON array of base64 blobs.

        Used by the forward flow. Fetches raw bytes once (from body_store,
        cache, or IMAP — whichever has them) and extracts every attachment in
        a single pass. This avoids the N separate /api/attachment requests that
        the naive approach makes, each of which opens and closes IMAP or leaves
        the connection in an inconsistent state between calls."""
        em     = (q.get("account") or [""])[0]
        folder = (q.get("folder")  or [""])[0]
        try:
            uid = int((q.get("uid") or ["0"])[0])
        except ValueError:
            return self._send_error(400, "invalid uid")

        key = (em, folder, uid)
        raw: Optional[bytes] = None

        # 1. Body store
        with _state._body_store_lock:
            snap = _state._body_store.get(key)
        if snap and snap.get("raw"):
            raw = bytes(snap["raw"])

        # 2. SQLite cache
        if not raw and _state.cache:
            cached = _state.cache.get_message(em, folder, uid)
            if cached and cached.get("raw"):
                raw = bytes(cached["raw"])

        # 3. Live IMAP (single fetch, all attachments extracted below)
        if not raw:
            acc = self._account(em)
            if acc is None:
                return self._send_error(404, "account not found — open the message first")
            try:
                msg = _state.imap.fetch_message(acc, folder, uid)
                if msg and msg.get("raw"):
                    raw = bytes(msg["raw"])
            except Exception as e:
                return self._send_error(500, _fmt_exc(e))

        if not raw:
            return self._send_error(404, "message not found")

        # Parse once, extract all attachments
        try:
            parsed = _parse_message_bytes(raw)
        except Exception as e:
            return self._send_error(500, f"could not parse message: {_fmt_exc(e)}")

        result = []
        for fname, ctype, data in parsed.get("attachments") or []:
            result.append({
                "filename":     fname,
                "content_type": ctype or "application/octet-stream",
                "data_b64":     base64.b64encode(data).decode("ascii"),
            })
        return self._send_json({"attachments": result})

    def _api_flag(self, body):
        em     = body.get("account", "")
        folder = body.get("folder", "")
        uid    = int(body.get("uid", 0))
        flagged = bool(body.get("flagged", True))
        acc = self._account(em)
        if acc is None or not folder or uid <= 0:
            return self._send_error(400, "missing/invalid args")
        try:
            _state.imap.set_flag(acc, folder, uid, flagged)
            return self._send_json({"ok": True})
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))

    def _api_delete(self, body):
        em = body.get("account", "")
        folder = body.get("folder", "")
        # Accept either {uid: N} (single) or {uids: [...]} (batch).
        uids = body.get("uids")
        sys.stderr.write(f"[api] /api/delete received body keys: {list(body.keys())}, uids raw: {uids!r}\n")
        if uids is None:
            single = body.get("uid")
            uids = [single] if single is not None else []
        try:
            uids = [int(u) for u in uids]
        except (TypeError, ValueError):
            return self._send_error(400, "invalid uid(s)")
        sys.stderr.write(f"[api] /api/delete parsed uids: {uids}, folder: {folder!r}\n")
        if not uids:
            return self._send_error(400, "no uids provided")

        acc = self._account(em)
        if acc is None or not folder:
            return self._send_error(400, "missing/invalid args")

        if len(uids) == 1:
            # Single delete — use existing path (no change in behaviour)
            try:
                _state.imap.delete_message(acc, folder, uids[0])
                try: _state.cache.delete(em, folder, uids[0])
                except Exception: pass
                return self._send_json({"ok": True, "deleted": uids, "failed": []})
            except Exception as e:
                return self._send_json({"ok": False, "deleted": [],
                                        "failed": [{"uid": uids[0], "error": _fmt_exc(e)}]})

        # Batch delete — single IMAP session, chunked UID sets
        all_successes: List[int] = []
        all_failures: List[dict] = []
        # Process in chunks to stay under IMAP line-length limits
        for chunk in _state.imap._chunk_uids(uids):
            s, f = _state.imap.batch_delete_messages(acc, folder, chunk)
            all_successes.extend(s)
            all_failures.extend(f)
        for uid in all_successes:
            try: _state.cache.delete(em, folder, uid)
            except Exception: pass
        return self._send_json({
            "ok": len(all_failures) == 0,
            "deleted": all_successes,
            "failed": all_failures,
        })

    def _api_empty_folder(self, body):
        """Permanently delete every message in a folder (Empty Trash).
        Caller must pass the folder name explicitly — there's no "default to
        trash" shortcut here because we want the JS to be unambiguous about
        what's being wiped."""
        em = body.get("account", "")
        folder = body.get("folder", "")
        acc = self._account(em)
        if acc is None or not folder:
            return self._send_error(400, "missing/invalid args")
        try:
            count = _state.imap.empty_folder(acc, folder)
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))
        # Wipe local cache for the folder too. The cache lookup is keyed by
        # (account, folder, uid); we don't have a wholesale folder-clear,
        # so we just iterate. Failures here are non-fatal.
        return self._send_json({"ok": True, "deleted_count": count})

    def _api_move(self, body):
        em  = body.get("account", "")
        src = body.get("folder", "") or body.get("src_folder", "")
        dst = body.get("dst_folder", "") or body.get("destination", "")
        uids = body.get("uids")
        if uids is None:
            single = body.get("uid")
            uids = [single] if single is not None else []
        try:
            uids = [int(u) for u in uids]
        except (TypeError, ValueError):
            return self._send_error(400, "invalid uid(s)")
        acc = self._account(em)
        if acc is None or not src or not dst:
            return self._send_error(400, "missing account, src folder, or dst folder")
        if not uids:
            return self._send_error(400, "no uids provided")
        if src == dst:
            return self._send_json({"ok": True, "moved": [], "failed": [],
                                    "note": "source and destination are the same"})
        moved: List[int] = []
        failed: List[dict] = []
        for uid in uids:
            try:
                _state.imap.move_message(acc, src, uid, dst)
                try: _state.cache.delete(em, src, uid)
                except Exception: pass
                moved.append(uid)
            except Exception as e:
                failed.append({"uid": uid, "error": _fmt_exc(e)})
        return self._send_json({
            "ok": len(failed) == 0,
            "moved": moved,
            "failed": failed,
        })

    def _api_save_draft(self, body):
        """Build a MIME message from the compose form fields and APPEND it
        to the account's Drafts folder with the \\Draft flag."""
        em = body.get("account", "")
        acc = self._account(em)
        if acc is None:
            return self._send_error(400, "unknown account")

        # Build the MIME message exactly as WebSmtp.send() does, but without
        # actually sending it.
        try:
            from email.mime.multipart import MIMEMultipart
            from email.mime.text import MIMEText
            from email.mime.base import MIMEBase
            from email import encoders as _enc
            import email.utils as _eu
            import io as _io, email.generator as _eg

            to_raw   = body.get("to", "")
            cc_raw   = body.get("cc", "")
            bcc_raw  = body.get("bcc", "")
            subject  = body.get("subject", "") or ""
            body_text = body.get("body_text", "") or ""
            body_html = body.get("body_html", "") or ""
            in_reply_to = body.get("in_reply_to", "") or ""
            references  = body.get("references", "") or ""

            attachments: List[tuple] = []
            for a in body.get("attachments") or []:
                fname = a.get("filename") or "attachment"
                data  = base64.b64decode(a.get("data_b64") or "",
                                         validate=False)
                attachments.append((fname, data))

            msg = (MIMEMultipart("mixed") if attachments
                   else MIMEMultipart("alternative"))
            from_disp = (f"{acc.real_name} <{acc.email_addr}>"
                         if acc.real_name else acc.email_addr)
            msg["From"] = from_disp
            if to_raw:  msg["To"]  = to_raw
            if cc_raw:  msg["Cc"]  = cc_raw
            if bcc_raw: msg["Bcc"] = bcc_raw
            msg["Subject"] = subject
            msg["Date"]    = _eu.formatdate(localtime=True)
            domain = (acc.email_addr.split("@", 1)[-1]
                      if "@" in acc.email_addr else "localhost")
            msg["Message-ID"] = _eu.make_msgid(domain=domain)
            if in_reply_to: msg["In-Reply-To"] = in_reply_to
            if references:  msg["References"]  = references

            if attachments:
                alt = MIMEMultipart("alternative")
                alt.attach(MIMEText(body_text or "", "plain", "utf-8"))
                if body_html:
                    alt.attach(MIMEText(body_html, "html", "utf-8"))
                msg.attach(alt)
                for fname, data in attachments:
                    part = MIMEBase("application", "octet-stream")
                    part.set_payload(data)
                    _enc.encode_base64(part)
                    part.add_header("Content-Disposition",
                                    f'attachment; filename="{fname}"')
                    msg.attach(part)
            else:
                msg.attach(MIMEText(body_text or "", "plain", "utf-8"))
                if body_html:
                    msg.attach(MIMEText(body_html, "html", "utf-8"))

            buf = _io.BytesIO()
            _eg.BytesGenerator(
                buf, mangle_from_=False, maxheaderlen=998
            ).flatten(msg, linesep="\r\n")
            msg_bytes = buf.getvalue()
        except Exception as e:
            return self._send_error(400, f"could not build message: {_fmt_exc(e)}")

        try:
            saved_to = _state.imap.save_draft(acc, msg_bytes)
            return self._send_json({"ok": True, "saved_to": saved_to})
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))
        """Move messages between folders. Accepts either a single uid or
        a list of uids (for multi-select move)."""
        em = body.get("account", "")
        src = body.get("folder", "") or body.get("src_folder", "")
        dst = body.get("dst_folder", "") or body.get("destination", "")
        uids = body.get("uids")
        if uids is None:
            single = body.get("uid")
            uids = [single] if single is not None else []
        try:
            uids = [int(u) for u in uids]
        except (TypeError, ValueError):
            return self._send_error(400, "invalid uid(s)")

        acc = self._account(em)
        if acc is None or not src or not dst:
            return self._send_error(400, "missing account, src folder, or dst folder")
        if not uids:
            return self._send_error(400, "no uids provided")
        if src == dst:
            return self._send_json({"ok": True, "moved": [], "failed": [],
                                    "note": "source and destination are the same"})

        moved: List[int] = []
        failed: List[dict] = []
        for uid in uids:
            try:
                _state.imap.move_message(acc, src, uid, dst)
                # Drop from local cache for the source folder so the next view
                # of that folder doesn't show a phantom row.
                try: _state.cache.delete(em, src, uid)
                except Exception: pass
                moved.append(uid)
            except Exception as e:
                failed.append({"uid": uid, "error": _fmt_exc(e)})
        return self._send_json({
            "ok": len(failed) == 0,
            "moved": moved,
            "failed": failed,
        })

    @staticmethod
    def _split_addrs(s: str) -> List[str]:
        if not s: return []
        return [a.strip() for a in re.split(r"[,;]", s) if a.strip()]

    @staticmethod
    def _addr_only(raw: str) -> str:
        import email.utils as _eu
        _name, em = _eu.parseaddr(raw or "")
        return em or raw

    def _api_send(self, body):
        em = body.get("account", "")
        acc = self._account(em)
        if acc is None:
            return self._send_error(400, "unknown account")
        to_raw = self._split_addrs(body.get("to", ""))
        cc_raw = self._split_addrs(body.get("cc", ""))
        bcc_raw = self._split_addrs(body.get("bcc", ""))
        to_env = [self._addr_only(a) for a in to_raw]
        cc_env = [self._addr_only(a) for a in cc_raw]
        bcc_env = [self._addr_only(a) for a in bcc_raw]
        if not (to_env or cc_env or bcc_env):
            return self._send_error(400, "at least one recipient required")
        subject     = body.get("subject", "") or ""
        body_text   = body.get("body_text", "") or ""
        body_html   = body.get("body_html", "") or ""
        in_reply_to = body.get("in_reply_to", "") or ""
        references  = body.get("references", "") or ""

        attachments: List[Tuple[str, bytes]] = []
        try:
            raw_atts = body.get("attachments") or []
            sys.stderr.write(f"[api] /api/send received {len(raw_atts)} attachment(s) in payload\n")
            for a in raw_atts:
                fname = a.get("filename") or "attachment"
                b64 = a.get("data_b64") or ""
                data = base64.b64decode(b64, validate=False)
                sys.stderr.write(f"[api] /api/send attachment: {fname!r}, "
                                 f"b64 len={len(b64)}, decoded len={len(data)}\n")
                attachments.append((fname, data))
        except Exception as e:
            return self._send_error(400, f"bad attachment payload: {e}")

        # Generate a job ID so the browser can correlate the SSE result event.
        job_id = f"send-{int(time.time()*1000)}-{id(body) & 0xffff:04x}"

        def _do_send():
            try:
                msg_id, msg_bytes = WebSmtp.send(
                    acc, to_env, cc_env, bcc_env, subject,
                    body_text, body_html, attachments,
                    in_reply_to=in_reply_to, references=references,
                )
            except Exception as e:
                _state.bus.emit({
                    "type": "send_result", "job_id": job_id,
                    "ok": False, "error": _fmt_exc(e),
                })
                return

            # Save to Sent folder.
            appended_to = ""
            sent_error  = ""
            candidates: List[str] = []
            if acc.sent_folder:
                candidates.append(acc.sent_folder)
            for fb in ("Sent", "INBOX/Sent", "INBOX.Sent", "Sent Items",
                       "Sent Messages", "[Gmail]/Sent Mail",
                       "Gesendet", "Envoyés", "Enviados",
                       "Inviata", "Posta inviata"):
                if fb not in candidates:
                    candidates.append(fb)
            for folder_name in candidates:
                try:
                    _state.imap.append_to_folder(acc, folder_name, msg_bytes)
                    appended_to = folder_name
                    if folder_name != acc.sent_folder:
                        acc.sent_folder = folder_name
                        try: save_accounts(_state.accounts)
                        except Exception: pass
                    break
                except Exception as e:
                    sent_error = f"{folder_name}: {_fmt_exc(e)}"
                    continue

            # Address book.
            try:
                for raw in to_raw + cc_raw + bcc_raw:
                    _state.contacts.see(raw)
            except Exception:
                pass

            _state.bus.emit({
                "type":        "send_result",
                "job_id":      job_id,
                "ok":          True,
                "message_id":  msg_id,
                "saved_to_sent": appended_to,
                "sent_error":  sent_error if not appended_to else "",
            })

        t = threading.Thread(target=_do_send, daemon=True,
                             name=f"smtp-{job_id}")
        t.start()
        # Return immediately — browser shows "Sending..." until the SSE
        # send_result event arrives.
        return self._send_json({"ok": True, "queued": True, "job_id": job_id})

    def _api_search(self, q):
        em = (q.get("account") or [""])[0]
        folder = (q.get("folder") or [""])[0]
        query = (q.get("q") or [""])[0]
        acc = self._account(em)
        if acc is None or not folder:
            return self._send_error(400, "missing account/folder")
        if not query.strip():
            return self._send_json({"headers": [], "query": query})
        try:
            headers = _state.imap.search_messages(acc, folder, query)
            return self._send_json({"headers": headers, "query": query})
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))

    def _api_contacts(self, q):
        query = (q.get("q") or [""])[0]
        try:
            cs = _state.contacts.list_all(query)
            return self._send_json([
                {"email": c.email, "name": c.name, "freq": c.freq}
                for c in cs[:200]  # cap for autocomplete UI
            ])
        except Exception as e:
            return self._send_error(500, _fmt_exc(e))

    # -- Remote image proxy -----------------------------------------------

    def _proxy(self, q):
        """Fetch a remote URL and return its bytes, caching the result."""
        target = (q.get("url") or [""])[0]
        if not target:
            return self._send_error(400, "missing url")
        if not target.startswith(("http://", "https://")):
            return self._send_error(400, "only http/https allowed")

        with _state._remote_cache_lock:
            cached = _state.remote_cache.get(target)
        if cached:
            ct, data = cached
            return self._send(200, data, ct,
                              extra_headers={"Cache-Control": "max-age=3600"})

        try:
            req = urllib.request.Request(
                target,
                headers={"User-Agent": "Mozilla/5.0 (EmailOfDeath/web)",
                         "Accept": "image/*,*/*;q=0.8"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                ct = resp.headers.get_content_type() or "image/png"
                if not (ct.startswith("image/") or ct.startswith("text/css")):
                    ct = "image/png"
                data = resp.read(10 * 1024 * 1024)
        except urllib.error.HTTPError as e:
            return self._send_error(e.code, f"upstream {e.code}: {e.reason}")
        except Exception as e:
            return self._send_error(502, f"fetch failed: {_fmt_exc(e)}")

        with _state._remote_cache_lock:
            if len(_state.remote_cache) >= _state.REMOTE_CACHE_MAX:
                _state.remote_cache.clear()
            _state.remote_cache[target] = (ct, data)

        return self._send(200, data, ct,
                          extra_headers={"Cache-Control": "max-age=3600"})

        # -- Server-Sent Events (push notifications) ---------------------------

    def _api_events(self):
        """Stream Server-Sent Events. The handler thread (one per browser tab)
        blocks on the bus queue and writes each event as it arrives. It exits
        cleanly when the client closes the EventSource — at which point the
        write fails with BrokenPipe and we unsubscribe."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        # Disable proxy buffering — relevant for nginx etc., harmless otherwise.
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()

        q = _state.bus.subscribe()
        try:
            self.wfile.write(b": connected\n\n")
            self.wfile.flush()
            while True:
                try:
                    event = q.get(timeout=15)
                except _queue.Empty:
                    # Heartbeat — also doubles as a write that detects a
                    # closed client socket.
                    try:
                        self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        return
                    continue
                try:
                    line = f"data: {json.dumps(event)}\n\n".encode("utf-8")
                    self.wfile.write(line)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    return
        finally:
            _state.bus.unsubscribe(q)

    # -- Account management (provider hints + CRUD + test) -------------------

    def _api_provider_hints(self, q):
        em = (q.get("email") or [""])[0].strip().lower()
        domain = em.split("@", 1)[-1] if "@" in em else em
        if not domain:
            return self._send_json({"hints": None, "domain": ""})
        hints = resolve_provider_hint(domain)
        return self._send_json({"hints": hints, "domain": domain})

    def _api_account_get(self, q):
        em = (q.get("email") or [""])[0].strip().lower()
        acc = self._account(em)
        if acc is None:
            return self._send_error(404, "account not found")
        # Don't return passwords. Just whether each one is set so the form can
        # show a "(saved)" placeholder rather than a literal one.
        return self._send_json({
            "name": acc.name,
            "email_addr": acc.email_addr,
            "real_name": acc.real_name,
            "imap_host": acc.imap_host, "imap_port": acc.imap_port,
            "imap_user": acc.imap_user, "imap_ssl": acc.imap_ssl,
            "imap_pass_set": bool(acc.imap_pass),
            "smtp_host": acc.smtp_host, "smtp_port": acc.smtp_port,
            "smtp_user": acc.smtp_user, "smtp_ssl": acc.smtp_ssl,
            "smtp_starttls": acc.smtp_starttls,
            "smtp_pass_set": bool(acc.smtp_pass),
            "sent_folder": acc.sent_folder,
            "trash_folder": acc.trash_folder,
            "drafts_folder": acc.drafts_folder,
        })

    def _api_account_save(self, body):
        """Create or update an account. The email_addr is the primary key —
        if there's already an account with the same email, it's updated in
        place; otherwise a new one is appended."""
        em = (body.get("email_addr") or "").strip().lower()
        if not em or "@" not in em:
            return self._send_error(400, "valid email_addr required")

        existing = self._account(em)
        is_new = existing is None
        acc = existing if existing is not None else Account()

        # Apply form fields. Passwords are special: an empty string in an
        # update means "keep the previously stored password" — so the user
        # doesn't have to retype it on every edit.
        acc.name      = body.get("name") or em
        acc.email_addr = em
        acc.real_name = body.get("real_name", "") or ""
        acc.imap_host = (body.get("imap_host") or "").strip()
        try: acc.imap_port = int(body.get("imap_port") or 993)
        except (TypeError, ValueError): acc.imap_port = 993
        acc.imap_user = (body.get("imap_user") or em).strip()
        acc.imap_ssl  = bool(body.get("imap_ssl", True))
        if body.get("imap_pass"):
            acc.imap_pass = body["imap_pass"]

        acc.smtp_host = (body.get("smtp_host") or "").strip()
        try: acc.smtp_port = int(body.get("smtp_port") or 465)
        except (TypeError, ValueError): acc.smtp_port = 465
        acc.smtp_user = (body.get("smtp_user") or em).strip()
        acc.smtp_ssl  = bool(body.get("smtp_ssl", True))
        acc.smtp_starttls = bool(body.get("smtp_starttls", False))
        if body.get("smtp_pass"):
            acc.smtp_pass = body["smtp_pass"]

        # If user asked to copy the IMAP password to SMTP (single-password UX),
        # do that here on the server so the form can stay simple.
        if body.get("use_imap_pass_for_smtp") and acc.imap_pass:
            acc.smtp_pass = acc.imap_pass

        # Optional folder overrides — useful when auto-detect can't find the
        # right names (e.g. IONOS / older Dovecot servers that don't advertise
        # SPECIAL-USE flags, or non-English folder names we don't recognize).
        # Empty string means "auto-detect, please" — preserve whatever's there.
        for src_key, attr in (
            ("trash_folder",  "trash_folder"),
            ("sent_folder",   "sent_folder"),
            ("drafts_folder", "drafts_folder"),
        ):
            if src_key in body:
                v = (body.get(src_key) or "").strip()
                if v:
                    setattr(acc, attr, v)

        if not acc.is_valid():
            missing = []
            for f in ("imap_host", "imap_user", "imap_pass",
                      "smtp_host", "smtp_user", "smtp_pass"):
                if not getattr(acc, f):
                    missing.append(f)
            return self._send_error(400, "missing required: " + ", ".join(missing))

        if is_new:
            _state.accounts.append(acc)
        try:
            save_accounts(_state.accounts)
        except Exception as e:
            # Roll back the in-memory append if the disk write failed.
            if is_new and acc in _state.accounts:
                _state.accounts.remove(acc)
            return self._send_error(500, _fmt_exc(e))

        # Drop any stale IMAP connection so the next request reconnects with
        # the new credentials.
        try: _state.imap._close(em)
        except Exception: pass
        # Restart IDLE watchers — the account list / credentials may have
        # changed and the existing IDLE thread has stale state.
        try: _state.restart_idle()
        except Exception: pass

        return self._send_json({"ok": True, "is_new": is_new, "email": em})

    def _api_account_delete(self, body):
        em = (body.get("email_addr") or "").strip().lower()
        acc = self._account(em)
        if acc is None:
            return self._send_error(404, "account not found")

        _state.accounts.remove(acc)
        try:
            save_accounts(_state.accounts)
        except Exception as e:
            # Put it back if save failed.
            _state.accounts.append(acc)
            return self._send_error(500, _fmt_exc(e))

        try: _state.imap._close(em)
        except Exception: pass
        try: _state.restart_idle()
        except Exception: pass

        # Optional: wipe cached messages for this account so the cache isn't
        # full of orphan rows. We don't have a wipe-all-folders helper, but
        # the cache is keyed by (account, folder, uid) so leaving them is
        # harmless — they'll just never be queried again.
        return self._send_json({"ok": True})

    def _api_test_account(self, body):
        """Try IMAP and SMTP login with given credentials, without saving.
        Returns per-protocol result with a hint list if auth failed."""
        import smtplib
        em = (body.get("email_addr") or "").strip().lower()
        if not em:
            return self._send_error(400, "email_addr required")

        results: Dict[str, Any] = {
            "imap": {"ok": False, "message": ""},
            "smtp": {"ok": False, "message": ""},
        }

        imap_host = (body.get("imap_host") or "").strip()
        imap_port = int(body.get("imap_port") or 993)
        imap_user = (body.get("imap_user") or em).strip()
        imap_pass = body.get("imap_pass") or ""
        imap_ssl  = bool(body.get("imap_ssl", True))

        smtp_host = (body.get("smtp_host") or "").strip()
        smtp_port = int(body.get("smtp_port") or 465)
        smtp_user = (body.get("smtp_user") or em).strip()
        smtp_pass = body.get("smtp_pass") or imap_pass  # single-password UX
        smtp_ssl  = bool(body.get("smtp_ssl", True))
        smtp_starttls = bool(body.get("smtp_starttls", False))

        # ---- IMAP ----
        if not (imap_host and imap_user and imap_pass):
            results["imap"]["message"] = "missing host / user / password"
        else:
            try:
                ctx = _ssl_context()
                if imap_ssl:
                    c = imaplib.IMAP4_SSL(imap_host, imap_port,
                                          ssl_context=ctx, timeout=15)
                else:
                    c = imaplib.IMAP4(imap_host, imap_port, timeout=15)
                    try: c.starttls(ssl_context=ctx)
                    except Exception: pass
                c.login(imap_user, imap_pass)
                typ, data = c.list()
                n_folders = len([d for d in (data or []) if d]) if typ == "OK" else 0
                results["imap"] = {"ok": True,
                                   "message": f"Connected. {n_folders} folder(s) visible."}
                try: c.logout()
                except Exception: pass
            except Exception as e:
                msg = _fmt_exc(e)
                results["imap"] = {
                    "ok": False, "message": msg,
                    "hints": _auth_hints(msg, em),
                }

        # ---- SMTP ----
        if not (smtp_host and smtp_user and smtp_pass):
            results["smtp"]["message"] = "missing host / user / password"
        else:
            try:
                ctx = _ssl_context()
                if smtp_ssl:
                    s = smtplib.SMTP_SSL(smtp_host, smtp_port,
                                         context=ctx, timeout=15)
                else:
                    s = smtplib.SMTP(smtp_host, smtp_port, timeout=15)
                    s.ehlo()
                    if smtp_starttls:
                        s.starttls(context=ctx)
                        s.ehlo()
                s.login(smtp_user, smtp_pass)
                results["smtp"] = {"ok": True, "message": "Connected."}
                try: s.quit()
                except Exception:
                    try: s.close()
                    except Exception: pass
            except Exception as e:
                msg = _fmt_exc(e)
                results["smtp"] = {
                    "ok": False, "message": msg,
                    "hints": _auth_hints(msg, em),
                }

        return self._send_json(results)


# =============================================================================
# Entry point — argparse selects web vs. desktop
# =============================================================================

def run_desktop():
    if not _PYQT6_AVAILABLE:
        print("ERROR: PyQt6 is not installed or could not be loaded.")
        print("Install it with:  pip install PyQt6")
        import sys; sys.exit(1)

    # Suppress noisy Qt warnings from broken email HTML. Marketing/Outlook
    # email frequently has CSS like `font-size: 0` or bare hex colors like
    # `f4f4f4` (no '#'), which Qt's HTML parser flags but renders fine.
    try:
        from PyQt6.QtCore import qInstallMessageHandler, QtMsgType

        def _msg_filter(msg_type, context, msg):
            if msg_type == QtMsgType.QtWarningMsg and msg:
                noisy = ("Point size <=", "Unknown color name",
                         "QTextHtmlParser::applyAttributes")
                for n in noisy:
                    if n in msg:
                        return  # swallow
            try:
                sys.stderr.write(f"Qt: {msg}\n")
            except Exception:
                pass

        qInstallMessageHandler(_msg_filter)
    except Exception:
        pass  # not fatal if message handler can't install

    # Hi-DPI niceties
    if hasattr(Qt, "AA_EnableHighDpiScaling"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling, True)
    if hasattr(Qt, "AA_UseHighDpiPixmaps"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setStyle("Fusion")

    # Dark palette as a fallback for native widgets QSS misses.
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor("#0d0d0d"))
    palette.setColor(QPalette.ColorRole.WindowText, QColor("#e0e0e0"))
    palette.setColor(QPalette.ColorRole.Base, QColor("#141414"))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor("#1a1a1a"))
    palette.setColor(QPalette.ColorRole.Text, QColor("#e0e0e0"))
    palette.setColor(QPalette.ColorRole.Button, QColor("#1a1a1a"))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor("#e0e0e0"))
    palette.setColor(QPalette.ColorRole.Highlight, QColor("#660000"))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor("#ffffff"))
    palette.setColor(QPalette.ColorRole.ToolTipBase, QColor("#141414"))
    palette.setColor(QPalette.ColorRole.ToolTipText, QColor("#e0e0e0"))
    palette.setColor(QPalette.ColorRole.PlaceholderText, QColor("#666666"))
    app.setPalette(palette)

    app.setStyleSheet(DARK_QSS)

    # Splash
    splash = create_splash()
    if splash:
        splash.show()
        for msg in [
            "Loading accounts...",
            "Establishing secure connection...",
            "Fetching messages from the crypt...",
            "Ready to deliver some Email of Death!",
        ]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    win = MainWindow()
    win.show()
    if splash:
        splash.finish(win)

    sys.exit(app.exec())




def _has_console() -> bool:
    """True if stdout is connected to a real terminal. PyInstaller --windowed
    builds on Windows have stdout=None, so any print() raises AttributeError
    or writes into the void. We use this to gate console output and to
    decide whether to fall back to a log file."""
    try:
        return sys.stdout is not None and sys.stdout.isatty()
    except Exception:
        return False


def _log_path() -> Path:
    """Where to write run logs in --windowed builds (no console available).
    Lives next to config.json so the user knows where to find it if the app
    silently fails to start."""
    return CONFIG_FILE.parent / "eod-web.log"


def _safe_print(*args, **kwargs):
    """print() that doesn't crash when stdout is None (--windowed PyInstaller).
    Writes to the log file instead so launches are debuggable."""
    msg = " ".join(str(a) for a in args)
    if _has_console():
        try: print(msg, **kwargs)
        except Exception: pass
        return
    try:
        with open(_log_path(), "a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass


def run_web():
    # PyInstaller --windowed on Windows leaves sys.stdout / sys.stderr as None.
    # ANY .write() on them crashes with AttributeError. The default HTTP
    # request logger writes to sys.stderr after sending headers but before the
    # body — when it crashes, the browser sees a closed connection and shows
    # "empty page" with no error.
    #
    # Replace None stdio with no-op writers BEFORE anything else runs.
    import io
    class _NullWriter(io.IOBase):
        def write(self, *a, **k): return 0
        def flush(self): pass
        def isatty(self): return False
    if sys.stdout is None:
        sys.stdout = _NullWriter()
    if sys.stderr is None:
        sys.stderr = _NullWriter()

    # Wrap the entire boot in a try/except so PyInstaller --windowed builds
    # don't silently die. Any startup failure gets logged to eod-web.log
    # next to config.json and shown via a desktop dialog if PyQt is available.
    try:
        _run_web_impl()
    except SystemExit:
        raise
    except Exception as e:
        tb = traceback.format_exc()
        try:
            with open(_log_path(), "a", encoding="utf-8") as f:
                f.write(f"\n--- crash {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
                f.write(tb)
        except Exception:
            pass
        # Best-effort GUI error dialog for --windowed builds.
        try:
            from PyQt6.QtWidgets import QApplication, QMessageBox
            app = QApplication.instance() or QApplication([])
            QMessageBox.critical(
                None, f"{APP_NAME} - Startup Error",
                f"Could not start the web server.\n\n"
                f"{e}\n\nDetails written to:\n{_log_path()}"
            )
        except Exception:
            pass
        sys.exit(1)


def _run_web_impl():
    _safe_print(f"{APP_NAME} - Web Edition")
    _safe_print(f"{ORG_NAME}")
    _safe_print("")

    _state.boot()
    _safe_print(f"Loaded {len(_state.accounts)} account(s) from {CONFIG_FILE}")
    pwbe = password_store().backend
    _safe_print(f"Password backend: {pwbe}")
    if not _state.accounts:
        _safe_print("No accounts configured. Add one using the desktop app first:")
        _safe_print(f"  python {sys.argv[0]} --desktop")
        _safe_print("")

    # Bind 127.0.0.1 only -- single user, no auth, no internet exposure.
    addr = (HOST, PORT)
    try:
        srv = ThreadingHTTPServer(addr, _Handler)
    except OSError as e:
        # Most common cause: another EOD instance is already running.
        # If so, just open the browser to the existing one and exit cleanly.
        msg = (f"Could not bind to {HOST}:{PORT}: {e}\n"
               f"Another instance may already be running. "
               f"Opening the existing one in your browser.")
        _safe_print(msg)
        try:
            webbrowser.open(f"http://{HOST}:{PORT}/")
        except Exception:
            pass
        sys.exit(0)
    srv.daemon_threads = True
    # SO_REUSEADDR so we can restart immediately after a crash without waiting
    # for TIME_WAIT to expire on Windows.
    srv.allow_reuse_address = True

    url = f"http://{HOST}:{PORT}/"
    _safe_print(f"Serving at {url}")
    _safe_print("Press Ctrl-C to stop.")
    _safe_print("")

    # Run the server on a background thread so we can verify it's actually
    # accepting connections before opening the browser. The previous approach
    # used a fixed 0.4 s Timer which is unreliable in PyInstaller --onefile
    # builds (the bootloader extraction + main thread setup can take several
    # seconds on Windows, especially on slower disks).
    serve_thread = threading.Thread(target=srv.serve_forever, daemon=True,
                                    name="EOD-HTTP")
    serve_thread.start()

    # Poll the bound port until a real connection succeeds, then open browser.
    if _wait_for_listen(HOST, PORT, timeout=10.0):
        _safe_print("Server is listening; opening browser.")
    else:
        _safe_print("Server may not be ready; opening browser anyway.")

    # Open the browser. The browser tab IS the UI — no separate status
    # window. If the browser fails to open the user can navigate manually.
    try:
        webbrowser.open(url)
    except Exception as e:
        _safe_print(f"webbrowser.open failed: {e}")
        _safe_print(f"Open this URL manually: {url}")

    # Taskbar entry: a small status window registered with the window manager
    # so it appears in the Windows taskbar with the skull icon. Window starts
    # minimized so it doesn't pop up on screen — clicking it from the taskbar
    # restores it. Closing the window's X button minimizes it back to the
    # taskbar; only the Quit button truly exits.
    ui_ok = False
    try:
        from PyQt6.QtWidgets import (
            QApplication, QSystemTrayIcon, QMenu, QMainWindow, QWidget,
            QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        )
        from PyQt6.QtGui import (
            QIcon as _QIcon, QAction as _QAction, QPixmap as _QPixmap,
            QCloseEvent as _QCloseEvent,
        )
        from PyQt6.QtCore import Qt as _Qt

        app = QApplication.instance() or QApplication(sys.argv)

        # Critical on Windows: tells the OS this is a separate application
        # so the taskbar groups under our icon, not generic Python.
        try:
            import ctypes
            myappid = "deathsheadsoftware.emailofdeath.web.1"
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception:
            pass

        # Build the icon — multi-resolution so taskbar gets a sharp version.
        icon = _QIcon()
        if ICON_FILE.exists():
            icon = _QIcon(str(ICON_FILE))
            _safe_print(f"Icon: loaded {ICON_FILE}")
        elif SKULL_FILE.exists():
            pix = _QPixmap(str(SKULL_FILE))
            if not pix.isNull():
                icon = _QIcon()
                for sz in (16, 24, 32, 48, 64, 128, 256):
                    scaled = pix.scaled(
                        sz, sz,
                        _Qt.AspectRatioMode.KeepAspectRatio,
                        _Qt.TransformationMode.SmoothTransformation,
                    )
                    icon.addPixmap(scaled)
                _safe_print(f"Icon: built from {SKULL_FILE}")
        if icon.isNull():
            _safe_print("Icon: WARNING — icon.ico and skull_print.png both "
                        "missing. Using fallback.")
            pix = _QPixmap(16, 16); pix.fill()
            icon = _QIcon(pix)

        app.setWindowIcon(icon)

        # Shutdown helper used by both the Quit button and the window's X.
        # It does the entire cleanup synchronously before calling app.quit()
        # so no daemon threads outlive the Qt event loop.
        def _full_shutdown():
            _safe_print("Shutting down...")
            # 1. Stop IMAP IDLE watchers (signals their threads to exit).
            try: _state.stop_idle()
            except Exception: pass
            # 2. Close persistent IMAP connections.
            try: _state.imap.disconnect_all()
            except Exception: pass
            # 3. Stop the HTTP server. shutdown() blocks until serve_forever
            #    returns, so we know nothing else is in-flight after this.
            try: srv.shutdown()
            except Exception: pass
            try: srv.server_close()
            except Exception: pass
            # 4. Flush the SQLite writer queues (cache + address book).
            try: _state.cache.shutdown()
            except Exception: pass
            try: _state.contacts.shutdown()
            except Exception: pass
            # 5. Exit Qt.
            app.quit()

        # Build the small status window. X button = full shutdown (kills the
        # process entirely, not minimize). Use the minimize button on the
        # title bar if you just want to get it out of the way.
        class _StatusWindow(QMainWindow):
            def closeEvent(self, ev: _QCloseEvent):
                # The Windows taskbar's right-click > Close window also
                # triggers this. We want both X and that menu to actually
                # quit, not minimize.
                ev.accept()
                _full_shutdown()

        win = _StatusWindow()
        win.setWindowTitle("Email of Death")
        win.setWindowIcon(icon)
        win.resize(420, 200)
        win.setStyleSheet(
            "QMainWindow, QWidget { background: #0d0d0d; color: #e0e0e0; "
            "  font-family: 'Segoe UI', sans-serif; }"
            "QLabel { color: #e0e0e0; }"
            "QLabel#title { color: #cc0000; font-size: 18px; font-weight: bold; }"
            "QLabel#url { color: #ff8080; font-size: 13px; }"
            "QPushButton { background: #2a0000; color: #cc0000; "
            "  border: 1px solid #cc0000; padding: 7px 16px; }"
            "QPushButton:hover { background: #cc0000; color: white; }"
        )

        central = QWidget()
        win.setCentralWidget(central)
        v = QVBoxLayout(central)
        v.setContentsMargins(20, 16, 20, 16)
        v.setSpacing(10)

        title = QLabel("Email of Death")
        title.setObjectName("title")
        v.addWidget(title)

        sub = QLabel("Running. Click the link below or use your browser tab.")
        v.addWidget(sub)

        link = QLabel(f'<a href="{url}" style="color:#ff8080;">{url}</a>')
        link.setObjectName("url")
        link.setOpenExternalLinks(True)
        link.setTextInteractionFlags(_Qt.TextInteractionFlag.TextBrowserInteraction)
        v.addWidget(link)

        info = QLabel(f"{len(_state.accounts)} account(s) loaded.")
        info.setStyleSheet("color: #808080; font-size: 11px;")
        v.addWidget(info)

        v.addStretch(1)

        btns = QHBoxLayout()
        open_btn = QPushButton("Open in Browser")
        def _open_again():
            try: webbrowser.open(url)
            except Exception: pass
        open_btn.clicked.connect(_open_again)
        btns.addWidget(open_btn)

        btns.addStretch(1)

        quit_btn = QPushButton("Quit")
        quit_btn.clicked.connect(_full_shutdown)
        btns.addWidget(quit_btn)
        v.addLayout(btns)

        # Show MINIMIZED so it lands in the taskbar without popping up.
        # The user can click the taskbar entry to bring it forward.
        win.showMinimized()

        # Keep a tray icon too (some users prefer it; quit accessible from
        # both places). Best-effort — if the system tray isn't available,
        # the taskbar entry is enough.
        try:
            if QSystemTrayIcon.isSystemTrayAvailable():
                tray = QSystemTrayIcon(icon)
                tray.setToolTip(f"Email of Death — {url}")
                menu = QMenu()
                act_show = _QAction("Show window")
                def _show_window():
                    win.showNormal()
                    win.raise_()
                    win.activateWindow()
                act_show.triggered.connect(_show_window)
                menu.addAction(act_show)
                act_open2 = _QAction("Open in Browser")
                act_open2.triggered.connect(_open_again)
                menu.addAction(act_open2)
                menu.addSeparator()
                act_quit2 = _QAction("Quit")
                act_quit2.triggered.connect(_full_shutdown)
                menu.addAction(act_quit2)
                tray.setContextMenu(menu)
                def _on_activated(reason):
                    if reason in (
                        QSystemTrayIcon.ActivationReason.Trigger,
                        QSystemTrayIcon.ActivationReason.DoubleClick,
                    ):
                        _show_window()
                tray.activated.connect(_on_activated)
                tray.show()
        except Exception:
            pass

        ui_ok = True
        _safe_print("Taskbar entry created (minimized). Click the skull "
                    "icon in the taskbar to show the window.")
        app.exec()
    except Exception as e:
        _safe_print(f"UI unavailable ({e}); running headless.")

    if not ui_ok:
        # No tray: fall back to a plain blocking loop. Ctrl-C in console mode,
        # or kill from Task Manager in --windowed mode (less ideal but works).
        stop_evt = threading.Event()
        try:
            while not stop_evt.is_set() and serve_thread.is_alive():
                stop_evt.wait(1.0)
        except KeyboardInterrupt:
            _safe_print("\nShutting down...")

    # Cleanup (defensive — _full_shutdown already does this on Quit)
    try: srv.shutdown()
    except Exception: pass
    try: srv.server_close()
    except Exception: pass
    try: _state.stop_idle()
    except Exception: pass
    try: _state.imap.disconnect_all()
    except Exception: pass
    try: _state.cache.shutdown()
    except Exception: pass
    try: _state.contacts.shutdown()
    except Exception: pass

    # Force-terminate the process to make sure no straggler daemon threads
    # keep the process alive. On Windows, PyInstaller --windowed builds
    # sometimes have lingering threads (especially from PyQt6 / IMAP IDLE)
    # that hold the process at a few hundred KB of memory even after all
    # the visible UI is gone. os._exit() skips any remaining atexit handlers
    # and exits the process immediately — by this point we've already done
    # all the cleanup that matters (HTTP shutdown, IMAP disconnect, SQLite
    # flush), so there's nothing left to lose.
    os._exit(0)


def _wait_for_listen(host: str, port: int, timeout: float) -> bool:
    """Return True once a TCP connect to (host, port) succeeds, else False
    after timeout. Used to defer opening the browser until the HTTP server
    is actually accepting."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.1)
    return False




def main():
    p = argparse.ArgumentParser(
        prog="EOD",
        description=(
            "Email of Death — Death's Head Software IMAP/SMTP client. "
            "Web by default; pass --desktop for the PyQt UI."
        ),
    )
    grp = p.add_mutually_exclusive_group()
    grp.add_argument("--web", action="store_true",
                     help="Run the locally-hosted web UI (default).")
    grp.add_argument("--desktop", "--gui", dest="desktop", action="store_true",
                     help="Run the PyQt6 desktop UI.")
    args = p.parse_args()
    if args.desktop:
        run_desktop()
    else:
        run_web()


if __name__ == "__main__":
    main()
