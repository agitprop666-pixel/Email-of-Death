# Runtime hook: ensure PyQt6.sip is importable from the bundle.
# PyInstaller bundles it as a .pyd/.so but the import machinery sometimes
# needs a nudge to find it before PyQt6.QtCore loads.
import sys, os

# If running from a PyInstaller bundle, add _MEIPASS to the DLL search path
# so the sip extension can be found by the dynamic linker.
if hasattr(sys, '_MEIPASS'):
    meipass = sys._MEIPASS
    # Windows: add to PATH so Qt DLLs find each other
    if sys.platform == 'win32':
        os.environ['PATH'] = meipass + os.pathsep + os.environ.get('PATH', '')
        try:
            os.add_dll_directory(meipass)
        except (AttributeError, OSError):
            pass
    # Pre-import sip so it's in sys.modules before PyQt6.QtCore loads
    try:
        import PyQt6.sip  # noqa: F401
    except ImportError:
        pass
